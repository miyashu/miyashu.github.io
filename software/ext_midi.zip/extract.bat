python extract.py %*
