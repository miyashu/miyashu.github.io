import os
import sys

def decompress(input_filepath):
    filename = os.path.basename(input_filepath)
    root, ext = os.path.splitext(filename)
    ext_upper = ext.upper()

    # --- 1. 対象外の拡張子をスキップ ---
    ALLOWED_EXTENSIONS = {".RCP", ".DAT", ".CMP", ".GSP"}
    if ext_upper not in ALLOWED_EXTENSIONS:
        print(f"スキップ（対象外の拡張子です）: {filename}")
        return

    # --- 2. ファイル読み込み ---
    with open(input_filepath, 'rb') as f:
        input_data = f.read()

    data_len = len(input_data)

    # 判定用の変数
    start_index = 0       # 解凍開始位置（0バイト目 または 4バイト目）
    target_size = None    # 解凍目標サイズ（ヘッダ指定時）
    out_ext = None        # 出力拡張子

    # 共通ヘッダパターンの定義
    HEADER_5B_RCP   = bytes([0xFF, 0x52, 0x43, 0x4D, 0x2D])               # FF 52 43 4D 2D (5バイト)
    HEADER_5B_CMP   = bytes([0xFF, 0x43, 0x4F, 0x4D, 0x45])               # FF 43 4F 4D 45 (5バイト)
    HEADER_SIZE_RCP = bytes([0x00, 0x00, 0xFF, 0x52, 0x43, 0x4D, 0x2D]) # 00 00 FF 52 43 4M 2D (7バイト)
    HEADER_SIZE_CMP = bytes([0x00, 0x00, 0xFF, 0x43, 0x4F, 0x4D, 0x45]) # 00 00 FF 43 4F 4D 45 (7バイト)

    # --- 3. 拡張子ごとの判定とパラメータ設定 ---

    # 【.RCP の場合】
    if ext_upper == ".RCP":
        if data_len >= 5 and input_data[:5] == HEADER_5B_RCP:
            start_index = 0
            out_ext = ".RCP"
        elif data_len >= 9 and input_data[2:9] == HEADER_SIZE_RCP: # 3〜9バイト目を判定
            target_size = input_data[0] | (input_data[1] << 8)  # リトルエンディアンでサイズ取得
            start_index = 4                                     # インデックス4（5バイト目）から開始
            out_ext = ".RCP"
        else:
            print(f"スキップ（ヘッダ条件不一致）: {filename}")
            return

    # 【.CMP の場合】
    elif ext_upper == ".CMP":
        if data_len >= 5 and input_data[:5] == HEADER_5B_CMP:
            start_index = 0
            out_ext = ".CM6"
        elif data_len >= 9 and input_data[2:9] == HEADER_SIZE_CMP: # 3〜9バイト目を判定
            target_size = input_data[0] | (input_data[1] << 8)
            start_index = 4
            out_ext = ".CM6"
        else:
            print(f"スキップ（ヘッダ条件不一致）: {filename}")
            return

    # 【.GSP の場合】
    elif ext_upper == ".GSP":
        out_ext = ".GSD"
        if data_len >= 4 and input_data[2:4] == b'\x00\x00':
            target_size = input_data[0] | (input_data[1] << 8)
            start_index = 4
        else:
            start_index = 0

    # 【.DAT の場合】
    elif ext_upper == ".DAT":
        # 条件1: 先頭5バイトが FFh 52h 43h 4Dh 2Dh
        if data_len >= 5 and input_data[:5] == HEADER_5B_RCP:
            start_index = 0
            out_ext = ".RCP"
        # 条件2: 先頭5バイトが FFh 43h 4Fh 4Dh 45h
        elif data_len >= 5 and input_data[:5] == HEADER_5B_CMP:
            start_index = 0
            out_ext = ".CM6"
        # 条件3: 3〜9バイト目が 00h 00h FFh 52h 43h 4Dh 2Dh
        elif data_len >= 9 and input_data[2:9] == HEADER_SIZE_RCP:
            target_size = input_data[0] | (input_data[1] << 8)
            start_index = 4
            out_ext = ".RCP"
        # 条件4: 3〜9バイト目が 00h 00h FFh 43h 4Fh 4Dh 45h
        elif data_len >= 9 and input_data[2:9] == HEADER_SIZE_CMP:
            target_size = input_data[0] | (input_data[1] << 8)
            start_index = 4
            out_ext = ".CM6"
        else:
            print(f"スキップ（ヘッダ条件不一致）: {filename}")
            return

    # --- 4. 出力先フォルダとパスの準備 ---
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    output_dir = os.path.join(script_dir, "output")
    os.makedirs(output_dir, exist_ok=True)

    output_filepath = os.path.join(output_dir, root + out_ext)

    # --- 5. 解凍処理本体 ---
    buffer = bytearray()
    input_index = start_index
    stop_decompression = False

    while input_index < data_len and not stop_decompression:
        flag = input_data[input_index]
        input_index += 1
        
        for bit_idx in range(8):
            if input_index >= data_len or stop_decompression:
                break
                
            flag_bit = (flag >> bit_idx) & 0x01
            
            if flag_bit == 1:
                b = input_data[input_index]
                input_index += 1
                buffer.append(b)
                
                if target_size is not None and len(buffer) >= target_size:
                    stop_decompression = True
                    break
                
            else:
                if input_index + 1 >= data_len:
                    break
                
                c1 = input_data[input_index]
                c2 = input_data[input_index+1]
                input_index += 2
                
                addr = ((c2 & 0x0F) << 8) | c1
                count = c2 >> 4
                
                addr += 0x12
                count += 3
                
                addr = addr & 0xFFF
                
                current_size = len(buffer)
                base_addr = current_size & 0xF000
                src_addr = base_addr | addr
                
                if current_size <= 0xFFF and src_addr > current_size:
                    src_addr -= 0x1000
                elif current_size > 0xFFF and src_addr > current_size:
                    src_addr -= 0x1000

                for _ in range(count):
                    if src_addr < 0:
                        buffer.append(0x00)
                    elif src_addr < len(buffer):
                        buffer.append(buffer[src_addr])
                    else:
                        buffer.append(0x00)
                    
                    src_addr += 1
                    
                    if src_addr == 0:
                        src_addr = len(buffer) & 0xF000

                    if target_size is not None and len(buffer) >= target_size:
                        stop_decompression = True
                        break

    # --- 6. ファイルへの出力 ---
    with open(output_filepath, 'wb') as f:
        f.write(buffer)

    if target_size is not None:
        print(f"解凍完了（指定サイズ {target_size} bytes で停止）: {filename} -> {output_filepath}")
    else:
        print(f"解凍完了（通常処理）: {filename} -> {output_filepath}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("【使い方】")
        print("このスクリプト（またはEXE）のアイコンに、解凍したいファイルをドラッグ＆ドロップしてください。\n")
        input("Enterキーを押すと終了します...")
        sys.exit()

    for target_path in sys.argv[1:]:
        if os.path.isfile(target_path):
            try:
                decompress(target_path)
            except Exception as e:
                print(f"エラー発生 ({os.path.basename(target_path)}): {e}")
        else:
            print(f"スキップ（ファイルではありません）: {target_path}")

    print("\nすべての処理が終了しました。")
    