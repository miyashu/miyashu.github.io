# NM (Next Maintenance) Manual

v0.99j (evaluation version, 2026-11-22). NM is a file maintenance tool with two screens, left and right, for MSX-DOS2 and Nextor.
The name NM stands for Next Maintenance: a file maintenance tool with another screen next to the first.

NM takes over the operation of MultiMente (MM, by MOGU) and is newly written. It does not use any of MM's program code.
**MM's settings can be used as they are**: NM reads MM's MMRET.DAT and MMMCR.DAT, and the lines of MM.CFG can be copied into NMCFG.DAT.

This is an evaluation version, so some parts have not been fully tested. **On an important disk, make a backup before you try any operation that writes to the disk.**
In particular, try [Y] (writing the order) and [P] (partition switching) on a disk that you can afford to lose.
The differences from MM are described in the separate document "MM-COMPARE_en".

## Using NM without kanji (ANK mode)

NM can show Japanese (Shift-JIS) full-width characters, but it does not need to. With `KANJI = OFF` in NMCFG.DAT, NM runs in "ANK mode": every byte, including characters of 80h and above, is shown as one character with the machine's own font. All of NM's own messages on the screen are in English.

1. The default is `KANJI = AUTO`. On a machine that is not a Japanese model, NM already runs in ANK mode without any setting.
2. On a Japanese machine (including an emulated one), switch kanji off yourself. NMCFG.DAT is a text file in the same directory as NM.COM. The one in the package has every line commented out with `;`. Add this line (or uncomment the existing line and change it):

   ```
   KANJI = OFF
   ```

3. Check which mode is running. Look at the last character of the title at the top left of the frame: `NM v0.99j_A` means ANK only, `NM v0.99j_K` means kanji.

In ANK mode NMFONT.DAT and NMUNI.DAT are not used and are not needed.

| File | ANK mode | Kanji |
|---|---|---|
| NM.COM | needed | needed |
| NM.OVL | needed | needed |
| NMCFG.DAT | only if you want settings | only if you want settings |
| NMFONT.DAT | not needed | used |
| NMUNI.DAT | not needed | used |

Two more points:

- In ANK mode, characters in long file names that are not ASCII appear as `?`.
- [¥] in this manual is the key of character code 5Ch: the backslash key on keyboards that are not Japanese.
- Keys such as [SHIFT]+[1]-[8] depend on the keyboard layout. If a key does not do what this manual says on your keyboard, see `KEYMAP` in chapter 9 (settings).

---

## 1. Requirements

| Item | Description |
|---|---|
| Machine | MSX2 or later, 128KB VRAM, 128KB or more of mapper RAM |
| OS | MSX-DOS2, Nextor (checked on 2.1 and 3.0). On MSX-DOS1, NM shows a message and exits |
| Kanji | The machine's kanji ROM, or the supplied NMFONT.DAT. If the MSX-View kanji ROM (View font) is present, NM uses it |

NM has been tested mainly on the turbo R. It is built to run on Z80 machines and on 128KB machines too, but these have had little testing.

## 2. Files

Put all the files in the same directory.

| File | Description | If missing |
|---|---|---|
| NM.COM | The program | — |
| NM.OVL | The rest of the program (loaded when needed). It must have been built at the same time as NM.COM | The viewer, file operations and so on cannot be used |
| NMFONT.DAT | 8-dot font for showing kanji in the list (Misaki font) | Kanji ROM characters are reduced and shown |
| NMUNI.DAT | Unicode → Shift-JIS table. Used for long file names and UTF-8 text | Kanji become `?` |
| NMCFG.DAT | Settings (chapter 9). In the supplied file every line is a comment | NM runs with the default values |
| NMRET.DAT or MMRET.DAT | Sets the command run by [RETURN] for each extension (chapter 10) | [RETURN] opens the built-in viewer |
| NMMCR.DAT or MMMCR.DAT | Key macros for [GRAPH] (chapter 10) | [GRAPH] does nothing |

MMRET.DAT and MMMCR.DAT have the same format as in MM. MM's files can be used as they are (they are not included in the package).
If you do not have them, download MultiMente from the GIGAMIX site ([https://www.gigamix.jp/](https://www.gigamix.jp/)); they are inside it.
If you want different contents for NM only, make files named NMRET.DAT and NMMCR.DAT in the same format. These are used first.

If the environment variable `%MM%` is set to a directory, the DAT files are read from there. Files that are not there, and all files when the variable is not set, are read from the same place as the program.
NMRET.DAT and NMMCR.DAT are searched for in this order: the NM name in `%MM%`, the NM name in the program's location, the MM name in `%MM%`, the MM name in the program's location.

### Environment variables

| Variable | Use |
|---|---|
| `%SHELL%` | The shell used to run external commands. If it is not set, NM looks for COMMAND2.COM on the boot drive, then on the drive that holds the program, then on A: |
| `%MM%` | The directory where the DAT files are kept |
| `%HOME%` | The destination of the [/] key |
| `%FONT0808%` | A font file for the half-width characters (8×8 dots, the characters from 20h, 1792 bytes: the form CHGFONT and similar tools use). When it is set, NM uses it in place of the machine's font. As with the machine's font, the left 6 dots are shown |

## 3. Starting and quitting

```
NM [left side] [right side]
```

With no arguments, NM shows the drive and directory it was started from on both the left and the right.
If you write locations after the name, the left side and then the right side start there. You can leave out the right side only.

| Form | Meaning |
|---|---|
| `A:` | The current directory of that drive |
| `A:\UTILS` | Drive and directory |
| `\UTILS` | A directory on the drive NM was started from |
| `UTILS` | A directory below the directory NM was started from |

```
NM A: B:            left is A:, right is B:
NM A:\UTILS         left is A:\UTILS, right is the starting location
```

A side for which you wrote a drive that does not exist, or something that is not a directory, becomes the starting location.
When NM comes back after running an external command, these arguments have no effect (it starts from the directory at that time).

Quit with [Q] or [ESC]. [ESC] asks for confirmation. When NM quits, the drive and directory of the side that was active become the current ones of DOS.

## 4. Screen

```
 Attr Copy Dele Edit Find maKe Log Move Quit Run Sort View Wild eXec   ← menu line
+ NM v0.99j_K ----------------------------- 2026-11-14 19:36:05 +
| Path: A:\                                                        |  path of the active side
| Name: COMMAND2.COM                                               |  file under the cursor (its long name, if it has one)
| Size:     15708  Date: 2026-11-10  Time: 12:00:00  Attr: ----A   |
+ A:\ ----------------------------+ A:\DEST -----------------------+
| DEST         <dir> 26-11-10 12:00| ..           <dir> 26-11-10 12:00|
|*COMMAND2.COM 15708 26-11-10 12:00| LONGFI~1.TXT    11 26-11-10 12:00|  list (17 lines per side)
|  …                               |  …                               |
|  18 files    2 marked 1K +N     |   6 files    0 marked            |  file count, mark count and total, sort
|A:REALLABEL  Free:  545K/  713K  |A:REALLABEL  Free:  545K/  713K  |  drive, volume name, free/total space
 F1:help  TAB:side  F3:same dir  F4:open there  F5:one/two sides  Q:quit  ← guide and messages
```

- The name and version appear at the top left of the frame (`NM v0.99j_K`). The last character is `K` when NM handles kanji, and `A` when it is ANK only (`KANJI = OFF`).
  When you report a problem, please include this text.
- The left and right halves are called "sides". The side with the white bar (the cursor) is the active side.
- The bottom line is a guide to the keys. While [SHIFT] is held down, it changes to a guide to the keys used together with [SHIFT] ([TAB], [SPACE], [F8]-[F10] = [F3]-[F5] with [SHIFT]).
- A `*` at the left edge of the list is a mark.
- The line below the list shows the total of the marked files in KB (for example `46 marked 372K`). You can compare it with the free space of the copy destination.
  The value is the total number of bytes rounded up to a whole KB, and the contents of directories are not added. If the clusters of the destination are large, the files actually take more space than this.
- The `+N` after it is the sort state (`+` ascending, `-` descending; N name, S size, D date, E extension).
  `*` means the list has been reordered by hand and not yet written to the disk. `W` means a display filter is in effect.
- The free space is not shown when a Z80 machine is looking at a large drive (because counting it takes time). This can be changed in the settings.

### Switching the display

| Key | Description |
|---|---|
| [F5] | Show only the active side on the whole screen / go back to two screens |
| [F8] ([SHIFT]+[F3]) | Switch between detail view and names-only view (both sides) |
| [F9] ([SHIFT]+[F4]) / [F10] ([SHIFT]+[F5]) | Switch the left side only / the right side only |

Names-only view has 2 columns per side (34 entries) with two screens, and 5 columns (85 entries) with one screen.

## 5. Keys

[F1] shows a list of the keys on the screen.

### Moving

| Key | Description |
|---|---|
| [↑][↓] | Move the cursor. With [SHIFT]: top / bottom. While the key is held down, the information lines at the top (Name, Size and so on) are not rewritten; they are when the key is released |
| [←][→] | Move one page (in names-only view, move between columns). With [SHIFT]: always one page. In detail view the list moves a page too, so the cursor stays on the same line of the screen |
| [CTRL]+[←][→] | Go to the left side / the right side (nothing happens when you are already there). With `PANEKEY = SHIFT`, [SHIFT]+[←][→] does this and [CTRL]+[←][→] becomes "always one page" |
| [CTRL]+[E][X][S][D] | Up, down, left, right (diamond cursor). [CTRL]+[R][C][F][A] are the same as with [SHIFT] |
| [RETURN] | Enter a directory. On a file: run it (see "Running" below) |
| [BS] / [.] | Go to the parent directory |
| [¥] | Go to the root |
| [/] | Go to the `%HOME%` directory |
| [H] | Type a path and go there (`B:\DIR`, `\DIR`, or a name relative to the current location) |
| [L] | Choose a drive (a letter A to H) |
| [1]-[8] | Change to drive A: to H: |
| [0] | Read both sides again from the disk and show them from the top (the volume name and free space too). Press it after you change a disk or card |
| [SHIFT]+[0] | Switch the file colours between "by attribute" and "by extension" (see "Colours by extension" in chapter 9) |
| [F] | Search by name (wildcards allowed). The cursor moves to the next match |

### Two-screen operations

| Key | Description |
|---|---|
| [TAB] | Change the active side |
| [F3] | Set the other side to the same directory as this side |
| [F4] | Open the directory under the cursor on the other side |
| [SHIFT]+[1]-[8] | Change the drive of the other side to A: to H: |
| [SHIFT]+[TAB] | Swap left and right. The cursor position and the order move together with the directory (marks are cleared) |

[SHIFT]+digit is recognised by the characters `!` `"` `#` … of the Japanese keyboard layout. If your layout is different, use `KEYMAP` in chapter 9.

### Marks

| Key | Description |
|---|---|
| [SPACE] | Mark / unmark and move one down |
| [SHIFT]+[SPACE] | Mark / unmark the file under the cursor (the cursor does not move) |
| [SELECT] | Mark all files (if there are marks, clear them all) |
| [SHIFT]+[SELECT] | Invert all marks |
| [CTRL]+[SELECT] | Invert the marks from the cursor downwards |
| [SHIFT]+[W] | Mark the files from the cursor downwards that match a wildcard |

The three [SELECT] keys do not mark directories.

### File operations

If there are marks, the operation applies to all marked entries; if there are none, it applies to the file under the cursor. A directory is handled together with its contents.

| Key | Description |
|---|---|
| [C] | Copy. Type the destination (the input starts with the path of the other side, so pressing [RETURN] as it is copies to the other side) |
| [M] | Move. The destination is entered as for [C] |
| [D] | Delete. Asks for confirmation. For a directory that has contents, the confirmation shows the number of entries |
| [N] | Rename |
| [K] | Make a directory |
| [A] | Change the attributes and the date and time. [R][H][S][A] toggle the attributes, [D] enters the date and time, [RETURN] sets them |

- When a file of the same name exists, choose [Y] overwrite / [N] skip / [T] only if newer / [C] change the name / [ESC] abort.
  [Y] [N] [T] with [SHIFT] apply to all the following files. With [C], type the name to use at the destination (if that name also exists, NM asks again).
- Before deleting or overwriting a read-only file, NM asks for confirmation.
- During a copy, [ESC] interrupts it.
- The destination file of a copy is not given a long file name (it has only an 8.3 name).
- When a file that has a long file name is deleted, renamed or moved, the long-name part left on the disk is also erased
  (otherwise the name would look broken in Windows, or MSX-DOS2 would become unable to delete the directory).
- After an operation, only the side whose contents changed is read again (for copy, the destination; for delete and rename, the active side; for move, both).

### Sorting and reordering

| Key | Description |
|---|---|
| [S] | Sort the active side. Then press [N] name, [S] size, [D] date, [E] extension, [O] none. Press the letter with [SHIFT] for descending order |
| [SHIFT]+[S] | Sort both sides |
| [DEL] | Reorder mode (see "Reorder mode" below) |
| [Y] | Write the order of the current list to the directory on the disk |
| [SHIFT]+[Y] | Write the order of both sides to their directories |

- [S] and [DEL] reorder only what is on the screen. The disk does not change until you press [Y].
- In a sort, directories come before files. `..` stays at the top.
- When you reorder with [DEL], the sort of that side becomes "none" and a `*` appears on the line below the list. This order is lost when that side is read again.
- To keep NEXTOR.SYS and similar files at the top and sort the rest, sort with [S], take those files out with [DEL] and put them back at the top, then press [Y].

**Reorder mode ([DEL])**

This works the same way as in MM. You take files out of the list and put them back where you want them.

| Key | Description |
|---|---|
| [DEL] | Take the file under the cursor out of the list. The files taken out are lined up in the 3 lines above the list (where Path, Name and Size normally appear). Up to 18 files |
| [INS] | Put the file that was taken out last, among the files taken out, in front of the file under the cursor. The cursor lands on the file just put in, so pressing the key repeatedly restores the order the files had before they were taken out |
| [↑][↓][←][→] | Move the cursor (the same with [SHIFT]). The cursor can go one line below the last file (to put files at the end) |
| [ESC] | If files taken out remain, give up the reordering and read that side again |

- Pressing [DEL] in the list takes out the file under the cursor and enters this mode.
- The mode ends when all the files taken out have been put back.
- If you press [DEL] several times without moving the cursor and then press [INS] the same number of times, the original order is restored.
- `..` cannot be taken out. Nothing can be put in front of `..` either.
- While in this mode, the other keys have no effect. The list on the other side stays as it is.

**Cautions for [Y]**

- The bottom line turns into a red warning, and NM writes only when you press [Y] once more. Any other key does nothing.
- The directory is rewritten directly. If the power is cut or the disk is removed during the write, the directory may be damaged.
- NM can handle directories of up to 192 slots (192 files without long names; fewer when there are long names).
  A larger directory is refused and nothing is written.
- If the write fails, NM writes back the original contents and then shows a message asking you to check the disk.
- Entries that are not in the list (such as files hidden by the display filter) follow at the end in their original order.

### Files to show

| Key | Description |
|---|---|
| [W] | Display filter. A wildcard such as `*.TXT` or `A*`, or `/string` (names that contain that string). [RETURN] with nothing typed clears it. It applies to both sides |
| [CTRL]+[W] | Whether to show hidden files and system files |

Directories are shown regardless of the filter.

### Running

| Key | Description |
|---|---|
| [RETURN] | Run according to MMRET.DAT (chapter 10). If no line matches, the built-in viewer |
| [SHIFT]+[RETURN] / [CTRL]+[RETURN] / [SHIFT]+[CTRL]+[RETURN] | Start `S_TOOL` / `C_TOOL` / `SC_TOOL` of NMCFG.DAT |
| [V] | Built-in viewer (chapter 6) |
| [SHIFT]+[V] | External viewer (`PAGER2`, default `VF $C`) |
| [E] | Open the file under the cursor in the editor (`EDITOR`, default `KID $F`). An input line appears with the file name in it: just press [RETURN]. Options for the editor can be added after the name (the whole line becomes `$F`) |
| [SHIFT]+[E] | Type a file name and open a new file in the editor |
| [R] | Shows an input line containing the name of the file under the cursor. For .COM and .BAT a space is added after the name, and you can add arguments there. For other files and for directories only the name is entered and the cursor is at the start (you can write a command in front). [RETURN] runs it, and when it ends NM waits for a key |
| [X] | Type a command line and run it. Macros (chapter 10) can be used |
| [GRAPH] | Show the list of macros of MMMCR.DAT in a window. Press one key to run a macro, [ESC] to close |

When an external command is run, NM starts again after the command ends. The drives and directories of the left and right sides, the cursor position and the active side are restored to what they were before the run. Marks, the order and the filter on the files shown are not restored. (During the run, the locations are held in the environment variables `NM_L`, `NM_R`, `NM_A` and `NM_C`. NM reads them when it starts again and deletes them.)

During the run, only a small part of NM (512 bytes) stays in memory.

- If the first word of the command is a .COM file, NM starts that file directly. The memory available to the program (TPA) is only 512 bytes less than when it is started from the prompt.
  The file is searched for in the same order as the shell does: if a path is written, only there; if not, the current directory, then the directories of `%PATH%`.
- Everything else is run through the shell (`%SHELL%`): the shell's own commands such as DIR and TYPE, batch files, lines that contain `<` `>` `|` `%`, and anything that was not found.
  In this case the shell also stays in memory, so the TPA is a further 1 to 1.5KB smaller.
- When several commands are run at once (the macros `$R` and `$T`), everything after a command that went through the shell also goes through the shell.

### Others

| Key | Description |
|---|---|
| [I] | Disk information (volume name, free space, total space, cluster size) |
| [CTRL]+[V] | Change the volume name. The input starts with the current name for you to edit. [RETURN] with nothing typed erases the name. The name is up to 11 characters and has no extension separator (one full-width character counts as 2 characters). The input line accepts no more than 11 characters |
| [P] | Partition switching (chapter 7) |
| [G] / [SHIFT]+[G] | Song title of MGSDRV or MCPLAYER / MGSDRV song list (chapter 8) |
| [F1] | Key help |
| [Q] | Quit |
| [ESC] | Quit (a confirmation window appears. [Y] or [RETURN] quits, [N] or [ESC] goes back) |

### Text input

When you type a name or a command, when NM asks for confirmation and when it reports an error, a window opens in the centre of the screen. When you press a key the window disappears and the display under it is restored.
The key guide and the progress of copies and other operations appear on the bottom line as before.

These keys can be used on the input line. It holds up to 60 characters.

| Key | Description |
|---|---|
| [←] [→] | Move the cursor |
| [BS] | Delete the character to the left of the cursor |
| [DEL] | Delete the character at the cursor |
| [INS] | Switch between insert and overwrite. In insert the cursor is a line under the character; in overwrite it is the size of a character |
| [CTRL]+[SPACE] | Start / stop kanji conversion (MSX-JE) |
| [RETURN] / [ESC] | Accept / cancel |

Input starts in insert. A full-width character is handled as one character. In [X] and [R] the letters you type are passed as they are (lower case stays lower case). In other inputs they become upper case.
Where you type the name of a file or directory, a name that does not fit in 8 + 3 characters is not accepted (one full-width character counts as 2 characters). After a window tells you so, you return to the input line and can correct it.

#### Kanji conversion (MSX-JE)

On models with built-in MSX-JE (FS-A1ST, FS-A1GT and others), or when an MSX-JE cartridge is present, kanji conversion can be used on the input line.

- Start it with [CTRL]+[SPACE]. `MSX-JE` appears on the bottom edge of the window frame, and the line below the input line becomes the conversion line.
- Operation is the usual MSX-JE procedure: type the reading, convert with [SPACE], confirm with [RETURN]. The confirmed characters are entered at the cursor position of the input line.
  When you confirm one phrase at a time, the confirmed part moves to the input line and the candidates for the remaining phrases appear on the conversion line.
- Press [CTRL]+[SPACE] again to stop. When there are no characters being converted, [RETURN] and [ESC] work as keys of the input line, so the input window closes and MSX-JE ends too.
- When `KANJI = OFF`, and when there is not enough free space in the upper part of memory (for example when there are many resident programs), pressing [CTRL]+[SPACE] does not start it.

## 6. Built-in viewer

[V] shows the file under the cursor. There is no limit on the size (the number of lines is up to about 2500).

| Key | Description |
|---|---|
| [SPACE] / [BS] | Next page / previous page |
| [SHIFT]+[SPACE] / [SHIFT]+[BS] | Half a page at a time |
| [↑][↓] | One line at a time |
| [←][→] | 10 pages at a time |
| [SHIFT]+[←][→] | 5 pages at a time |
| [H] / [T] | Top / end |
| [TAB] | Tab width (8 / 4) |
| [K] | Change how full-width characters are shown (the 3 kinds below). In the hex dump: show / do not show full-width characters in the character column |
| [U] | Switch between UTF-8 and Shift-JIS (the same in the hex dump). Which one is being used is shown at the right end of the top line as `[SJIS]` / `[UTF8]`. When each byte is shown as ANK (at the start of the hex dump, and when `KANJI = OFF`), it is `[ANK]` |
| [X] | Hex dump / text |
| [RETURN] / [ESC] | Exit |

The hex dump starts in ANK display. Pressing [K] shows full-width characters and makes [U] work.
When `KANJI = OFF`, [K] and [U] of the viewer do not work and do not appear in the key guide.

- **Character codes**: Shift-JIS and UTF-8. NM looks at the first 1KB and decides automatically. If it is wrong, switch with [U].
  UTF-8 is shown using NMUNI.DAT. Characters that do not exist in Shift-JIS become `?`.
- **How full-width characters are shown** ([K] cycles through them. The value at start-up can be set with `VIEW`)

  | Kind | One screen | Characters |
  |---|---|---|
  | 8-dot lines | 80 columns × 25 lines | Kanji ROM characters reduced to 12×8. Default |
  | 8-dot lines (Misaki) | 80 columns × 25 lines | Characters of NMFONT.DAT (the same as the list) |
  | 12-dot lines | 80 columns × 17 lines | Kanji ROM characters reduced to 12×12 |

  If a View font is present, the 1st and the 3rd use its 12×8 and 12×12 characters (easier to read than reduced ones).
- **Read-ahead**: After showing the page, NM reads on through the rest while no key is pressed. When it finishes, the line count on the first line changes from `?` to the actual number, and [T] works at once.
- **Hex dump**: 16 bytes per line. [←][→] move 1000h bytes at a time, and 800h bytes at a time while [SHIFT] is held. The character column at first shows only ASCII and half-width kana. Pressing [K] shows full-width characters too (whether Shift-JIS or UTF-8 is decided in the same way as for text display, and can be changed with [U]). When a full-width character crosses a line boundary, it is shown as one character at the end of the first line, and the start of the next line is blank by that amount.

## 7. Partition switching ([P])

Assigns a different partition to the drive of the active side. Choose from the list with the cursor or a digit key. [ESC] cancels.

| Environment | Description |
|---|---|
| Nextor | Lists the partitions of the devices connected to the same driver as that drive. The current one is marked `(now)`, and one already assigned to another drive shows that drive name |
| MEGA-SCSI on MSX-DOS2 | Lists the contents of MEGASCSI.TBL in the root of that drive. The hidden area of the ESE ASPI format (number 0) is not shown |

- **The drive that holds the NM program cannot be switched** (NM refuses). If the NM files were not on the partition switched to, NM could not continue.
- The list holds up to 14 entries.
- On Nextor, if you choose a partition already assigned to another drive, a Nextor error appears and nothing changes.
- On a drive that is not a target, such as a floppy, NM only says so.

## 8. Working with MGSDRV and MCPLAYER

This can be used when MGSDRV is resident. MGSDRV does the playing, so the music continues while you operate NM and after NM quits.

| Key | Description |
|---|---|
| [RETURN] (on a .MGS file) | Load that song and play it |
| [G] | Show the title of the current song. Pressing [S] there stops the playing |
| [SHIFT]+[G] | Show the list of loaded songs and play the one you choose |

Song data can be up to 16KB. When MGSDRV is not resident, [RETURN] on a .MGS file is handled as for an ordinary file.

### MCPLAYER (Micro Cabin songs)

When the resident MCPLAYER is there (`MCPLAYER /Z` makes it resident), .MCM songs can be played in the same way.

| Key | Description |
|---|---|
| [RETURN] (on a .MCM file) | Load that song and play it |
| [G] | While MCPLAYER is playing: show the title of the song (or, without one, its file name and the name of the driver). Pressing [S] there stops the playing |

- **Driver file (.DRV)**: put it in the directory of the song or in the directory of NM.COM. NM looks for `xxx.DRV` with the first 5, 4, then 3 characters of the song's file name (for XAK201.MCM: XAK20.DRV, XAK2.DRV, XAK.DRV). If none is found, it looks through the .DRV files in the directory of the song for one that knows the song (for songs that were renamed).
- **Song list (.LST)**: if the directory of the song has a song list of MCPLAYER (`XAK.LST` and the like), NM takes the title, the driver and the number of loops from it. The title is shown as "game / title": in Japanese when NM handles kanji, in English when it is ANK only. A driver named in the list is used before the ones found by the file name.
- **Size**: a song can be up to 6KB.
- **When MGSDRV is resident too**: starting a song with one of them stops the other.
- When MCPLAYER is not resident, [RETURN] on a .MCM file is handled as for an ordinary file.

## 9. Settings (NMCFG.DAT)

It is a text file. Write `item = value` on each line; everything from `;` onwards is a comment. Item names may be in upper or lower case.
The syntax is the same as MM.CFG, so lines of MM.CFG can be copied. Unknown items are skipped. NM reads up to the first 6143 bytes.

| Item | Description | Default |
|---|---|---|
| `MODE` | Display at start-up. 1 = detail view, 2 = names-only view | 1 |
| `MODE2` | File colours at start-up. 0 = by attribute, 1 = by extension | 0 |
| `PANEKEY` | The key that, pressed with [←][→], goes to the other side. CTRL or SHIFT. The other one becomes the "always one page" key | CTRL |
| `VIEW` | Full-width characters in the viewer. 1 = 8-dot lines, 2 = 8-dot lines (Misaki), 3 = 12-dot lines | 1 |
| `KANJI` | Whether to handle full-width characters. ON / OFF / AUTO. AUTO means ON if the machine is a Japanese model | AUTO |
| `VIEWFONT` | Whether to use the View font. ON / OFF | ON |
| `FREE` | Display of free space. AUTO (not shown for a large drive on a Z80) / ON / OFF | AUTO |
| `LFN` | Whether to show long file names on the Name line. ON / OFF. Set it to OFF if it is slow on floppies | ON |
| `ATTR_H` / `ATTR_S` | Whether to show hidden files / system files. 1 / 0 | 1 |
| `COL_BACK` etc. | Colours (table below). Write red, green and blue as 3 digits of 0 to 7 | See the table below |
| `KEYMAP` | Key replacement. Pairs of 2 characters, "the key you press, the key it stands for", separated by spaces, up to 8 pairs. It works only on the list screen | None |
| `EDITOR` | The editor for [E] | `KID $F` |
| `PAGER` / `PAGER2` | [V] / [SHIFT]+[V] | `$V` / `VF $C` |
| `S_TOOL` / `C_TOOL` / `SC_TOOL` | [RETURN] with [SHIFT] / [CTRL] / [SHIFT]+[CTRL] | `KID $C` / `VF $C` / `VF $C` |
| `TOOL` | [RETURN] when no line of MMRET.DAT matches | `$V` (built-in viewer) |
| `SCSAVER` | The program started as the screen saver. If not written, the built-in one | (built-in) |
| `SC_TIME` | Time until the screen saver starts. 0 to 255, about 4.3 seconds per unit. 0 means "never start" | 43 (about 3 minutes) |

- **`KANJI = OFF` (ANK only)**: Characters of 80h and above are also shown one byte at a time with the machine's font. In long file names, anything other than ASCII becomes `?`.
  NMFONT.DAT and NMUNI.DAT are not used (they need not be present). On a machine that is not a Japanese model, NM behaves this way with AUTO left as it is.
- **`KEYMAP` example**: On a layout where [SHIFT]+[2] gives `@`, write `KEYMAP = @"` to use [SHIFT]+[2] as "set the other side to B:".

### Colours

| Item | Where it is used | Default |
|---|---|---|
| `COL_BACK` | Background. The key letters on the menu line also have this colour | 111 |
| `COL_TEXT` | Values, read-only files, the cursor bar | 777 |
| `COL_LINE` | Frame lines | 345 |
| `COL_HEAD` | Headings, the line below the list | 456 |
| `COL_FILE` | Files, paths | 666 |
| `COL_DIR` | Directories | 357 |
| `COL_HID` | Hidden files, system files | 333 |
| `COL_KEY` | Background of the key letters on the menu line | 741 |
| `COL_BAR` | Text on the cursor bar and on the bottom line | 000 |

The supplied NMCFG.DAT contains the MultiMente colour scheme (113, 777, 077, 577, 770, 577, 440, 070, 000) as comment lines. Remove the `;` at the start of those lines to get that scheme.

The colours are set at start-up. On quitting and before running an external command, they are returned to the power-on colours.

### Colours by extension

Press [SHIFT]+[0], or write `MODE2 = 1`, and the colour of a file is decided by its extension. Files whose extension is not in the table, and directories, keep the colours they have in the "by attribute" display.

If you write nothing, the extensions are grouped as in MultiMente.

| Colour | Extensions |
|---|---|
| 770 (yellow) | COM, BAT |
| 373 (light green) | MGS, MPK |
| 347 (blue) | PMA, LZH, ARC, ARK, DES, ISH, ZIP, FNS |
| 700 (red) | BAS |
| 077 (cyan) | PCK, PCM |
| 707 (magenta) | SC?, SR?, GRP, PIC, MAG, PI, Q4, JPG, MKI, MSA, BMP, LAP, MAX, GIF |

To choose your own, write `EXT` lines in NMCFG.DAT. Give a colour (three digits, as for `COL_xxxx`), then the extensions that get that colour, separated by spaces.

```
EXT = 770 COM BAT
EXT = 700 ROM DSK
EXT = 373 MGS IMS VGM
```

- Up to 6 `EXT` lines (6 colours) and up to 40 extensions in total. Anything beyond that is ignored.
- If you write even one `EXT` line, the table above is not used; only your lines count.
- `?` matches any one character (`SC?` matches both SC5 and SC7).
- A change made with [SHIFT]+[0] goes back to the `MODE2` setting when an external command is run.

## 10. MMRET.DAT, MMMCR.DAT (NMRET.DAT, NMMCR.DAT) and macros

### File size limits

The DAT files are read up to the following sizes. Lines written beyond that are not read (no notice is given).

| File | Size read |
|---|---|
| NMCFG.DAT | 6143 bytes |
| MMRET.DAT, NMRET.DAT | 8191 bytes |
| MMMCR.DAT, NMMCR.DAT | 7167 bytes |

The supplied NMCFG.DAT is about 2.6KB, and the MMRET.DAT and MMMCR.DAT that come with MultiMente are 2 to 3KB.

### MMRET.DAT (commands run by [RETURN])

```
.ext<TAB>command<TAB>comment
:filename.ext<TAB>command<TAB>comment
```

- Only lines that begin with `.` or `:` are read. The separator is TAB. `?` can be used in the extension.
- The lines are examined from the top, and the first one that matches is used.
- **Several commands for one extension**: If you separate commands with `;` within one line, or write several lines for the same extension, [RETURN] shows a menu to choose from (up to 9 entries).
  Choose with a digit key, or with [↑][↓] and [RETURN].

  ```
  .TXT<TAB>$V;KID $C;TYPE $C$K
  ```

  MM uses only the first line, so if you write several lines, the same file can be shared with MM.

### MMMCR.DAT (macros for [GRAPH])

```
key)command<TAB>'text shown in the list<TAB>;comment
```

The keys are the digits (0-9) and the letters (A-Z), 36 in all. Pressing [GRAPH] opens a window in which the 36 are laid out in fixed positions (0-H in the left column, I-Z in the right column). A key with nothing registered shows only its symbol. If there are two lines for the same key, the one written first is used. The text shown in the list can be up to 34 characters.

### Macros

| Macro | Description |
|---|---|
| `$C` / `$X` | Name of the file under the cursor (with / without extension) |
| `$D` | Drive name of the active side |
| `$P` | Path of the active side (without the drive name) |
| `$O` / `$o` | Path of the other side (with the drive name) / drive name of the other side |
| `$T` / `$t` | Run once for each marked file (with / without extension) |
| `$M` / `$m` | Run with the marked files gathered on one line |
| `$K` / `$k` | Wait for a key after the run |
| `$R` | New line (to write commands one after another) |
| `$V` | View with the built-in viewer (write it at the start of the line) |
| `$F` | The file name typed in (used in `EDITOR`) |
| `$$` / `$;` | `$` / `;` |

After expansion, the commands can be up to about 126 characters in total.

## 11. Long file names and kanji

- **Long file names (LFN)**: A long name given in Windows or elsewhere is shown on the Name line when the cursor rests on the file (while the cursor is kept moving, the 8.3 name is shown). It is display only; long names cannot be typed or changed.
  The list and the operations use the 8.3 names. FAT12 and FAT16 are supported.
- **Kanji file names**: They are shown in kanji in the list, the path and the Name line. The characters are chosen in this order.

  1. The 12×8 characters of the View font (the MSX-View kanji ROM)
  2. NMFONT.DAT (Misaki font, 8×8)
  3. Kanji ROM characters reduced to 12×8

- **View font**: If any of the following is present, it is used automatically. If you do not want to use it, set `VIEWFONT = OFF`.

  | Kind | List and 8-dot lines | 12-dot lines |
  |---|---|---|
  | The ROM cartridge supplied with MSX-View | JIS level 1 | JIS levels 1 and 2 |
  | Extended View font (placed in an ESE RAM or similar) | JIS levels 1 and 2 | JIS levels 1 and 2 |
  | Built into the FS-A1GT | JIS level 1 | JIS level 1 |
  | A ROM fitted to the FS-A1ST | Depends on the ROM fitted | Same as left |

  Characters that the View font does not have are shown by methods 2 and 3 above.

## 12. When you change a disk or card

NM does not check by itself whether a disk or SD card has been changed. The screen keeps the contents from the last time it was read.
After changing one, press [0]. NM reads the lists of both sides, the volume name and the free space again, and shows both from the top.
At this time it also makes DOS discard the disk contents that DOS remembers.

- It is DOS (and the driver) that notices the change. The next time that drive is read or written, DOS treats it as a new disk.
  Whether a card change is reported to DOS depends on the driver of the interface.
- Even before you press [0], if you change directory or do a file operation, the disk is read again at that point.
  However, you would be choosing files from the old list left on the screen, so it is safer to press [0] first.
- If you remove the disk that holds the NM program, NM.OVL, NMFONT.DAT and NMUNI.DAT can no longer be read.
  Put the program on a drive that is not removed (a RAM disk, for example).
- Do not remove a disk in the middle of a copy or other operation.

### Using one drive as two drives

On a machine with one floppy drive, DOS gives the one drive two drive names (A: and B:; with other interfaces present they may be D: and E:, and so on).
When NM tries to read or write the other drive name, the following prompt appears in the middle of the screen.

```
 Insert disk for drive B: and press a key
```

Change to the disk that you use under that drive name and press any key. The prompt disappears and the operation continues.
When you open A: and B: on the left and right and copy, this prompt appears every time the reading side and the writing side change over.

### Screen saver

If no key is pressed on the list screen for the time set by `SC_TIME`, the screen saver starts. It does not start while an input or confirmation window is shown, inside the viewer, or during a copy or other processing.

- **Built-in** (when `SCSAVER` is not written): The screen is divided into 16 pieces, one piece is made black, and a neighbouring piece slides into it; this is repeated.
  Pressing any key returns to the original screen. The list, the cursor and the marks stay as they were. The key pressed to stop it does not act as an operation.
- **External** (`SCSAVER = program name`): NM starts a program that "starts, and ends when a key is pressed", such as a screen saver for MultiMente.
  When it ends, control returns to NM, and the locations of the left and right sides and the cursor are as before (marks are cleared). The disk is read every time it starts.
- To turn it off, write `SC_TIME = 0`.

## 13. Limits and things not done yet

- The list can show up to 819 entries per side (409 each when there is no free mapper RAM).
- The viewer handles up to about 2500 lines. The viewer has no modes (such as showing control codes).
- The clock is 24-hour display only.
- [P] cannot specify a partition directly by number.
- Half-width letters in a volume name become upper case.
- On floppies, showing long file names with many kanji, and UTF-8 text, takes time (because NMUNI.DAT is read for every character).

## 14. Test status

Development is done on an emulator (openMSX), and only part has been checked on real hardware.

| Subject | Status |
|---|---|
| Basic operations (list, moving around, marks, copy, move, delete, rename, viewer, external commands) | Checked on the emulator with MSX-DOS2, Nextor 3 and Nextor 2.1. Also checked on real hardware (turbo R, and the MSX2 FS-A1FM) |
| [P] partition switching | Checked on real hardware with Nextor 2.1 (SD card) and with MEGA-SCSI on MSX-DOS2 |
| MGSDRV playing | Checked on real hardware |
| View font | All 4 kinds checked on the emulator. On real hardware: built into the FS-A1GT, a ROM fitted to the FS-A1ST, and the cartridge (on the FS-A1FM, checked that JIS level 2 in 12-dot lines changes depending on whether the View font is present) |
| `KANJI = OFF` | Checked on real hardware |
| [Y] writing the order, [SHIFT]+[S], [SHIFT]+[Y], total of marks | Checked on real hardware |
| Starting locations on the command line, [C] change the name, [CTRL]+[V] volume name, [F8]-[F10] | Checked on real hardware |
| [DEL] reorder mode, re-reading with [0] (including after swapping a card) | Checked on real hardware |
| The prompt when one drive is used as two drives | Checked on the emulator with MSX-DOS2 and Nextor 3 |
| 128KB machines | Not checked |

## 15. Credits

- Misaki font (by Num Kadoma, [https://littlelimit.net/misaki.htm](https://littlelimit.net/misaki.htm#download)). NMFONT.DAT is a conversion of it.
- The operation and the screen follow MultiMente (by MOGU). MultiMente is distributed on the GIGAMIX site ([https://www.gigamix.jp/](https://www.gigamix.jp/)).
- The way of reading the View font is based on the material of "Let's use View font" (by A to C) ([http://www.yo.rim.or.jp/~anaka/AtoC/index32.htm](http://www.yo.rim.or.jp/~anaka/AtoC/index32.htm)).
