# NM and MM.COM (MultiMente): a comparison of the specifications

As of NM (Next Maintenance) v0.99j (evaluation version, 2026-11-22). NM is compared with the manual of MultiMente v2.07 (MM.TXT).
NM is newly written and takes over the operation of MM; it uses none of MM's program.

**Compatibility with MM's settings**: NM reads MM's MMRET.DAT and MMMCR.DAT as they are. Lines of MM.CFG can be copied to NMCFG.DAT (unknown items are skipped).
The environment variable `%MM%` is also used with the same meaning as in MM.
MultiMente (including MMRET.DAT and MMMCR.DAT) can be downloaded from the GIGAMIX site ([https://www.gigamix.jp/](https://www.gigamix.jp/)).

**How it was made**: the references were the MM manual (MM.TXT), the sample settings file (MM.CFG), the format of the DAT files, and the screens and behaviour seen by running MM.
The contents of MM's program were not used, and it was not disassembled.

There are five categories.

1. The same
2. Added (not in MM)
3. Changed (the same purpose, but different behaviour or keys)
4. Left out (decided not to have)
5. Not yet done (in MM, not yet implemented in NM)

MM's behaviour is taken from what its manual says. Details not written in the manual (such as the result of macro expansion) have not been fully compared.

---

## 1. The same

### Keys

| Key | Function |
|---|---|
| [A] | Change attributes and date (files, directories) |
| [C] / [M] / [D] | Copy / move / delete. Directories with their contents |
| [N] / [K] | Rename / make a directory |
| [E] / [SHIFT]+[E] | Edit with the editor (an input line with the file name, where options can be added) / edit a new file |
| [V] / [SHIFT]+[V] | Built-in viewer / external viewer |
| [R] / [X] | Run / run a command line |
| [RETURN] | Run according to MMRET.DAT. If there is no entry, the built-in viewer. .MGS is played |
| [RETURN] with [SHIFT] / [CTRL] / [SHIFT]+[CTRL] | Start the assigned tool |
| [GRAPH] | One-key macros of MMMCR.DAT |
| [F] | Find by name (wildcards allowed) |
| [H] / [L] | Enter a path and go there / select a drive |
| [1] to [8] | Go to drive A: to H: |
| [.] / [BS], [¥], [/] | Parent directory, root, `%HOME%` |
| [W] | Display filter (`*`, `?`, `/string`) |
| [CTRL]+[W] | Change the attributes shown (hidden, system) |
| [SHIFT]+[W] | Mark by wildcard from the cursor downward |
| [SPACE] | Mark and go to the next |
| [SELECT], [SHIFT]+[SELECT], [CTRL]+[SELECT] | Mark all (unmark all if any are marked), invert all, invert from the cursor onward. Directories are not included |
| [S] | Sort |
| [Y] | Write the order to the disk |
| [DEL] | Reorder mode. [DEL] takes an entry out, [INS] puts it back in. Ends when nothing taken out is left |
| [I] | Disk information |
| [CTRL]+[V] | Change the volume name. Entering nothing deletes it |
| [P] | Switch partitions |
| [G] / [SHIFT]+[G] | Show the MGSDRV song title / choose from the list of songs |
| [F1] | Description of the functions |
| [↑][↓], with [SHIFT] | Move the cursor, top / bottom |
| [←][→] with [SHIFT] | Move one page |
| [CTRL]+[E][X][S][D][R][C][F][A] | Diamond cursor (in NM, on the list screen only) |
| [Q] / [ESC] | Quit ([Q] at once, [ESC] after a confirmation). After quitting, the drive and directory last viewed become the DOS current ones |

### Others

| Item | Details |
|---|---|
| Screen | SCREEN 7, 80 columns of 6×8-dot characters. The menu line, the double-line frame and the colours match MM |
| Display of marks | The colour of the name is not changed; a `*` is added |
| MMRET.DAT, MMMCR.DAT | The same format. MM's files can be used as they are (if files named NMRET.DAT and NMMCR.DAT exist, those are used first) |
| How settings are written | `item = value ; comment`, the same as MM.CFG (for how they are read, see "3. Changed") |
| Defaults of the external tools | `KID $F`, `VF $C` and so on, the same as MM |
| Macros | `$C` `$X` `$D` `$P` `$R` `$T` `$t` `$M` `$m` `$$` |
| Environment variables | `%SHELL%`, `%HOME%`, `%MM%` |
| Swapping A: / B: on a one-drive machine | When the other drive name is used, a prompt to swap the disk is shown and a key is awaited (NM's prompt is in English) |
| Screen saver | `SCSAVER` (an external program. If there is none, the built-in 16-piece puzzle), `SC_TIME` (time until it starts, default 43 = about 3 minutes) |
| How external commands are run | No temporary file is made; a small resident part is left and the command is run. .COM files are started directly, and anything else goes through `%SHELL%` (the resident part is 256 bytes in MM, 512 bytes in NM) |
| When a file of the same name exists | [Y] overwrite, [T] only if newer, [C] change the name, [N] skip, with [SHIFT] for all that follow |
| Directory given at startup | `NM A:\UTILS`, the same as `MM A:\UTILS` (for giving the right side, see "2. Added") |
| Interrupting a copy | [ESC] |
| Viewer keys | [SPACE]/[BS] page, [←][→] 10 pages, with [SHIFT] half of that, [H]/[T] top / end, [TAB] tab width, [RETURN]/[ESC] quit |
| Working with MGSDRV | Playing .MGS, showing the song title, choosing from the list |
| View font | Uses the kanji ROM of MSX-View and the 12×8 font of the FS-A1GT |

---

## 2. Added

| Item | Details |
|---|---|
| Two screens | Directories are shown side by side, left and right. [TAB] changes the active side |
| Giving the left and right locations at startup | The location of the right side can be written second, as in `NM A: B:` |
| Keys for the two screens | [F3] set the other side to the same directory, [F4] open the directory at the cursor on the other side, [SHIFT]+[1] to [8] drive of the other side, [SHIFT]+[TAB] swap left and right |
| One-screen display | [F5] shows only the active side on the whole screen (85 entries in the names-only display) |
| Display of 256 or more entries | Up to 819 entries per side (MM shows the first 255) |
| Display of long file names (LFN) | The long name of the file at the cursor is shown on the Name line. Kanji are shown too (NMUNI.DAT) |
| Cleaning up LFNs | On delete, rename and move, the long-name part left on the disk is erased too |
| Free space and total capacity | Always shown for each side (to see the free space of the copy destination) |
| Total of the marks | The total size of the marked files is shown in KB |
| Display of the volume name | Shown after the drive name, for each side |
| Hex dump | [X] in the viewer |
| UTF-8 text | Detected automatically and shown in the viewer. [U] switches |
| Character size in the viewer | [K] switches between 8-dot lines (25 lines), 12-dot lines (17 lines) and the Misaki font |
| Read-ahead in the viewer | After the display, the rest is read while the program is idle |
| Switching Nextor partitions | [P] assigns one chosen from the list of devices and partitions |
| Working with MCPLAYER | With the resident MCPLAYER, [RETURN] plays .MCM files (Micro Cabin songs). It and MGSDRV stop each other |
| Several commands for the same extension | If several are written in MMRET.DAT, [RETURN] shows a menu |
| Macros | `$O` (path of the other side), `$o` (drive of the other side), `$;` (a literal `;`) |
| [SHIFT]+[S], [SHIFT]+[Y] | Sort both sides, write the order of both sides |
| Colour settings | Nine items such as `COL_BACK` can be changed in NMCFG.DAT |
| Colours by extension | [SHIFT]+[0] as in MM. The extensions and their colours can be set with `EXT` in NMCFG.DAT (fixed in MM) |
| Key replacement | `KEYMAP` (for keyboards with a different layout) |
| Switching to ANK only | `KANJI = ON / OFF / AUTO` (in MM the ANK version and the kanji version are separate programs) |
| Handling of disk errors | "Abort, Retry" is not shown; the error text is shown inside the screen and the operation is stopped |
| Confirmation for read-only files | Asks before deleting or overwriting a read-only file |
| Deleting a directory that has contents | Shows the number of entries inside and asks |
| Extended View font, ROM fitted to the FS-A1ST | Can be used as the View font. The 12×12 characters are used for the 12-dot lines of the viewer |

---

## 3. Changed

| Item | MM | NM |
|---|---|---|
| [HOME] | Shut down the HDD | Does nothing |
| [TAB] | Mark / unmark (the cursor does not move) | Changes the active side. Mark / unmark is [SHIFT]+[SPACE] |
| [SHIFT]+[1] to [9] | Number of display columns (1, 2, 3, 5 columns, automatic) | Changes the drive of the other side. Columns are switched with [F8] [F9] [F10], between two kinds: the detailed display and the names-only display |
| Number of columns in the names-only display | 2, 3 or 5 columns can be chosen | Fixed at 2 columns with two screens, 5 columns with one screen |
| [←][→] | (not described in the manual) | One page in the detailed display, move between columns in the names-only display |
| [0] | Rereads the same drive and shows it from the top | Rereads both sides and shows them from the top (the volume names too) |
| Destination of [C] [M] | Entered. [RETURN] with nothing entered chooses from the tree | Entered. Starts with the path of the other side already filled in. There is no tree |
| Information area | Capacity, free space, number of entries and number of marks are shown in the information area | Number of entries, number of marks and free space are shown below each of the left and right lists |
| [S] sort | (one screen) | The active side only. [SHIFT]+[S] for both sides |
| Details of the [DEL] reorder mode | Up to 24 entries can be taken out. The number of display columns can be changed within the mode | Up to 18 (placed in the 3 lines above the list). The kind of display cannot be changed |
| [Y] writing the order | Writes | Shows a red warning and writes only when [Y] is pressed once more. Up to 192 slots. After writing, rereads and verifies |
| How settings are made | MM.CFG is written into the program with CS.COM | NMCFG.DAT is read at every start (the program is not rewritten). Only some items are read (see 5 below) |
| ANK version and kanji version | Separate programs | One program. Kanji are drawn directly in the list (no kanji driver is needed) |
| Kanji font of the list | The kanji version displays them. With the View font or a dedicated kanji driver, 12×8 characters can be used | The View font; if there is none, the bundled NMFONT.DAT (Misaki 8×8); if that is missing too, the kanji ROM reduced in size |
| [↑][↓] in the viewer | Move one page (half with [SHIFT]) | One line at a time |
| Kanji in the viewer | Depends on a kanji driver or the like | Draws them itself by reducing the characters of the kanji ROM. With the View font, those characters |
| Overlay | MM.EXE | NM.OVL. Not loaded unless it was built together with the program |
| After an external command | (not described in the manual) | NM is started again. The cursor position, the marks and the directory of the other side are not restored |
| When there is no `%SHELL%` | (not described in the manual) | Looks for COMMAND2.COM on the boot drive, the drive holding the program, then A:, in that order |
| `$P` | Path of the current directory | Path without the drive name (`\DIR\SUB`). Whether this is the same as MM has not been checked |
| `$k` | Waits for a key | Treated the same as `$K` (waits after the run) |
| [P] on MEGA-SCSI | Choose from MMPART.DIR (a list you make yourself) | The list is made from MEGASCSI.TBL on the disk. MMPART.DIR is not used. Names are not shown |
| [P] on the drive holding the program | (not described in the manual) | Refuses to switch |
| List of MGS songs | MGSDRV 3.15 or later | The same. Numbers start from 1 |
| Copy buffer | Uses free mapper RAM (up to 1MB) | Only about 7.5KB inside the program (free mapper RAM is not used). Copying large files should be slower than MM |
| Rereading after a file operation | (one screen) | Only the side whose contents changed is reread |

---

## 4. Left out

These are things NM was decided not to have.

| Item | MM keys etc. |
|---|---|
| Tree display, MMTREE.DIR | [T], empty [RETURN] at the copy destination input |
| Compression and extraction | [U], [SHIFT]+[U], [CTRL]+[I], [CTRL]+[P], [CTRL]+[L], [CTRL]+[O] |
| History | [↑] during input, MM.HIS, MM.PHS |
| Shutting down the HDD | [HOME], [CTRL]+[GRAPH]+[DEL] |
| Replacing the half-width font | `%FONT0808%` |
| Customizing with CS.COM | The method of writing MM.CFG into the program |
| The kanji version as a separate program | — |
| Macros only for compression and extraction | `$A`, `$Z` |
| Automatic change of the number of display columns | [SHIFT]+[9] |
| 3-column display | [SHIFT]+[3] |
| MMPART.DIR | List of MEGA-SCSI partition names |

---

## 5. Not yet done

These are in MM and have not yet been made in NM. It has not been decided to drop them.

| Item | MM | NM now |
|---|---|---|
| Editing of text input | Cursor movement, insert / overwrite, [DEL], [CTRL]+[U], [CTRL]+[K], kanji input (MSX-JE, the conversion line is the bottom line) | Cursor movement, insert / overwrite, [BS], [DEL], kanji input (MSX-JE, [CTRL]+[SPACE]. The conversion line is inside the input window). [CTRL]+[U] and [CTRL]+[K] are not yet done |
| Volume attributes, delete with [D], rename with [N] | [A], [D] and [N] also work on the volume | Only change and delete with [CTRL]+[V]. A full-width name cannot be given |
| Direct selection of a partition | [CTRL]+[0] to [8] | None |
| Viewer modes | [B] ignore 1Ah, [C] control codes, [R] line breaks, [A] ANK display | None (ends at 1Ah) |
| Starting tools from the viewer | [SHIFT]+[V], [RETURN] with [SHIFT] and so on | None |
| 12-hour clock display | `%TIME%` | 24-hour display only |
| Macros | `$d` (temporary drive), `$J` (run in kanji mode) | Ignored |
| Setting items | The items of MM.CFG | Reads only `MODE`, `ATTR_H`, `ATTR_S` and the 7 external tool items. `SORT`, `WILDCARD`, `KEYCLIK`, `MODE2`, `ATTR_V`, the initial viewer mode and so on are not read |
| Diamond cursor | Usable everywhere | On the list screen only |
| Using free mapper RAM for copying | Yes | No |
