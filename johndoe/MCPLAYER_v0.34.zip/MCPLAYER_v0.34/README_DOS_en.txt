﻿============================================================
MCPLAYER.COM (MICRO CABIN MUSIC PLAYER for MSX-DOS) Ver 0.34
============================================================

MCPLAYER.COM stays resident under MSX-DOS2 or Nextor and plays the music of Micro Cabin games in the background while you keep using the DOS prompt or a file manager.
Like MGSDRV, you install it with MCPLAYER /Z and play a song with MCPLAYER song.MCM. As in the ROM version, every song is played with the game's own sound driver and instruments.

The DOS files are made in the dos/ folder together with the ROM when you run player/build_rom.py as described in README_en.md.
The music and drivers come from your own disk images; the package contains none of them.

== Files (dos/) ==

  File                 Contents
  -------------------  --------------------------------------------------------------------------------------------------------------------------------------------------
  MCPLAYER.COM         The player (install, play, stop; about 5 KB)
  XAK.DRV etc.         The game's sound driver, extracted from your disk images and adapted to MCPLAYER.COM
  XAK/XAK101.MCM etc.  The songs of the playlist, one folder per game, with their original file names (a song that several games share is put in the folder of each game)
  XAK/XAK.LST etc.     Song list (file name, driver, loop count, titles), one per game folder, Shift-JIS

Copy the contents of dos/ with its folders to an MSX disk. Keep MCPLAYER.COM and the *.DRV files in the same folder.

  DRV                 Game                                     Song file names
  ------------------  ---------------------------------------  ------------------------
  XAK                 Xak                                      XAK…
  XAKI                Xak II                                   XAKI…
  GAZZ                Tower of Gazzel                          GAZZ…
  FRYM / FRYT / FRYD  Fray (MSX2 / turboR / demo)              FRYM… / FRYT… / FRYD…
  ILLU                Illusion City                            ILLU…
  FFAN                Final Fantasy                            FFAN…
  RISK                Dai Senryaku II (Campaign Version)       RISK…
  PMAK                Princess Maker                           PMAK…
  CABI / CABI3        The Tower of Cabin (disks 1-2 / disk 3)  CABI… / CABI3…

== Requirements ==

- An MSX running MSX-DOS2 or Nextor (2 / 3), with one free mapper RAM segment (16 KB)
- MSX-MUSIC or FM-PAC (without FM only the PSG parts play)
- A turbo R can stay in R800 mode (the FM writes wait long enough for the R800)

== Usage ==

      MCPLAYER /Z                 install (again to remove)
      MCPLAYER XAK\XAK201.MCM     play in the background (back to the prompt at once)
      MCPLAYER XAK201.MCM /L:2    fade out and stop after 2 loops (default: loop forever)
      MCPLAYER /S                 stop
      MCPLAYER /F                 fade out and stop (speed with /F:8 etc., default 4)
      MCPLAYER                    usage and state (playing / fading / stopped, song name)
      MCPLAYER XAK201.MCM /E      show the title in English (/J: Japanese)

- Installing and removing reboot DOS (like MGSDRV; REBOOT.BAT runs if present). The reboot resets the environment and the current directory, so set them again in REBOOT.BAT if needed.
- MCPLAYER can be removed only while it is the last program installed (remove MGSDRV etc. first if you installed them after it).
- Songs that do not loop stop at their end.

-- Song lists (*.LST) --

Each game folder has a list of its songs, named like the driver (XAK.LST). It is Shift-JIS text, one song per line; lines starting with # are comments.

      XAK201.MCM | XAK.DRV |  | Xak | (Japanese title) | Xak | Village of Fearless
      (file name | driver | loop count | game | title | English game name | English title)

- When a song is played, MCPLAYER looks up its line and uses the driver, loop count and titles. The title is shown with "Playing" and in the state display (MCPLAYER), and handed to file managers (API.md).
- The list is found like the driver, by the first characters of the song file name (song folder, then the folder of MCPLAYER.COM); otherwise the *.LST files in those folders are checked.
- The driver and loop count may be empty (then the usual search / loop forever). With a loop count the song stops after that many loops even without /L.
- The title is shown in Japanese when the machine's character set is Japanese and the DOS screen is in kanji mode (a graphics screen), otherwise in English; /J and /E choose.
- Songs that are not in a list (renamed songs etc.) still play with the search below, without a title. The lists are text, so you can edit them.

-- How the driver is chosen --

If the song list names a driver for the song, that one is used. Otherwise MCPLAYER looks for xxxxx.DRV named after the first 5, 4, then 3 characters of the song file name (XAK201.MCM: XAK20.DRV, XAK2.DRV, XAK.DRV), first in the song's folder, then in the folder of MCPLAYER.COM.
If none is found, it checks the *.DRV files in those folders for one whose song list contains this song, so renamed songs play as well. /D:XAK.DRV names the driver directly.

== From a file manager ==

Associate .MCM files with MCPLAYER in the file manager. In NM or MultiMente, add a line for .MCM with MCPLAYER $C to MMRET.DAT. Selecting a .MCM file then plays it while you keep using the file manager.

== With MGSDRV ==

MCPLAYER and MGSDRV can be resident together, but they share the sound chips (PSG, MSX-MUSIC), so playing both at once mixes the music.

- MCPLAYER song.MCM stops MGSDRV first if MGSDRV is resident.
- Stopping MCPLAYER before playing an MGS file is up to the program that plays it (otherwise the music mixes). The entry for that is described in API.md (Japanese).

== Notes ==

- TPA: the resident part takes 249 bytes of page 3 (the TPA top goes down by about 100h). On MSX-DOS2 with MGSDRV resident as well, programs that need much TPA (for example NM, which needs D360h or more) may not start. On Nextor both fit.
- Nextor COMMAND3.COM / COMMAND2.COM 2.44: every time a program reboots DOS (installing or removing MGSDRV or MCPLAYER), the shell's swap area fills a little, and after 4-5 times external commands fail with "Not enough memory" (Konamiman/Nextor #289). MCPLAYER cleans this up before it reboots, so installing and removing MCPLAYER does not cause it (repeating it with MGSDRV alone still does).
- Songs up to 6 KB (the largest known song is 4.7 KB).

== Tested ==

- openMSX (FS-A1ST) with MSX-DOS2 and Nextor 3: playing, stopping, fading and loop counts with all 12 drivers, MGSDRV resident together, renamed songs.
- The relocated drivers give the same PSG and FM output as the original drivers for all 471 songs (checked in a Z80 emulator).
- Real hardware (MSX turbo R, MSX-DOS2 and Nextor 2): playing in R800 and Z80 mode, playing from the NM file manager, using it with MGSDRV.
