"""disk_image 以下のディスクイメージから FM の曲を抜き出し、data フォルダとプレイリストを作る

使い方 (MicroCabin フォルダで):
  python tools/extract_disks.py [--images disk_image] [--out data] [--db tools/mcm_db.csv]
                                [--playlist player/playlist.txt]

1. 抜き出し
   - disk_image の下のフォルダ 1 つが 1 ゲーム。ディスク番号はファイル名で並べた順 (1 から)
   - 抜き出すのは FM を使う曲だけ (PSG のみの曲・空の曲は除く)。同じフォルダの中で同じ曲は最初の 1 つだけ
   - ファイル名: フォルダ名の先頭 4 文字 + ディスク番号 1 桁 + 連番 2 桁 (例 ILLU102)
                 FRAY_M2 / FRAY_TR / FRAY_DM は FRYM2 / FRYTR / FRYDM + ディスク番号 + 連番
2. データベース (tools/mcm_db.csv) に、見つかった場所を書き足す。データベースにない曲は新しく登録する
3. データベースと data フォルダからプレイリストを作る (曲名・並び・除外はデータベースのもの)
   プレイリストを直したら python tools/mcm_db.py sync でデータベースに反映する

データベースを最初に作るときだけ使うオプション:
  --ref data_ref --ref-playlist player/playlist_ref.txt
     参考データと中身が同じ曲に、参考プレイリストの曲名・ゲーム名・並び・ループ回数・ドライバ・
     除外を付ける (データベースにまだない曲だけ)。使い回しの曲は参考プレイリストでその曲が
     あったゲームのフォルダのファイルを使う (HOME 参照)
"""
import argparse, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mcm
from mcm_scan import scan
import mcm_db
import omake

ROOT = os.path.dirname(HERE)
PREFIX = {'FRAY_M2': 'FRYM2', 'FRAY_TR': 'FRYTR', 'FRAY_DM': 'FRYDM'}
# 参考データのフォルダ -> その曲に使うディスクのフォルダ (前にあるほど優先)
HOME = {'FRAY': ['FRAY_M2', 'FRAY_TR', 'FRAY_DM'], 'C-TIMES': ['GAZZEL', 'CABIN']}


def prefix_of(folder):
    return PREFIX.get(folder.upper(), re.sub(r'[^A-Z0-9]', '', folder.upper())[:4])


def read_ref_playlist(path, ref_dir):
    """参考プレイリスト -> {md5: dict(title, loops, drv, exclude, order, game, src, dir)}"""
    out = {}
    if not path or not os.path.isfile(path):
        return out
    base = os.path.dirname(os.path.abspath(path))
    game = ''
    with open(path, encoding='utf-8-sig') as f:
        for order, raw in enumerate(f):
            line = raw.strip()
            if line.lower().startswith('@game'):
                game = line[5:].split('#', 1)[0].strip()
                continue
            active = not line.startswith('#')
            body = line.lstrip('#').strip()
            if '.MCM' not in body.upper():
                continue
            body, _, reason = body.partition('#')
            parts = [p.strip() for p in body.split('|')]
            rel = parts[0]
            # 参考プレイリストは ../data/... を指しているので、改名後の参考フォルダに読み替える
            p = os.path.normpath(os.path.join(base, rel))
            if not os.path.isfile(p):
                m = re.search(r'data[\\/](.*)$', rel)
                p = os.path.join(ref_dir, m.group(1)) if m else p
            if not os.path.isfile(p):
                continue
            s = mcm.load(p)
            if not s or s.md5 in out:
                continue
            out[s.md5] = dict(title=parts[1] if len(parts) > 1 else '',
                              loops=parts[2] if len(parts) > 2 else '',
                              drv=(parts[3] if len(parts) > 3 else '').upper(),
                              exclude='' if active else (reason.strip() or '除外'),
                              order=order, game=game, src=os.path.basename(p),
                              dir=os.path.basename(os.path.dirname(p)).upper())
    return out


def extract(images, out, known=frozenset(), skip=frozenset(), home=None):
    """抜き出して out に書く。戻り: [(フォルダ, [曲 dict])], 集計
    曲 dict: name, song, disk, pos, write (ファイルに書いたか)
    - FM の曲: フォルダ名の先頭4字 + ディスク番号 + 連番 (例 ILLU102)。skip (データベースで除外した曲の MD5) は書かない
    - PSG だけの曲: データベースにあるもの (known) だけを 先頭4字 + P + ディスク番号 + 連番 (例 XAKP101)
    - BASIC の PLAY で鳴らす曲 (OMAKE.BAS): データベースにあるものだけを 先頭4字 + O + ディスク番号 + 連番
    連番は書かない曲にも付ける (どの環境でも同じ名前になるように)
    home: {MD5: その曲に使うフォルダの集まり} (データベースの収録する行の folder)。
          そのフォルダのディスクがあればそこにだけ書き、なければ最初に見つかったフォルダに書く"""
    games = []
    stats = []
    for folder in sorted(os.listdir(images)):
        fdir = os.path.join(images, folder)
        if not os.path.isdir(fdir):
            continue
        disks = sorted(f for f in os.listdir(fdir) if os.path.isfile(os.path.join(fdir, f))
                       and not f.lower().endswith('.txt'))
        if not disks:
            continue
        pre = prefix_of(folder)
        seen = set()
        songs = []
        n_psg = n_dup = n_skip = 0
        for dn, disk in enumerate(disks, 1):
            serial = 0
            psg_serial = 0
            data = open(os.path.join(fdir, disk), 'rb').read()
            for pos, s in scan(data):
                if s.is_empty() or not s.uses_fm():
                    n_psg += 1
                    if s.is_empty() or s.md5 in seen:
                        continue
                    seen.add(s.md5)
                    psg_serial += 1
                    if s.md5 in known and s.md5 not in skip:
                        songs.append(dict(name=f'{pre}P{dn}{psg_serial:02d}', song=s, disk=dn, pos=pos, write=True))
                    continue
                if s.md5 in seen:
                    n_dup += 1
                    continue
                seen.add(s.md5)
                serial += 1
                w = s.md5 not in skip
                n_skip += not w
                songs.append(dict(name=f'{pre}{dn}{serial:02d}', song=s, disk=dn, pos=pos, write=w))
            for k, (fname, body) in enumerate(omake.find_in_disk(data), 1):
                r = mcm.parse(body, 0, strict=True)
                if r and r[0].md5 in known and r[0].md5 not in seen:
                    seen.add(r[0].md5)
                    songs.append(dict(name=f'{pre}O{dn}{k:02d}', song=r[0], disk=dn, pos=fname, write=True))
        games.append((folder, songs))
        stats.append([folder, len(disks), 0, n_skip, n_psg, n_dup])
    # 同じ曲は、データベースでその曲に使うフォルダにだけ書く
    if home is not None:
        found = {}
        for folder, songs in games:
            for x in songs:
                if x['write']:
                    found.setdefault(x['song'].md5, []).append(folder)
        for folder, songs in games:
            for x in songs:
                h = x['song'].md5
                if not x['write'] or h not in home:
                    continue
                pref = [f for f in found[h] if f in home[h]]
                x['write'] = folder in pref if pref else folder == found[h][0]   # 使うフォルダそれぞれに書く
    for st, (folder, songs) in zip(stats, games):
        os.makedirs(os.path.join(out, folder), exist_ok=True)
        for x in songs:
            if x['write']:
                open(os.path.join(out, folder, x['name'] + '.MCM'), 'wb').write(x['song'].body)
        st[2] = sum(x['write'] for x in songs)
    return games, stats


# ディスクイメージを入れるフォルダ (FRAY_DM = 体験版は持っている人が少ないので作らない。あれば使う)
GAME_FOLDERS = ['XAK', 'XAKII', 'FRAY_M2', 'FRAY_TR', 'GAZZEL', 'ILLUSION', 'FFANTASY', 'RISK2', 'PMAKER', 'CABIN']
FOLDER_NOTE = {'FRAY_M2': 'MSX2 版', 'FRAY_TR': 'MSX turboR 版'}
README_NAME = 'ここに入れるディスク.txt'
DISK_COUNT = {'XAK': 3, 'XAKII': 6, 'FRAY_M2': 4, 'FRAY_TR': 5, 'GAZZEL': 4, 'ILLUSION': 8, 'FFANTASY': 1,
              'RISK2': 2, 'PMAKER': 7, 'CABIN': 3}


def setup_folders(images, rows):
    """disk_image の下にゲームごとのフォルダを作る (スペルミスを防ぐため)。戻り: 作ったフォルダ"""
    disks = DISK_COUNT
    made = []
    for folder in GAME_FOLDERS:
        d = os.path.join(images, folder)
        if not os.path.isdir(d):
            os.makedirs(d)
            made.append(folder)
        readme = os.path.join(d, README_NAME)
        if not os.path.isfile(readme):
            game = mcm_db.FOLDER_GAMES.get(folder, folder)
            text = [f'{game}' + (f' ({FOLDER_NOTE[folder]})' if folder in ('FRAY_M2', 'FRAY_TR') else ''),
                    '',
                    f'このフォルダに {game} のディスクイメージ (.dsk) を入れてください'
                    + (f' (全 {disks[folder]} 枚)' if folder in disks else '') + '。',
                    'ディスクの番号はファイル名の順です (「Disk 1 of 3」のような名前なら、そのままで構いません)。',
                    '持っていないゲームのフォルダは空のままで構いません。',
                    'ROM を作るときは、曲を鳴らすドライバと音色などの表も、このディスクイメージから取り出します。']
            with open(readme, 'w', encoding='utf-8-sig', newline='\r\n') as f:
                f.write('\n'.join(text) + '\n')
    return made


def write_log(path, games, rows, disks_of):
    """抜き出した曲がデータベースのどの行か (ユーザーが曲名などを直すときの手がかり)"""
    by_md5 = {}
    for r in rows:
        by_md5.setdefault(r['md5'], []).append(r)
    lines = ['# 抜き出した曲とデータベース (tools/mcm_db.csv) の行の対応',
             '# 曲名などを直すときは、この id の行をデータベースで直す (同じ曲がほかのゲームにもあれば行が複数ある)',
             '# ファイル\tディスク\t位置\tid\tゲーム\t曲名\t英語の曲名\t除外の理由', '']
    n_unknown = 0
    for folder, songs in games:
        lines.append(f'== {folder}')
        for i, d in enumerate(disks_of.get(folder, []), 1):
            lines.append(f'   ディスク{i}: {d}')
        for x in songs:
            if not x['write']:
                continue
            pos = x['pos'] if isinstance(x['pos'], str) else f"{x['pos']:06X}h"
            rs = by_md5.get(x['song'].md5)
            if not rs:
                n_unknown += 1
                lines.append(f"{x['name']}.MCM\t{x['disk']}\t{pos}\t(データベースにない曲)")
                continue
            for r in rs:
                lines.append('\t'.join([f"{x['name']}.MCM", str(x['disk']), pos, r['id'], r['game'],
                                        r['title'], r['title_en'], r['exclude']]))
        lines.append('')
    with open(path, 'w', encoding='utf-8-sig', newline='\r\n') as f:
        f.write('\n'.join(lines) + '\n')
    return n_unknown


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--images', default=os.path.join(ROOT, 'disk_image'))
    ap.add_argument('--out', default=os.path.join(ROOT, 'data'))
    ap.add_argument('--db', default=mcm_db.DEFAULT_DB)
    ap.add_argument('--playlist', default=mcm_db.DEFAULT_PLAYLIST)
    ap.add_argument('--all', action='store_true', help='データベースで除外にした曲も抜き出す')
    ap.add_argument('--full', action='store_true',
                    help='管理用: 今のプレイリストをデータベースに反映してから、曲名などの欄も書いたプレイリストで上書きする')
    ap.add_argument('--log', default=os.path.join(ROOT, 'extract_log.txt'))
    ap.add_argument('--ref', help='参考データのフォルダ (データベースを最初に作るとき)')
    ap.add_argument('--ref-playlist', help='参考プレイリスト (データベースを最初に作るとき)')
    a = ap.parse_args()

    rows = mcm_db.load_db(a.db)
    made = setup_folders(a.images, rows)
    have = [f for f in os.listdir(a.images) if os.path.isdir(os.path.join(a.images, f))
            and any(not x.lower().endswith('.txt') for x in os.listdir(os.path.join(a.images, f)))]
    if made or not have:
        if made:
            print(f'ディスクイメージを入れるフォルダを作りました: {a.images}')
            for f in made:
                print(f'  {f:9s} {mcm_db.FOLDER_GAMES.get(f, f)}')
        if not have:
            print('それぞれのフォルダにゲームのディスクイメージ (.dsk) を入れてから、もう一度実行してください。')
            return
    if a.full:
        mcm_db.sync_before_rewrite(rows, a.playlist, a.db)     # 直したプレイリストを失わないように
    known = {r['md5'] for r in rows}
    # データベースで除外にした曲 (どのゲームでも除外) は抜き出さない
    skip = set() if a.all else {h for h in known if all(r['exclude'] for r in rows if r['md5'] == h)}
    home = None
    if not a.all:
        home = {}
        for r in rows:
            if not r['exclude'] and r['folder']:
                home.setdefault(r['md5'], set()).add(r['folder'])
    games, stats = extract(a.images, a.out, known, skip, home)
    ref = read_ref_playlist(a.ref_playlist, a.ref) if a.ref_playlist else {}

    # 曲ごとに見つかった場所
    where = {}
    for folder, songs in games:
        for x in songs:
            where.setdefault(x['song'].md5, []).append((folder, x))

    # 新しい曲の登録。使うファイル (folder/file) は、参考プレイリストにあればそのゲームのフォルダ、
    # なければ最初に見つかったフォルダ (参考プレイリストに最初に出るゲームの順)
    def ref_home(h):
        """参考プレイリストにある曲を使うフォルダ (参考データのフォルダに対応するもの)"""
        folders = [fo for fo, _ in where[h]]
        return next((f for f in HOME.get(ref[h]['dir'], [ref[h]['dir']]) if f in folders), None)

    def folder_rank(folder):
        # そのフォルダを使う曲が参考プレイリストに最初に出る位置 (寄せ集めのフォルダを先にしない)
        idx = [ref[h]['order'] for h in where if h in ref and ref_home(h) == folder]
        return (min(idx) if idx else 10 ** 9, folder)
    folder_order = sorted((f for f, _ in games), key=folder_rank)

    def new_key(kv):
        h, locs = kv
        return (ref[h]['order'] if h in ref else 10 ** 9, folder_order.index(locs[0][0]), locs[0][1]['name'])
    new = 0
    for h, locs in sorted(where.items(), key=new_key):
        if h in known:
            continue
        rf = ref.get(h)
        folders = [fo for fo, _ in locs]
        home = ref_home(h) if rf else None
        if home is None:
            home = min(folders, key=folder_order.index)
        x = next(x for fo, x in locs if fo == home)
        r = mcm_db.new_row(rows, x['song'], home, x['name'])
        if rf:
            r.update(title=rf['title'], game=rf['game'] or r['game'], exclude=rf['exclude'],
                     loops=rf['loops'], drv=rf['drv'] or r['drv'], order=str(rf['order'] * 10), ref=rf['src'])
        rows.append(r)
        known.add(h)
        new += 1
    for r in rows:                              # 見つかった場所 (同じ曲の行すべてに)
        for fo, x in where.get(r['md5'], []):
            pos = x['pos'] if isinstance(x['pos'], str) else f'{x["pos"]:06X}h'
            r['files'] = mcm_db.add_item(r['files'], f'{fo}/{x["name"]} (ディスク{x["disk"]} {pos})')
    mcm_db.save_db(a.db, rows)

    playlist = a.playlist
    if not a.full and os.path.isfile(playlist):
        playlist = os.path.join(os.path.dirname(a.playlist), 'playlist_new.txt')   # 自分のプレイリストは上書きしない
    n_in, n_ex, n_unk = mcm_db.make_playlist(rows, a.out, playlist, full=a.full)
    disks_of = {f: sorted(x for x in os.listdir(os.path.join(a.images, f))
                          if os.path.isfile(os.path.join(a.images, f, x)) and not x.lower().endswith('.txt'))
                for f, _ in games}
    n_unknown = write_log(a.log, games, rows, disks_of)

    print(f'{"フォルダ":10s} ディスク  書いた曲  除外  PSG/空  重複   (書いた曲以外は抜き出していない)')
    for folder, nd, ns, nskip, npsg, ndup in stats:
        print(f'{folder:10s} {nd:6d} {ns:8d} {nskip:5d} {npsg:7d} {ndup:5d}')
    print(f'曲データ {sum(x["write"] for _, s in games for x in s)} ファイル -> {a.out}')
    print(f'データベース {len(rows)} 曲 (新しく登録 {new} 曲) -> {a.db}')
    print(f'プレイリスト {playlist}: 収録 {n_in} 曲' + (f'、除外 {n_ex} 曲' if a.full else ''))
    print(f'ログ {a.log}' + (f' (データベースにない曲 {n_unknown} 曲)' if n_unknown else ''))


if __name__ == '__main__':
    main()
