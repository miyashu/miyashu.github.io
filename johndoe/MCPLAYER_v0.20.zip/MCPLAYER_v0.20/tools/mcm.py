"""マイクロキャビンの曲データ (MCM) の形 — 抜き出し・データベース・ROM 作成で共通に使う

MCM の形 (mcdrv.asm の IniTblSng が読む形):
  先頭に BLOAD ヘッダ (FEh, 開始, 終了, 実行アドレス の 7 バイト) が付いていることがある
  本体 +0    ワード: チャンネルのブロック数 (FM 曲は 9/11/12、PSG のみの曲は 3 など。ドライバは読まない)
  本体 +2    ワード: 次のブロックの位置 (本体の先頭から)。続いてチャンネル 0 のデータ
  ...        各ブロックは「次のブロックの位置」で始まり、その後にチャンネルのデータ
  最後       次のブロックの位置が指すワードが 0000 なら終わり (この 0000 までが曲)
  チャンネルは PSG 0-2、FM 0-8 の順 (12 を超える分はドライバが使わない)
  各チャンネルのデータはコマンド列で、終わりの 00 がちょうどブロックの最後の 1 バイトになる
  (既知の 374 ファイルはすべてこの形。抜き出しではこれを見分けの条件にしている)
"""
import hashlib
import struct

MAX_SIZE = 0x4000
MAX_BLOCKS = 32
USED_CHANNELS = 12          # ドライバが使うチャンネル数 (PSG 3 + FM 9)

# パラメータ付きコマンドのバイト数。FFh は第1パラメータが 8,9 (共通) / 0Ch,0Eh (ドライバB) なら +1
OP_PARAMS = {0xFA: 1, 0xFB: 1, 0xFC: 1, 0xFD: 2, 0xFE: 1, 0xFF: 1}
OP_PAR_EXTRA = (0x08, 0x09, 0x0C, 0x0E)
NOTE_MAX = 0x24             # 01h-24h が音符


def _stream_end(b, p, end):
    """チャンネルのコマンド列を p から end の手前までたどり、終わりの 00 の位置を返す"""
    while p < end and b[p] != 0:
        op = b[p]
        n = OP_PARAMS.get(op, 0)
        if op == 0xFF and p + 1 < end and b[p + 1] in OP_PAR_EXTRA:
            n = 2
        p += 1 + n
    return p


class Song:
    """本体 (BLOAD ヘッダを除いた、先頭から終端の 0000 まで) とチャンネルのデータ"""

    def __init__(self, body, links):
        self.body = body
        self.links = links
        ends = links[1:] + [len(body) - 2]
        self.channels = [body[a + 2:e] for a, e in zip(links, ends)]
        self.md5 = hashlib.md5(body).hexdigest()

    @property
    def blocks(self):
        return len(self.links)

    def uses_fm(self):
        """FM チャンネル (4 番目以降、12 番目まで) に音符があれば True"""
        for c in self.channels[3:USED_CHANNELS]:
            p = 0
            while p < len(c) and c[p] != 0:
                op = c[p]
                if op <= NOTE_MAX:
                    return True
                n = OP_PARAMS.get(op, 0)
                if op == 0xFF and p + 1 < len(c) and c[p + 1] in OP_PAR_EXTRA:
                    n = 2
                p += 1 + n
        return False

    def is_empty(self):
        return all(len(c) <= 1 for c in self.channels[:USED_CHANNELS])


def parse(d, pos=0, strict=True):
    """d の pos から MCM として読めれば (Song, 使ったバイト数) を返す。読めなければ None

    strict: ブロック数のワードとブロックの数が一致し、各チャンネルのコマンド列が
            ちょうどブロックの最後で終わることも確かめる (ディスクの中を探すとき用)
    """
    hdr = 0
    limit = len(d)
    if pos + 7 <= len(d) and d[pos] == 0xFE:
        start, end = struct.unpack_from('<HH', d, pos + 1)
        if 0 < end - start < MAX_SIZE:
            hdr = 7
            limit = min(limit, pos + 7 + end - start + 1)
    base = pos + hdr
    if base + 6 > limit:
        return None
    nblk = struct.unpack_from('<H', d, base)[0]
    if strict and not 1 <= nblk <= MAX_BLOCKS:
        return None
    p = 2
    links = []
    while True:
        nx = struct.unpack_from('<H', d, base + p)[0]
        if nx < p + 3 or nx >= MAX_SIZE or base + nx + 2 > limit:
            return None
        links.append(p)
        if len(links) > MAX_BLOCKS:
            return None
        p = nx
        if struct.unpack_from('<H', d, base + p)[0] == 0:
            break
    if strict:
        if len(links) != nblk:
            return None
        ends = links[1:] + [p]
        for a, e in zip(links, ends):
            if _stream_end(d, base + a + 2, base + e) != base + e - 1:
                return None
    body = bytes(d[base:base + p + 2])
    return Song(body, links), hdr + p + 2


def load(path):
    """ファイルを読んで Song を返す (形が崩れていても、たどれれば読む)"""
    d = open(path, 'rb').read()
    r = parse(d, 0, strict=False)
    return r[0] if r else None
