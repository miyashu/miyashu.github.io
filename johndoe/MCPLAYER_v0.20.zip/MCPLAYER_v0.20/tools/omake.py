"""MSX-BASIC の PLAY 文で鳴らしている曲を MCM にする (Xak ディスク3 の OMAKE.BAS: おまけゲーム「GoGo ピクシー」のタイトル曲)

ディスクイメージの中の BASIC プログラムを読み、タイトル画面の部分 (USR0 を呼んだ後から GOTO まで) の
SOUND・文字列の代入・PLAY を順に実行して、3 声の MML を MCM のコマンドに置き換える。
  - MSX-BASIC の PLAY は文ごとに 3 声の頭がそろう。書いていない声はその文の長さだけ休む
  - O, L, V などは PLAY 文をまたいで引き継ぐ
  - SOUND 7 でトーンを止めてノイズにした声は、ノイズで鳴らす (周期は SOUND 6)。
    S0 (減衰) のエンベロープは、1 フレームごとに音量を下げて同じように聞こえるようにする
  - 同じ文字列が続く声はループ (62h+回数 ... 72h) にまとめる
  - ドライバのオクターブ = MML のオクターブ - 1 (MSX-BASIC の O1 C は約 65Hz)、音程 = 3 * 半音 + 2
"""
import re
import struct

NOTE = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
PSG_CLOCK = 1789773

# ---------------------------------------------------------------------------
# ディスクイメージ (FAT12) のファイル


def disk_files(d):
    """ディスクイメージのルートのファイル -> {名前: 中身}。FAT でなければ {}"""
    try:
        bps = struct.unpack_from('<H', d, 11)[0]
        spc, res, nf = d[13], struct.unpack_from('<H', d, 14)[0], d[16]
        nroot, spf = struct.unpack_from('<H', d, 17)[0], struct.unpack_from('<H', d, 22)[0]
        if bps != 512 or not spc or not nf or not nroot:
            return {}
        fat = d[res * bps:(res + spf) * bps]
        root = (res + nf * spf) * bps
        data = root + nroot * 32
        out = {}
        for i in range(nroot):
            e = d[root + i * 32:root + i * 32 + 32]
            if e[0] in (0, 0xE5) or e[11] & 0x18:
                continue
            name = e[0:8].decode('latin1').strip() + '.' + e[8:11].decode('latin1').strip()
            c = struct.unpack_from('<H', e, 26)[0]
            size = struct.unpack_from('<I', e, 28)[0]
            body = bytearray()
            n = 0
            while 2 <= c < 0xFF0 and n < 2880 and len(body) < size:
                o = data + (c - 2) * spc * bps
                body += d[o:o + spc * bps]
                o = c * 3 // 2
                v = fat[o] | fat[o + 1] << 8
                c = v >> 4 if c & 1 else v & 0xFFF
                n += 1
            out[name.upper()] = bytes(body[:size])
        return out
    except (IndexError, struct.error):
        return {}


# ---------------------------------------------------------------------------
# MSX-BASIC の中間言語 (使うものだけ文字に戻す)
TOKENS = {0x81: 'END', 0x82: 'FOR', 0x83: 'NEXT', 0x89: 'GOTO', 0x8D: 'GOSUB', 0x8F: "'", 0x97: 'DEF',
          0xC1: 'PLAY', 0xC4: 'SOUND', 0xCF: 'BLOAD', 0xD9: 'TO', 0xDA: 'THEN', 0xDD: 'USR', 0xE6: "'",
          0xEF: '=', 0xF1: '+', 0xF2: '-'}


def detokenize(b):
    """プログラム -> [(行番号, 文字列)]"""
    lines = []
    i = 1
    while i + 4 <= len(b):
        nxt, num = struct.unpack_from('<HH', b, i)
        if nxt == 0:
            break
        i += 4
        s = ''
        quoted = False
        while i < len(b) and b[i] != 0:
            c = b[i]
            i += 1
            if quoted:
                s += chr(c) if 32 <= c < 127 else '?'
                quoted = c != 0x22
                continue
            if c == 0x22:
                quoted = True
                s += '"'
            elif c == 0xFF:
                s += '?'
                i += 1
            elif c == 0x0F:
                s += str(b[i]); i += 1
            elif 0x11 <= c <= 0x1A:
                s += str(c - 0x11)
            elif c == 0x1C or c == 0x0E or c == 0x0D:
                s += str(struct.unpack_from('<H', b, i)[0]); i += 2
            elif c in (0x0B, 0x0C):
                s += '&H' + format(struct.unpack_from('<H', b, i)[0], 'X'); i += 2
            elif c == 0x1D:
                i += 4
            elif c == 0x1F:
                i += 8
            elif c in TOKENS:
                s += ' ' + TOKENS[c] + ' '
            elif 32 <= c < 127:
                s += chr(c)
            else:
                s += ' '
        i += 1
        lines.append((num, s))
    return lines


def split_outside_quotes(s, sep):
    out, cur, q = [], '', False
    for ch in s:
        if ch == '"':
            q = not q
        if ch == sep and not q:
            out.append(cur)
            cur = ''
        else:
            cur += ch
    out.append(cur)
    return out


def number(v):
    v = v.strip().upper()
    if v.startswith('&B'):
        return int(v[2:], 2)
    if v.startswith('&H'):
        return int(v[2:], 16)
    return int(v)


def run_title(lines):
    """USR0 を呼んだ後から GOTO / END までを実行 -> (PLAY 文のリスト [[3 声の文字列 or None]], SOUND のレジスタ)"""
    regs = {}
    strs = {}
    plays = []
    started = False
    for num, text in lines:
        if not started:
            started = 'USR' in text and '0' in text.split('USR', 1)[1][:3]
            continue
        for st in split_outside_quotes(text, ':'):
            st = st.strip()
            if not st or st.startswith("'"):
                continue
            words = st.split()
            head = words[0] if words else ''
            if head in ('GOTO', 'END'):
                return plays, regs
            if head == 'SOUND':
                a, v = st[5:].split(',', 1)
                regs[number(a)] = number(v)
            elif head == 'PLAY':
                args = []
                for a in split_outside_quotes(st[4:], ','):
                    a = a.strip()
                    if a.startswith('"'):
                        args.append(a.strip('"'))
                    else:
                        args.append(strs.get(a.replace(' ', ''), ''))
                plays.append((args + [None, None, None])[:3])
            else:
                m = re.match(r'^([A-Z][A-Z0-9]*\$)\s*=\s*"([^"]*)"?$', st.replace(' =', '=').replace('= ', '='))
                if m:
                    strs[m.group(1)] = m.group(2)
    return plays, regs


# ---------------------------------------------------------------------------
# MML


class Voice:
    """1 声の MML の状態 (O, L, V, T, S, M は PLAY 文をまたいで残る)"""

    def __init__(self):
        self.o, self.l, self.v, self.t, self.s, self.m = 4, 4, 8, 120, None, 255

    def parse(self, mml):
        """MML -> [(種類 'n'/'r', 半音, フレーム数, 音量, エンベロープの M (なければ None))]"""
        out = []
        s = mml.upper()
        i = 0

        def num():
            nonlocal i
            m = re.match(r'\d+', s[i:])
            if not m:
                return None
            i += len(m.group())
            return int(m.group())
        while i < len(s):
            c = s[i]
            i += 1
            if c in NOTE or c == 'R':
                semi = None
                if c != 'R':
                    semi = NOTE[c] + 12 * self.o
                    if i < len(s) and s[i] in '#+':
                        semi += 1
                        i += 1
                    elif i < len(s) and s[i] == '-':
                        semi -= 1
                        i += 1
                n = num()
                length = n if n else self.l
                f = 60 * 60 * 4 / (self.t * length)
                t = f
                while i < len(s) and s[i] == '.':
                    f /= 2
                    t += f
                    i += 1
                out.append(('r' if c == 'R' else 'n', semi, t, self.v,
                            self.m if self.s is not None else None))
            elif c == 'O':
                self.o = num()
            elif c == 'L':
                self.l = num()
            elif c == 'V':
                self.v = num()
                self.s = None
            elif c == 'T':
                self.t = num()
            elif c == 'S':
                self.s = num()
            elif c == 'M':
                self.m = num()
            elif c == '>':
                self.o += 1
            elif c == '<':
                self.o -= 1
        return out


# ---------------------------------------------------------------------------
# MCM


def time_op(n):
    return bytes([0x97 + n]) if n <= 0xF1 - 0x97 else bytes([0xFA, n])


class Ch:
    def __init__(self):
        self.b = bytearray()
        self.t = self.v = self.o = None

    def time(self, n):
        if n != self.t:
            self.b += time_op(n)
            self.t = n

    def vol(self, v):
        if v != self.v:
            self.b += bytes([0x32 + v])
            self.v = v

    def rest(self, n):
        while n > 0:
            k = min(n, 255)
            self.time(k)
            self.b += b'\x25'
            n -= k

    def note(self, semi, n):
        o = semi // 12 - 1
        if o != self.o:
            self.b += bytes([0x28 + o])
            self.o = o
        self.time(n)
        self.b += bytes([3 * (semi % 12) + 2])

    def noise(self, n, vol, env_m, period):
        if env_m is None:
            self.vol(vol)
            self.time(n)
            self.b += bytes([0x42 + period])
            return
        step = 16 * env_m / PSG_CLOCK * 60          # S0: 音量が 1 段下がるフレーム数
        k = 0
        while k < n:
            lv = 15 - int(k / step)
            if lv <= 0:
                break
            self.vol(lv)
            self.time(1)
            self.b += bytes([0x42 + period])
            k += 1
        if k < n:
            self.rest(n - k)


def build(plays, regs):
    """PLAY 文のリスト -> MCM の本体 (12 ブロック: PSG A-C + 空の FM 0-8)"""
    mixer = regs.get(7, 0xB8)
    period = regs.get(6, 0) & 0x1F
    voices = [Voice() for _ in range(3)]
    events = []                                   # 文ごと: 3 声の [(…)] or None、文の長さ
    for p in plays:
        ev = [voices[k].parse(p[k]) if p[k] is not None else None for k in range(3)]
        length = max((sum(round(e[2]) for e in x) for x in ev if x is not None), default=0)
        events.append((ev, length, p))
    chans = []
    for k in range(3):
        is_noise = (mixer >> k) & 1 and not (mixer >> (k + 3)) & 1
        ch = Ch()
        if is_noise:
            # 同じ文字列が続くところはループにまとめる
            i = 0
            while i < len(events):
                j = i
                while (j + 1 < len(events) and events[j + 1][2][k] is not None
                       and events[j + 1][2][k] == events[i][2][k] and j + 1 - i < 15):
                    j += 1
                cnt = j - i + 1
                ev, length, p = events[i]
                if cnt > 1:
                    ch.v = ch.t = None
                    ch.b += bytes([0x62 + cnt])
                    for kind, semi, f, vol, env in ev[k]:
                        ch.rest(round(f)) if kind == 'r' else ch.noise(round(f), vol, env, period)
                    ch.b += b'\x72'
                    ch.v = ch.t = None
                else:
                    if ev[k] is None:
                        ch.rest(length)
                    else:
                        for kind, semi, f, vol, env in ev[k]:
                            ch.rest(round(f)) if kind == 'r' else ch.noise(round(f), vol, env, period)
                i = j + 1
        else:
            ch.b += b'\xf2'                         # 音を最後まで伸ばす
            for ev, length, p in events:
                if ev[k] is None:
                    ch.rest(length)
                    continue
                for kind, semi, f, vol, env in ev[k]:
                    if kind == 'r':
                        ch.rest(round(f))
                    else:
                        ch.vol(vol)
                        ch.note(semi, round(f))
        chans.append(bytes(ch.b))
    chans += [b''] * 9
    blocks = [c + b'\x00' for c in chans]
    offs = []
    p = 2
    for d in blocks:
        offs.append(p)
        p += 2 + len(d)
    body = bytearray(struct.pack('<H', len(blocks)))
    for k, d in enumerate(blocks):
        body += struct.pack('<H', offs[k + 1] if k + 1 < len(blocks) else p) + d
    body += b'\x00\x00'
    return bytes(body)


def convert(basic):
    """BASIC のプログラム (中間言語) -> MCM の本体 (PLAY がなければ None)"""
    plays, regs = run_title(detokenize(basic))
    if not any(any(x for x in p if x) for p in plays):
        return None
    return build(plays, regs)


def find_in_disk(d):
    """ディスクイメージの中の OMAKE.BAS から作った MCM -> [(ファイル名, MCM)]"""
    out = []
    files = disk_files(d)
    for name, body in sorted(files.items()):
        if name == 'OMAKE.BAS' and body[:1] == b'\xff':
            mcm = convert(body)
            if mcm:
                out.append((name, mcm))
    return out
