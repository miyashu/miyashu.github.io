"""MCM 曲データベース — 曲名などを曲の中身 (MD5) で管理する

データベース (mcm_db.csv、UTF-8 BOM 付き。Excel でも開ける) は 1 行が「あるゲームの 1 曲」。
曲は中身 (MD5) で見分ける。同じデータを別のゲームでも使っている (使い回し) ときは、ゲームごとに
1 行ずつあり、曲名などもゲームごとに付けられる (例: Xak II「ハボロネーズの森」とガゼルの塔「森」)。
曲データそのものは入っていないので、データベースとプログラムだけを配って、各自が自分の
ディスクイメージから吸い出し (tools/extract_disks.py)、プレイリストを作ることができる。
ファイル名やディスク上の位置が違っても、中身が同じなら同じ曲として曲名が付く。

使い方 (MicroCabin フォルダで):
  python tools/mcm_db.py sync [player/playlist.txt]      プレイリストの内容をデータベースに反映
  python tools/mcm_db.py playlist [-o player/playlist.txt] [--data data]
                                                          データベースと data フォルダからプレイリストを作る
  python tools/mcm_db.py find ファイル/フォルダ ...        どの曲か調べる (よく似た曲も出す)
  python tools/mcm_db.py add ファイル/フォルダ ... [--folder 名前]
                                                          データベースにない曲を登録する
  共通: --db データベースの CSV (既定: このフォルダの mcm_db.csv)

ふだんの手順: playlist.txt で曲名・並び・除外 (# と理由) を直す -> sync -> build_rom.py
  同じ曲を別のゲームにも入れるには、そのゲームの @game の下に行を書き足す (どのフォルダのファイルでもよい)。
  行を別のゲームの下へ移すと、その曲はそちらのゲームのものになる
(playlist と tools/extract_disks.py も、playlist.txt を作り直す前に今の内容を自動で反映する)

列:
  id        行の番号 (S0001 ...)
  game      ゲーム名 (プレイリストの @game。正式名)
  game_en   英語のゲーム名 (@game ゲーム名 | 英語のゲーム名)
  order     プレイリストでの並び (小さい順。ゲームの並びは、そのゲームの最小の order の順)
  title     曲名
  title_en  英語の曲名 (プレイリストの 5 番目の欄。本体の文字セットが日本以外のときに表示)
  exclude   収録しない理由 (空なら収録する)。プレイリストでは行頭に # を付け、行末に「# 理由」と書く
  loops     ループ回数 (空なら既定)
  drv       (使っていない。以前のドライバの指定)
  note      メモ
  variant_of 別アレンジ・改版の元の曲の id
  folder, file  この曲を収録するときに使う、吸い出したファイル (disk_image のフォルダ名とファイル名)
  files     この曲が見つかった場所すべて (フォルダ/ファイル (ディスク番号 位置))
  ref       参考データ (data_ref) の同じ曲のファイル名
  md5 ...   照合用の値 (本体の MD5、大きさ、チャンネル数、チャンネルごと・出だしの値)

同じ曲の判定:
  完全一致  曲の本体 (BLOAD ヘッダと末尾の詰め物を除き、先頭から終端の 0000 まで) の MD5 が同じ
  よく似た曲 チャンネルごとのデータ、または各チャンネルの出だし 16 バイトの一致数で判定 (find が表示)
"""
import argparse, csv, glob, hashlib, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mcm

DEFAULT_DB = os.path.join(HERE, 'mcm_db.csv')
ROOT = os.path.dirname(HERE)
DEFAULT_PLAYLIST = os.path.join(ROOT, 'player', 'playlist.txt')
DEFAULT_DATA = os.path.join(ROOT, 'data')
INTRO = 16          # 「出だし」として比べるバイト数
MIN_CH = 4          # これより短いチャンネルは空とみなす
SIMILAR = 0.5       # 有効なチャンネルのこの割合以上が一致したら「よく似た曲」

FIELDS = ['id', 'game', 'game_en', 'order', 'title', 'title_en', 'exclude', 'loops', 'drv', 'note', 'variant_of',
          'folder', 'file', 'files', 'ref', 'md5', 'size', 'channels', 'ch_md5', 'ch_intro']

# disk_image のフォルダ名 -> データベースにない曲に付けるゲーム名とドライバ
FOLDER_GAMES = {
    'XAK': 'Xak', 'XAKII': 'Xak II', 'GAZZEL': 'ガゼルの塔',
    'FRAY_M2': 'FRAY', 'FRAY_TR': 'FRAY', 'FRAY_DM': 'FRAY',
    'ILLUSION': '幻影都市', 'FFANTASY': 'ファイナルファンタジー',
    'RISK2': 'キャンペーン版大戦略II', 'PMAKER': 'プリンセスメーカー', 'CABIN': 'The Tower of Cabin',
}
FOLDER_DRV = {'PMAKER': 'B'}


def h8(b):
    return hashlib.md5(b).hexdigest()[:8]


def fingerprint_song(s):
    """mcm.Song -> 照合用の値 (dict)"""
    chans = s.channels
    return {
        'md5': s.md5,
        'size': str(len(s.body)),
        'channels': str(s.blocks),
        'ch_md5': ' '.join(h8(c) if len(c) >= MIN_CH else '-' for c in chans),
        'ch_intro': ' '.join(h8(c[:INTRO]) if len(c) >= MIN_CH else '-' for c in chans),
    }


def similarity(a, b):
    """2 曲の一致度 (0-1) と説明。チャンネルの順番は問わない"""
    best = (0.0, '')
    for key, label in (('ch_md5', 'チャンネル'), ('ch_intro', '出だし')):
        x = [h for h in a[key].split() if h != '-']
        y = [h for h in b[key].split() if h != '-']
        if not x or not y:
            continue
        rest = list(y)
        hit = 0
        for h in x:
            if h in rest:
                rest.remove(h)
                hit += 1
        score = hit / max(len(x), len(y))
        if score > best[0]:
            best = (score, f'{label} {hit}/{max(len(x), len(y))} 一致')
    return best


# ---------------------------------------------------------------------------
# データベースの読み書き
def load_db(path):
    if not os.path.isfile(path):
        return []
    with open(path, encoding='utf-8-sig', newline='') as f:
        return [dict({k: '' for k in FIELDS}, **{k: (v or '') for k, v in row.items() if k in FIELDS})
                for row in csv.DictReader(f)]


def save_db(path, rows):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, FIELDS, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, path)


def add_item(lst, item):
    items = [x for x in lst.split(' | ') if x]
    if item not in items:
        items.append(item)
    return ' | '.join(items)


def order_key(r):
    try:
        return int(r['order'])
    except ValueError:
        return 10 ** 9


def next_id(rows):
    return max([int(r['id'][1:]) for r in rows if r['id'][1:].isdigit()] + [0]) + 1


def new_row(rows, song, folder='', file=''):
    """データベースにない曲の行を作る (まだ rows には足さない)"""
    game = FOLDER_GAMES.get(folder.upper(), folder)
    same = [order_key(r) for r in rows if r['game'] == game and order_key(r) < 10 ** 9]
    order = (max(same) + 1) if same else 100000 + 1000 * len({r['game'] for r in rows})
    return dict({k: '' for k in FIELDS}, id=f'S{next_id(rows):04d}', game=game, order=str(order),
                drv=FOLDER_DRV.get(folder.upper(), ''), folder=folder, file=file,
                **fingerprint_song(song))


def iter_mcm(paths):
    for p in paths:
        if os.path.isdir(p):
            for f in sorted(glob.glob(os.path.join(p, '**', '*'), recursive=True)):
                if os.path.isfile(f) and f.upper().endswith('.MCM'):
                    yield f
        else:
            yield p


def index_data(data_dir):
    """data フォルダの曲 -> {md5: [(フォルダ, ファイル名, パス), ...]}"""
    idx = {}
    for f in iter_mcm([data_dir]):
        s = mcm.load(f)
        if s:
            folder = os.path.basename(os.path.dirname(f))
            idx.setdefault(s.md5, []).append((folder, os.path.splitext(os.path.basename(f))[0], f))
    return idx


# ---------------------------------------------------------------------------
# プレイリスト
def parse_playlist(path):
    """プレイリスト -> [dict(path, game, game_en, title, title_en, loops, drv, exclude, line)]"""
    base = os.path.dirname(os.path.abspath(path))
    out = []
    game = game_en = ''
    with open(path, encoding='utf-8-sig') as f:
        for lineno, raw in enumerate(f, 1):
            s = raw.strip()
            if s.lower().startswith('@game'):
                g = [x.strip() for x in s[5:].split('#', 1)[0].split('|')]
                game = g[0]
                game_en = g[1] if len(g) > 1 else None        # None = 書いていない (データベースのまま)
                continue
            if s.startswith('@'):
                continue                        # @cg, @startup など (read_directives が読む)
            excluded = s.startswith('#')
            body = s.lstrip('#').strip()
            main, _, comment = body.partition('#')
            parts = [p.strip() for p in main.split('|')]
            if not parts[0].upper().endswith('.MCM'):
                continue                        # ふつうのコメント
            out.append(dict(path=os.path.normpath(os.path.join(base, parts[0])), game=game, game_en=game_en,
                            cols=len(parts),
                            title=parts[1] if len(parts) > 1 else '',
                            loops=parts[2] if len(parts) > 2 else '',
                            drv=parts[3].upper() if len(parts) > 3 else '',
                            title_en=parts[4] if len(parts) > 4 else '',
                            exclude=(comment.strip() or '除外') if excluded else '',
                            line=lineno))
    return out


def read_directives(path):
    """プレイリストの @startup, @startup_cg (全体)、@cg (ゲームごと)、@song_cg (曲ごと) の行
    -> (全体の行, {ゲーム名: [行]}, {(ゲーム名, 曲のファイル名): [行]})
    CG や起動時の曲は各自が用意するものなので、データベースには入れず、作り直すときに引き継ぐ"""
    head, per_game, per_song = [], {}, {}
    if not os.path.isfile(path):
        return head, per_game, per_song
    game = None
    song = None
    with open(path, encoding='utf-8-sig') as f:
        for raw in f:
            s = raw.strip()
            low = s.lower()
            if low.startswith('@game'):
                game = s[5:].split('#', 1)[0].split('|')[0].strip()
                song = None
            elif low.startswith('@startup'):
                head.append(s)
            elif low.startswith('@song_cg') and song is not None:
                per_song.setdefault(song, []).append(s)
            elif low.startswith('@cg') and game is not None:
                per_game.setdefault(game, []).append(s)
            else:
                name = s.lstrip('#').strip().split('#', 1)[0].split('|')[0].strip()
                if name.upper().endswith('.MCM'):
                    song = (game, os.path.basename(name).upper())   # 次の @song_cg はこの曲のもの
    return head, per_game, per_song


def make_playlist(rows, data_dir, out_path, full=True):
    """データベースと data フォルダからプレイリストを書く。戻り: (収録, 除外, データベースにない曲) の数
    full=False: 曲の行はファイル名だけにする (曲名・ループ回数などは ROM を作るときにデータベースから引く。
                曲名は行末のコメントに書く)"""
    idx = index_data(data_dir)
    rel_base = os.path.dirname(os.path.abspath(out_path))
    head, per_game, per_song = read_directives(out_path)
    rank = {}
    for r in rows:
        rank[r['game']] = min(rank.get(r['game'], 10 ** 9), order_key(r))
    lines = ['# MICRO CABIN MUSIC PLAYER プレイリスト (tools/mcm_db.py playlist が作成)',
             '# 書式: 曲ファイル | 曲名 | ループ回数 | (使わない) | 英語の曲名   (曲名以降は省略可)',
             '# ドライバと音色はゲームのもの (曲ファイルのフォルダ名のディスクイメージから取り出す)',
             '# 収録しない曲は行頭に # を付け、行末に「# 理由」を書く',
             '# "@game ゲーム名 | 英語のゲーム名" でそれ以降の曲のゲーム名を指定する',
             '# 5 番目の欄は英語の曲名 (本体の文字セットが日本以外のときに表示する)',
             '# "@cg 画像" (@game の後) でそのゲームの CG、"@startup 曲 | 曲名 | 英語の曲名" で起動時の曲、',
             '# "@startup_cg 画像" で起動時の CG を指定する (CG は MSX2 以降で表示)',
             '# "@song_cg 画像" (曲の行の次の行) でその曲を鳴らしている間だけ CG を替える',
             '# 曲名・並び・ゲーム名・除外を直したら python tools/mcm_db.py sync でデータベースに反映する']
    if not full:
        lines = ['# MICRO CABIN MUSIC PLAYER プレイリスト',
                 '# 1 行に 1 曲のファイル。曲名・英語の曲名・ループ回数は ROM を作るときにデータベースから引く',
                 '#   (行末の # の後ろは曲名のメモ。直しても ROM には反映されない)',
                 '# 曲を外すには行を消すか行頭に # を付ける。並びは行の順。',
                 '# "@game ゲーム名" でそれ以降の曲のゲームを指定する ("@game ゲーム名 | 英語の名前" で名前を替えられる)',
                 '# "@cg 画像" (@game の後) でそのゲームの CG、"@song_cg 画像" (曲の行の次の行) でその曲の間だけの CG',
                 '# "@startup 曲" で起動時の曲、"@startup_cg 画像" で起動時の CG (なければ標準の CG)',
                 '# 曲名を直すときは extract_log.txt で曲の id を調べ、tools/mcm_db.csv のその行を直す']
    if head:
        lines += [''] + head
    n_in = n_ex = 0
    game = None
    for r in sorted(rows, key=lambda r: (rank[r['game']], order_key(r), r['id'])):
        locs = idx.get(r['md5'])
        if not locs:
            continue                            # 吸い出していない曲
        path = next((p for fo, fi, p in locs if fo == r['folder'] and fi == r['file']), locs[0][2])
        if r['game'] != game:
            game = r['game']
            lines += ['', f'@game {game}' + (f' | {r["game_en"]}' if r['game_en'] and full else '')]
            lines += per_game.get(game, [])
        rel = os.path.relpath(path, rel_base).replace('\\', '/')
        cols = [r['title'], r['loops'], r['drv'], r['title_en']]
        while cols and not cols[-1]:
            cols.pop()
        text = rel + ('\t| ' + ' | '.join(cols) if cols else '')
        if not full:
            text = rel
            if not r['exclude']:
                name = ' / '.join(x for x in (r['title'], r['title_en']) if x)
                text += f'\t# {name}' if name else ''
        if r['exclude']:
            lines.append(f'#{text}\t# {r["exclude"]}')
            n_ex += 1
        else:
            lines.append(text)
            n_in += 1
        lines += per_song.get((game, os.path.basename(rel).upper()), [])
    known = {r['md5'] for r in rows}
    unknown = [(fo, fi, p) for h, locs in idx.items() if h not in known for fo, fi, p in locs[:1]]
    if unknown:
        lines += ['', '# ---- データベースにない曲 (python tools/mcm_db.py add data で登録できる) ----']
        for fo, fi, p in sorted(unknown):
            lines.append(os.path.relpath(p, rel_base).replace('\\', '/'))
    with open(out_path, 'w', encoding='utf-8', newline='\r\n') as f:
        f.write('\n'.join(lines) + '\n')
    return n_in, n_ex, len(unknown)


# ---------------------------------------------------------------------------
# コマンド
def sync(rows, playlist):
    """プレイリストの内容を rows に反映する (rows はその場で書き換える)。戻り: 説明の文字列

    行は (曲の MD5, ゲーム名) で対応させる。プレイリストに出てきた曲のうち、そのゲームの行が
    プレイリストにないもの (別のゲームへ移した・消した) はデータベースからも消す。
    プレイリストに出てこない曲 (吸い出していない曲) の行はそのまま残す。
    """
    by_key = {(r['md5'], r['game']): r for r in rows}
    changed = {'title': 0, 'title_en': 0, 'game_en': 0, 'exclude': 0, 'loops': 0, 'drv': 0}
    added = 0
    seen = set()
    games = {}                                  # 改名を数える: 前のゲーム名 -> 新しいゲーム名
    for i, e in enumerate(parse_playlist(playlist), 1):
        s = mcm.load(e['path']) if os.path.isfile(e['path']) else None
        if not s:
            print(f'  {playlist}:{e["line"]}: 読めない: {e["path"]}')
            continue
        folder = os.path.basename(os.path.dirname(e['path']))
        file = os.path.splitext(os.path.basename(e['path']))[0]
        game = e['game'] or FOLDER_GAMES.get(folder.upper(), folder)
        key = (s.md5, game)
        if key in seen:
            print(f'  {playlist}:{e["line"]}: 同じゲームに同じ曲が前にもあるので無視: {os.path.basename(e["path"])}')
            continue
        seen.add(key)
        r = by_key.get(key)
        if r is None:
            # 同じ曲がほかのゲームにあれば、照合用の値・見つかった場所を写して行を作る
            base = next((x for x in rows if x['md5'] == s.md5), None)
            r = new_row(rows, s, folder, file)
            if base:
                r.update(files=base['files'], ref=base['ref'], variant_of=base['variant_of'])
            r['game'] = game
            rows.append(r)
            by_key[key] = r
            added += 1
        new = dict(exclude=e['exclude'], order=str(i * 10), folder=folder, file=file)
        for k, col in (('title', 1), ('loops', 2), ('drv', 3), ('title_en', 4)):
            if e['cols'] > col:
                new[k] = e[k]
        if e['game_en'] is not None:
            new['game_en'] = e['game_en']
        for k, v in new.items():
            if r[k] != v:
                if k in changed:
                    changed[k] += 1
                r[k] = v
    # プレイリストに出てきた曲の、プレイリストにないゲームの行を消す
    md5s = {h for h, _ in seen}
    gone = [r for r in rows if r['md5'] in md5s and (r['md5'], r['game']) not in seen]
    for r in gone:
        rows.remove(r)
    return (f'曲名 {changed["title"]}、英語の曲名 {changed["title_en"]}、英語のゲーム名 {changed["game_en"]}、'
            f'除外 {changed["exclude"]}、ループ回数 {changed["loops"]}、'
            f'ドライバ {changed["drv"]} か所を変更、行の追加 {added}、行の削除 {len(gone)}')


def cmd_sync(a):
    rows = load_db(a.db)
    msg = sync(rows, a.playlist)
    save_db(a.db, rows)
    print(f'{a.playlist} を反映しました: {msg} -> {a.db}')


def sync_before_rewrite(rows, playlist, db):
    """プレイリストを作り直す前に、今のプレイリストの内容をデータベースに反映しておく (直した分を失わないため)"""
    if os.path.isfile(playlist):
        msg = sync(rows, playlist)
        save_db(db, rows)
        print(f'今の {playlist} を先にデータベースに反映しました: {msg}')


def cmd_playlist(a):
    rows = load_db(a.db)
    sync_before_rewrite(rows, a.output, a.db)
    n_in, n_ex, n_unk = make_playlist(rows, a.data, a.output)
    print(f'プレイリスト {a.output}: 収録 {n_in} 曲、除外 {n_ex} 曲'
          + (f'、データベースにない曲 {n_unk} 曲 (末尾)' if n_unk else ''))


def show_similar(fp, rows, skip_id=None):
    out = []
    for r in rows:
        if r['id'] == skip_id:
            continue
        s, why = similarity(fp, r)
        if s >= SIMILAR:
            out.append((s, r, why))
    out.sort(key=lambda t: -t[0])
    for s, r, why in out[:3]:
        print(f'      似ている: {r["id"]} {r["title"] or "(曲名なし)"}  [{r["game"]}]  {why}  ({r["folder"]}/{r["file"]})')
    return out


def cmd_find(a):
    rows = load_db(a.db)
    for f in iter_mcm(a.paths):
        s = mcm.load(f)
        if not s:
            print(f'{f}: MCM ではない')
            continue
        fp = fingerprint_song(s)
        same = [r for r in rows if r['md5'] == s.md5]
        if same:
            for r in same:
                print(f'{f}: {r["id"]} {r["title"] or "(曲名なし)"}  [{r["game"]}]'
                      + (f'  除外: {r["exclude"]}' if r['exclude'] else ''))
            show_similar(fp, [r for r in rows if r['md5'] != s.md5])
        else:
            print(f'{f}: 未登録 ({fp["size"]} バイト)')
            if not show_similar(fp, rows):
                print('      似ている曲なし')


def cmd_add(a):
    rows = load_db(a.db)
    by_md5 = {r['md5']: r for r in rows}
    added = 0
    for f in iter_mcm(a.paths):
        s = mcm.load(f)
        if not s:
            print(f'  MCM ではない: {f}')
            continue
        if s.md5 in by_md5:
            continue
        folder = a.folder or os.path.basename(os.path.dirname(os.path.abspath(f)))
        r = new_row(rows, s, folder, os.path.splitext(os.path.basename(f))[0])
        rows.append(r)
        by_md5[s.md5] = r
        added += 1
        print(f'  新しい曲: {r["id"]}  {folder}/{r["file"]}  [{r["game"]}]')
        show_similar(fingerprint_song(s), rows[:-1])
    save_db(a.db, rows)
    print(f'登録 {added} 曲。データベース {len(rows)} 曲: {a.db}')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--db', default=DEFAULT_DB)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('sync', help='プレイリストの内容をデータベースに反映')
    p.add_argument('playlist', nargs='?', default=DEFAULT_PLAYLIST)
    p.set_defaults(fn=cmd_sync)
    p = sub.add_parser('playlist', help='データベースと data フォルダからプレイリストを作る')
    p.add_argument('-o', '--output', default=DEFAULT_PLAYLIST)
    p.add_argument('--data', default=DEFAULT_DATA)
    p.set_defaults(fn=cmd_playlist)
    p = sub.add_parser('find', help='どの曲か調べる')
    p.add_argument('paths', nargs='+')
    p.set_defaults(fn=cmd_find)
    p = sub.add_parser('add', help='データベースにない曲を登録')
    p.add_argument('paths', nargs='+')
    p.add_argument('--folder', help='フォルダ名 (ゲーム名とドライバの既定に使う。省くと親フォルダ名)')
    p.set_defaults(fn=cmd_add)
    a = ap.parse_args()
    a.fn(a)


if __name__ == '__main__':
    main()
