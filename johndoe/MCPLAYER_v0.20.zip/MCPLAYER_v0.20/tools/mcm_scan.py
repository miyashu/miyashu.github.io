"""ディスクイメージ (または任意のバイナリ) から マイクロキャビンの曲データ (MCM) を探して抜き出す

使い方:
  python mcm_scan.py イメージ [イメージ ...] [-o 出力フォルダ] [--all]

ディスクの全位置 (1 バイトごと) を調べる。MCM の形の条件は mcm.py を参照。
既定では FM を使う曲だけを出す (--all で PSG のみの曲も)。
"""
import argparse, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mcm

# 候補: ブロック数のワード (01h-20h, 00h) か BLOAD ヘッダ (FEh)
_CAND = re.compile(rb'(?=[\x01-\x20]\x00|\xfe)', re.S)


def scan(d):
    """d の中の曲を [(位置, Song), ...] で返す (見つけた曲の中は探さない)"""
    found = []
    skip_to = 0
    for m in _CAND.finditer(d):
        pos = m.start()
        if pos < skip_to:
            continue
        r = mcm.parse(d, pos, strict=True)
        if r:
            found.append((pos, r[0]))
            skip_to = pos + r[1]
    return found


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('images', nargs='+')
    ap.add_argument('-o', '--out', help='抜き出した MCM を書くフォルダ')
    ap.add_argument('--all', action='store_true', help='PSG のみの曲も出す')
    a = ap.parse_args()
    seen = {}
    for img in a.images:
        d = open(img, 'rb').read()
        name = os.path.splitext(os.path.basename(img))[0]
        print(f'== {img}')
        for pos, s in scan(d):
            kind = 'FM ' if s.uses_fm() else 'PSG'
            dup = seen.get(s.md5)
            print(f'  {pos:06X}  {len(s.body):5d} バイト  {s.blocks:2d}ch  {kind}'
                  + (f'  (重複: {dup})' if dup else ''))
            if dup or (kind == 'PSG' and not a.all):
                continue
            fn = f'{name}_{pos:06X}.MCM'
            seen[s.md5] = fn
            if a.out:
                os.makedirs(a.out, exist_ok=True)
                open(os.path.join(a.out, fn), 'wb').write(s.body)
    print(f'違う曲 {len(seen)} 曲')


if __name__ == '__main__':
    main()
