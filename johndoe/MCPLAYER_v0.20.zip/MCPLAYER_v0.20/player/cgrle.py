"""CG のランレングス圧縮 (プレーヤーの CgDec で展開する)
  01h-7Fh : 続く n バイトをそのまま
  80h+n   : 続く 1 バイトを n+3 回 (3-130 回)
プレーヤーは 256 バイトずつ展開するので、まとまりは画面のデータの 256 バイトの区切りをまたがない。
そのままのバイトはまとめて OTIR で送るので、ROM のバンク (16KB) の境目もまたがない"""
BANK = 0x4000
LINE = 256


def rle(raw, base=32):
    """base = ROM のバンクの先頭から見た、圧縮したデータの始まりの位置 (前にパレット 32 バイト)"""
    out = bytearray()
    for s in range(0, len(raw), LINE):
        seg = raw[s:s + LINE]
        lit = bytearray()

        def flush():
            nonlocal lit
            while lit:
                pos = base + len(out) + 1            # そのままのバイトの始まり
                room = BANK - pos % BANK             # バンクの終わりまで
                k = min(127, len(lit), room)
                out.append(k)
                out.extend(lit[:k])
                lit = lit[k:]
        i, n = 0, len(seg)
        while i < n:
            j = i
            while j < n and seg[j] == seg[i] and j - i < 130:
                j += 1
            if j - i >= 3:
                flush()
                out.append(0x80 + j - i - 3)
                out.append(seg[i])
                i = j
            else:
                lit.append(seg[i])
                i += 1
        flush()
    return bytes(out)


def unrle(d, n):
    out = bytearray()
    i = 0
    while len(out) < n:
        t = d[i]; i += 1
        if t & 0x80:
            out += bytes([d[i]]) * ((t & 0x7F) + 3); i += 1
        else:
            out += d[i:i + t]; i += t
    return bytes(out)


def check(d, n, base=32):
    """まとまりが 256 バイトの区切り・バンクの境目をまたいでいないか"""
    i = o = 0
    while o < n:
        t = d[i]; i += 1
        k = (t & 0x7F) + 3 if t & 0x80 else t
        assert o // LINE == (o + k - 1) // LINE, ('line', o, k)
        if t & 0x80:
            i += 1
        else:
            a, b = base + i, base + i + t - 1
            assert a // BANK == b // BANK, ('bank', a, b)
            i += t
        o += k
    return True
