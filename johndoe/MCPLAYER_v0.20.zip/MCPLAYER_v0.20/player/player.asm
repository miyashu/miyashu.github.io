;=============================================================================
; MICRO CABIN MUSIC PLAYER  -  MSX メガロムカートリッジ (ASCII16 マッパー)
;
;   バンク0 (4000h-7FFFh 固定) : 本プログラム + プレイリスト表 + 半角フォント
;   バンク1以降                 : ゲームのドライバ、ゲームの表、曲名、曲データ(MCM)、CG、全角フォント
;                                 (ページ1のバンクを一時的に切り替えて RAM へ読む)
;   ページ2 (8000h-BFFFh)       : RAM。ゲームの表 (8xxxh/9xxxh)、演奏中の曲 (A000h-)、
;                                 幻影都市のドライバ (8000h-)
;   ページ3                     : RAM。プレーヤーのワーク (C000h-)、スタック (CCC0h より下)、
;                                 ゲームのドライバ (CCC0h-DDFFh。ワークを含む)
;   ドライバはゲームのディスクイメージから build_rom.py が取り出して入れる (曲を取ったゲームのもの)。
;   曲を鳴らす前に、その曲のドライバを元の番地へ写し、そのゲームの表を写す
;   画面: SCREEN 2 に k8x12L フォント (8x12 ドット) で描く
;   プレイリスト表 (PlaylistTable) は build_rom.py が書き込む。
;
; 組み立て: sjasmplus player.asm  (build_rom.py が自動で実行する)
;=============================================================================

; ---- BIOS ----
RDSLT		equ	000Ch
WRSLT		equ	0014h
ENASLT		equ	0024h
FILVRM		equ	0056h
LDIRVM		equ	005Ch
CHGCLR		equ	0062h
INIGRP		equ	0072h
RSLREG		equ	0138h
SNSMAT		equ	0141h
CHGMOD		equ	005Fh
CHGCPU		equ	0180h		; turboR: CPU の切り替え
INITXT		equ	006Ch		; SCREEN 0
CHPUT		equ	00A2h		; 1 文字出す
KILBUF		equ	0156h
MSXID1		equ	002Bh		; bit7: 0=60Hz 1=50Hz  bit0-3: 文字セット (0=日本)
MSXVER		equ	002Dh		; 0=MSX1 1=MSX2 2=MSX2+ 3=turboR

; ---- システムワーク ----
CLIKSW		equ	0F3DBh
GRPCOL		equ	0F3C9h		; SCREEN 2 の色表アドレス
GRPCGP		equ	0F3CBh		; SCREEN 2 のパターン表アドレス
RG1SAV		equ	0F3E0h
RG8SAV		equ	0FFE7h
RG9SAV		equ	0FFE8h
FORCLR		equ	0F3E9h
BAKCLR		equ	0F3EAh
BDRCLR		equ	0F3EBh
HIMEM		equ	0FC4Ah
H_TIMI		equ	0FD9Fh		; 垂直帰線割込みのフック
EXPTBL		equ	0FCC1h

; ---- ASCII16 マッパー ----
BANK_P1		equ	6000h		; 4000h-7FFFh のバンク切替

; ---- ドライバのコマンド (ここでの番号。ドライバごとの番号は DrvDesc+D_CMDS) ----
CMD_INICHIPS	equ	0		; 音源の初期化
CMD_FADEOUT	equ	1		; フェードアウト (C=速さ)
CMD_CHKMUS	equ	2		; 演奏中か (Z = 止まっている)
CMD_PLAY	equ	3		; 演奏開始 (HL=曲。曲の番地が決まっているドライバは A000h に書き換えてある)

; ---- ゲームのドライバ ----
STACK_TOP	equ	0CCC0h		; スタックはドライバの一番低い番地 (CCC0h) の下
DRV_END		equ	0DE00h		; ドライバが使う RAM の終わり
TBL_LEN		equ	1E0h		; ゲームの表 (エンベロープ 30h + ビブラート 30h + エフェクト 80h + FM 音色 100h)
DRV_MAX		equ	12		; ドライバの数の上限 (DrvDir)
SET_MAX		equ	32		; ドライバと表の組の数の上限 (SetDir)
; DrvDir の 1 件 (build_rom.py が書く。曲を鳴らすときに DrvDesc へ写す)
D_BANK		equ	0		; ドライバのイメージのバンク
D_ADDR		equ	1		; バンク内アドレス
D_BASE		equ	3		; 置く番地
D_COPY		equ	5		; 写す長さ
D_CLEAR		equ	7		; その後ろを 0 にする長さ (ワーク)
D_INT		equ	9		; 割込み処理
D_CMD		equ	11		; コマンドの入口
D_CMDS		equ	13		; コマンド番号 (初期化, フェードアウト, 演奏中か, 演奏開始)
D_STRIDE	equ	17		; チャンネルのワークの大きさ
D_CNT		equ	19		; チャンネルのワークのループ回数の位置 (次がループ先)
D_TBLRAM	equ	20		; 表を置く番地
D_CHN		equ	22		; 曲のチャンネルのワーク (12 個)
D_CHACT		equ	24		; 処理中のチャンネル番号 (80h-82h=PSG 0-8=FM)
D_FADEPASS	equ	26		; フェードの段数
D_FADECTL	equ	28		; フェードの制御 (bit7=フェードアウト中)
D_SHDFME	equ	30		; FM 0Eh の写し
D_WORK		equ	32		; 0 にするワークの先頭 (長さは D_CLEAR)
D_RHY		equ	34		; チャンネルのワークのリズムの印 (bit5) の位置。0FFh = ch6-8 は常にリズム
D_PAGE1		equ	35		; 1 = ページ1で動くドライバ (ファイナルファンタジー)。呼ぶ間だけページ1を RAM にする
DRV_DESC	equ	40
SONG_RAM	equ	0A000h		; 曲データを置く RAM (最大 2000h バイト)

; ---- 設定 ----
ENTRY_SIZE	equ	12		; プレイリスト1曲分のバイト数
FADE_SPEED	equ	10		; フェードアウト: 1段あたりの割込み数 (x16段)
MAX_SECONDS	equ	600		; これ以上演奏したら強制フェードアウト
GAP_FRAMES	equ	40		; 曲間の無音フレーム数
TITLE_BYTES	equ	70		; 曲名の最大バイト数 (全角は2バイト)
TITLE_BUF	equ	TITLE_BYTES*2+2	; 曲名 (日本語\0英語\0) を読む大きさ

; プレイリスト表 (PlaylistTable)
;  +0,+1 曲数
;  +2    設定 (bit0 = 自動再生: 起動時の曲が終わったら、リストの先頭の曲から鳴らす)
;  +3-+6 (使っていない)
;  +7    全角フォントの先頭バンク
;  +8    起動時の曲 (ENTRY_SIZE バイト。曲データのバンク 0 = なし)
;  +20   起動時の CG (バンク, 画面モード, 文字色, 背景色。バンク 0 = なし)
;  +24 から 1曲 ENTRY_SIZE バイト:
;  +0 曲データのバンク  +1,+2 曲データのアドレス  +3,+4 曲データの長さ
;  +5 曲名のバンク      +6,+7 曲名のアドレス (日本語\0英語\0。英語は空でもよい)
;  +8 ループ回数 (0=曲が自然に終わるか時間切れまで)
;  +9 ドライバと表の組の番号 (SetDir の 1 から)
;  +10,+11 ゲームの情報のアドレス (バンク0 内。0=なし)
;     ゲームの情報: +0 CG のバンク (0=なし) +1 画面モード (5/7/8) +2 文字色 +3 背景色
;                   +4 ゲーム名 (日本語\0英語\0)
; CG はバンクの先頭から続けて置く (SCREEN 5: 27136 バイト + パレット 32 バイト / SCREEN 8: 54272 バイト /
;  SCREEN 7 (512x212): 54272 バイト + パレット 32 バイト)
PL_FLAGS	equ	2
PL_GLYPH_BANK	equ	7
AUTO_WAIT	equ	180		; 自動再生で起動時の曲がないとき、CG を見せておくフレーム数
PL_STARTUP	equ	8
PL_TITLECG	equ	20
PL_ENTRIES	equ	24
G_CGBANK	equ	0
G_CGMODE	equ	1
G_FG		equ	2
G_BG		equ	3
G_NAME		equ	4
E_SBANK		equ	0
E_SADDR		equ	1
E_SLEN		equ	3
E_TBANK		equ	5
E_TADDR		equ	6
E_LOOPS		equ	8
E_DRV		equ	9
E_GAME		equ	10

		output	"player.bin"

		org	4000h
;=============================================================================
; ROM ヘッダ
		db	"AB"
		dw	Init
		dw	0, 0, 0
		ds	6, 0
; 表示する言語 (ROM の 001Eh。build_rom.py の --lang でも変えられる)
;  0 = 本体の文字セットで決める (日本なら日本語、それ以外は英語)  1 = 常に英語  2 = 常に日本語
		db	"MCPLAYER LANG:"
LangCfg:	db	0
		assert	LangCfg = 401Eh
; クレジット (表示はしない。H キーのヘルプにも同じ内容を出す)
		db	0, "MICRO CABIN MUSIC PLAYER Ver 0.20 / "
		db	"Sound: original MICRO CABIN drivers (driver disassembly: Roberto Vargas) / "
		db	"Thanks: Manuel Pazos, Patriek Lesparre / "
		db	"All music (C) MICRO CABIN Corp. Thank you for the wonderful music!", 0

;=============================================================================
Init:		di
		ld	sp, STACK_TOP	; スタックはドライバの下 (C000h からのワークとの間)

		; マッパーが ASCII16 か確かめる (ESERAMair などで 8KB バンクのまま起動したとき)。
		; 違うマッパーでは 6000h-7FFFh に ROM の正しい部分が見えず、そこのルーチンを呼ぶと暴走するので、
		; ここまでと MapCheck・MapError は ROM の先頭 8KB (4000h-5FFFh) に置き、6000h 以降は使わない
		ld	hl, MapChkImg
		ld	de, MapChk
		ld	bc, MAPCHK_SIZE
		ldir
		call	MapChk		; Z = ASCII16
		jp	nz, MapError

		; ページ2(8000h-BFFFh)をページ3と同じスロットの RAM にする
		; (曲データをここに置く)
		call	RSLREG
		rlca
		rlca
		and	3		; ページ3の基本スロット
		ld	c, a
		ld	b, 0
		ld	hl, EXPTBL
		add	hl, bc
		bit	7, (hl)
		jr	z, .notExp
		set	7, c
		inc	hl
		inc	hl
		inc	hl
		inc	hl		; SLTTBL
		ld	a, (hl)
		rrca
		rrca
		rrca
		rrca
		and	0Ch		; ページ3の拡張スロット番号
		or	c
		ld	c, a
.notExp:	ld	a, c
		ld	(RamSlotId), a
		ld	h, 80h
		call	ENASLT

		; RAM ワーク初期化 (RamSlotId は残す)
		ld	a, (RamSlotId)
		ld	hl, RAM_START
		ld	de, RAM_START+1
		ld	bc, RAM_END-RAM_START-1
		ld	(hl), 0
		ldir
		ld	(RamSlotId), a

		; バンク読み出しルーチンを RAM へ
		ld	hl, RamCopyImg
		ld	de, RamCopy
		ld	bc, RAMCOPY_SIZE
		ldir
		ld	hl, CgDecImg
		ld	de, CgDec
		ld	bc, CGDEC_SIZE
		ldir
		ld	hl, RamHooksImg
		ld	de, RamHooks
		ld	bc, RAMHOOKS_SIZE
		ldir
		; ページ1を RAM にするときの A8h と拡張スロットの値 (ページ3と同じ RAM)
		in	a, (0A8h)
		ld	(P1RomA8), a
		and	0F3h
		ld	b, a
		ld	a, (RamSlotId)
		and	3
		rlca
		rlca
		or	b
		ld	(P1RamA8), a
		ld	a, (RamSlotId)
		and	80h
		ld	(P1Exp), a
		jr	z, .p1ne
		ld	a, (0FFFFh)	; ページ3の基本スロット (= RAM) の拡張スロットの選択
		cpl
		ld	(P1SubRom), a
		and	0F3h
		ld	b, a
		ld	a, (RamSlotId)
		and	0Ch
		or	b
		ld	(P1SubRam), a
.p1ne:		call	P1Test		; ページ1に RAM があるか (P1Ok)

		; 割込み周波数 (60/50Hz): MSX1 は本体の ID、MSX2 以降は VDP の設定 (R#9 bit1 = PAL)
		ld	a, (MSXVER)
		or	a		; Z = MSX1 (rrca・rlca は Z を変えない)
		ld	a, (RG9SAV)
		rrca
		rrca			; CY = PAL (MSX2 以降)
		jr	nz, .id
		ld	a, (MSXID1)
		rlca			; CY = 50Hz (MSX1)
.id:		ld	a, 60
		jr	nc, .hz
		ld	a, 50
.hz:		ld	(FPS), a
		; 表示する言語 (LangCfg。0 なら文字セットが日本以外で英語) と MSX のバージョン
		ld	a, (LangCfg)
		dec	a
		jr	z, .en		; 1: 常に英語
		dec	a
		jr	z, .ja		; 2: 常に日本語
		ld	a, (MSXID1)
		and	0Fh
		jr	z, .ja
.en:		ld	a, 1
		jr	.lang
.ja:		xor	a
.lang:		ld	(LangEn), a
		ld	a, (MSXVER)
		ld	(MsxVer), a

		; 画面: SCREEN 2
		xor	a
		ld	(CLIKSW), a
		call	BlackPalette	; 描いている途中を見せない (MSX2 以降)
		call	InitScreen

		; ページ2に RAM があるか
		ld	hl, 0BFFFh
		ld	(hl), 0AAh
		ld	a, (hl)
		cp	0AAh
		jr	nz, .noRam
		ld	(hl), 55h
		ld	a, (hl)
		cp	55h
		jr	z, .ramOk
.noRam:		ld	hl, MsgNoRam
		call	ShowMessage
		ei
.stop0:		halt
		jr	.stop0
.ramOk:
		; turboR は Z80 モードにする (ゲームのドライバは FM 音源へ待たずに書くため)
		ld	a, (MsxVer)
		cp	3
		jr	c, .noTR
		ld	a, 80h		; Z80 (LED も切り替える)
		call	CHGCPU
		di
.noTR:
		; ドライバはまだない (コマンドは A=0・Z で戻り、割込みは何もしない)
		call	NoDriver
		ld	a, 0FFh
		ld	(LoadedDrv), a
		; 音源初期化
		call	FMSearch
		call	Silence

		call	DrawStatic
		call	SetupMeters

		ld	hl, (PlaylistTable)
		ld	a, h
		or	l
		jr	nz, .haveSongs
		ld	hl, MsgNoSongs
		call	ShowMessage
		ei
.stop:		halt
		jr	.stop
.haveSongs:
		ld	hl, 0
		ld	(CurIdx), hl
		ld	(SelIdx), hl
		call	SetViewFromSel
		call	DrawGameSel

		; 割込みフック: 元の 5 バイトを OldTimi に写して jp IntHook を書く
		di
		ld	hl, H_TIMI
		ld	de, OldTimi
		ld	bc, 5
		ldir
		ld	a, 0C3h
		ld	(H_TIMI), a
		ld	hl, IntHook
		ld	(H_TIMI+1), hl
		; HIMEM がドライバの終わりより下なら、その上はシステム (ディスク等) のワークで
		; ドライバと重なっている。元のフックはそのワークを使うので呼ばない
		ld	hl, (HIMEM)
		ld	de, DRV_END
		or	a
		sbc	hl, de
		jr	nc, .chain
		ld	a, 0C9h		; ret
		ld	(OldTimi), a
.chain:		ld	a, 0FFh		; 起動時に押していたキーは離すまで無視する
		ld	(KeyBlock), a
		call	ScanKeys
		xor	a
		ld	(KeyHit), a
		ei

;-----------------------------------------------------------------------------
; 起動時の画面と曲 (プレイリストの @startup_cg と @startup)
;  起動時の CG は必ずある (指定がなければ build_rom.py が標準の CG を入れる)。曲はないこともある
;  V9990 / V9968 (I/O 88h) があれば: 内蔵 VDP は曲選択の画面、そちらに起動時の CG を出し、曲があれば 1 周だけ鳴らす
;  MSX2 以降: 起動時の CG を出し、曲があればループで鳴らす (なければ無音)。何かキーで曲選択へ
;  それ以外 (MSX1): 曲選択の画面で、曲があれば 1 周だけ鳴らす (SPACE で選んだ曲に切り替え)
		call	V9Detect
		ld	a, (HasExtVdp)
		or	a
		jr	z, .noV9
		ld	hl, PlaylistTable+PL_TITLECG
		call	V9ShowCG
		jr	.list		; CG は V9990 に出しているので、内蔵 VDP は曲選択の画面
.noV9:		ld	a, (MsxVer)
		or	a
		jr	z, .list
		ld	a, (PlaylistTable+PL_TITLECG+G_CGBANK)
		or	a
		jr	z, .list
		ld	a, VIEW_TITLE
		ld	(ViewMode), a
		ld	hl, PlaylistTable+PL_TITLECG
		call	ShowCG
		call	AnyKey		; 今押されているキーは無視する
		ld	(AnyPrev), a
		ld	a, (PlaylistTable+PL_STARTUP+E_SBANK)
		or	a
		jp	nz, PlayStartup	; パレットは CG のもの
		jp	FrameLoop	; 曲なし: CG を出したまま、何かキーで曲選択へ (TitleLoop)
.list:		call	ListPalette	; 曲選択の画面を見せる
		ld	a, (PlaylistTable+PL_STARTUP+E_SBANK)
		or	a
		jp	nz, PlayStartup
		ld	a, (PlaylistTable+PL_FLAGS)	; 自動再生: リストの先頭の曲から
		and	1
		jp	nz, AutoStart
		jp	GoIdle

; 停止状態にして操作を待つ
GoIdle:		xor	a
		ld	(Playing), a
		ld	(IsStartup), a
		call	DrawPlayInfo
		jp	FrameLoop

;=============================================================================
; 1曲を開始する (CurIdx)
PlaySong:
		xor	a
		ld	(IsStartup), a
		ld	hl, (CurIdx)
		call	GetEntry	; HL = 曲のエントリ
		jr	PlayEntry
; 起動時の曲を鳴らす
PlayStartup:	ld	a, 1
		ld	(IsStartup), a
		ld	hl, PlaylistTable+PL_STARTUP
; エントリ HL の曲を鳴らす
PlayEntry:	push	hl
		di			; 割込みでドライバを動かすのを止める
		xor	a
		ld	(IntOn), a
		ld	(FadeDone), a
		ld	(Ticks), a
		ei
		ld	a, (SkipSilence)	; 前の曲が終わって次へ進むときは、もう鳴っていないので初期化しない
		or	a
		call	z, Silence
		xor	a
		ld	(SkipSilence), a
		pop	hl
		ld	de, CurEntry
		ld	bc, ENTRY_SIZE
		ldir

		; 状態クリア
		xor	a
		ld	(Fading), a
		ld	(StopAfter), a
		ld	(FrameCnt), a
		ld	(LastMinLoop), a
		ld	hl, 0
		ld	(Seconds), hl
		ld	hl, LoopCnt
		ld	de, LoopCnt+1
		ld	bc, 11
		ld	(hl), a
		ldir
		ld	a, 1
		ld	(Playing), a

		call	V9SongCG
		call	DrawPlayInfo

		; 曲のドライバとゲームの表を用意し、曲データを RAM へ写して演奏開始
		call	LoadSet
		ld	a, (CurEntry+E_SBANK)
		ld	hl, (CurEntry+E_SADDR)
		ld	bc, (CurEntry+E_SLEN)
		ld	de, SONG_RAM
		di
		call	RamCopy
		ei
		call	CalcChUsed
		ld	a, 0FFh		; チャンネル名を描き直す (色)
		ld	(MtLabelMode), a
		ld	hl, SONG_RAM
		ld	a, CMD_PLAY
		call	DrvCmd
		xor	a
		ld	(Silenced), a
		inc	a
		ld	(IntOn), a	; 以後ドライバは割込み (IntHook) で動く

;-----------------------------------------------------------------------------
; 毎フレームの処理 (ドライバは割込みで動くので、ここが遅れても曲は止まらない)
FrameLoop:
		ei
		halt
		ld	a, (ViewMode)
		cp	VIEW_TITLE
		jp	z, TitleLoop
		ld	a, (Playing)
		or	a
		jp	z, Idle
		call	MetersIfList

		; フェードアウトが最小音量まで進んだら (IntHook がドライバを止めている)、
		; ドライバの終了処理を待たずに音を止める。
		; ドライバはフェード終了時に変数を初期化し、FM 0Eh をリズムモード (20h) に
		; 書き換える。リズムモードを切っていた曲 (PMAKER など) では、鳴っていた
		; ch6-8 がリズム音に化けて「ポン」と鳴るため、その手前で止める。
		ld	a, (FadeDone)
		or	a
		jr	z, .noFadeEnd
		call	Silence
		jp	SongEnded
.noFadeEnd:
		call	TickTime
		call	KeyInput	; A = KEY_NONE / KEY_PLAY / KEY_STOP / KEY_VIEW
		cp	KEY_PLAY
		jp	z, PlaySelected
		cp	KEY_STOP
		jp	z, StopFade
		cp	KEY_VIEW
		call	z, ToggleView

		; 曲が終わったか (全チャンネル停止 かつ フェード中でない)
		ld	a, CMD_CHKMUS
		call	DrvCmd
		jp	z, SongEnded

		ld	a, (Fading)
		or	a
		jp	nz, FrameLoop

		; ループ回数の確認
		call	CalcMinLoop	; A = 演奏中チャンネルの最小ループ回数
		ld	hl, LastMinLoop
		cp	(hl)
		jr	z, .noLoopChg
		ld	(hl), a
		call	DrawLoop
.noLoopChg:
		ld	a, (IsStartup)	; 起動時の曲 (曲選択の画面): 1 周したらすぐ止める
		or	a
		jr	z, .normal
		ld	a, (LastMinLoop)
		cp	255
		jp	z, FrameLoop
		or	a
		jp	nz, StartupDone
		jp	FrameLoop
.normal:	ld	a, (LastMinLoop)
		cp	255
		jr	z, .chkTime	; 演奏中のチャンネルなし (まもなく自然に終わる)
		ld	a, (CurEntry+E_LOOPS)
		or	a
		jr	z, .chkTime	; 0 = ループ回数で止めない
		ld	b, a
		ld	a, (LastMinLoop)
		cp	b
		jr	nc, StartFade
.chkTime:
		ld	hl, (Seconds)
		ld	de, MAX_SECONDS
		or	a
		sbc	hl, de
		jp	c, FrameLoop

StartFade:
		ld	c, FADE_SPEED
		ld	a, CMD_FADEOUT
		call	DrvCmd
		ld	a, 1
		ld	(Fading), a
		jp	FrameLoop

; SPACE: 再生中の曲を選んでいたらフェードアウトして止める
StopFade:	ld	a, 1
		ld	(StopAfter), a
		ld	a, (Fading)
		or	a
		jp	nz, FrameLoop
		ld	c, 2
		ld	a, CMD_FADEOUT
		call	DrvCmd
		ld	a, 1
		ld	(Fading), a
		jp	FrameLoop

; SPACE: 選んでいる曲をすぐ鳴らす
PlaySelected:	ld	hl, (SelIdx)
		ld	(CurIdx), hl
		jp	PlaySong

; 停止中
Idle:		call	MetersIfList
		call	KeyInput
		cp	KEY_PLAY
		jp	z, PlaySelected
		cp	KEY_VIEW
		call	z, ToggleView
		jp	FrameLoop

; 起動時の CG を表示中: 何かキーが押されたら曲を止めて曲選択の画面へ。曲は終わったら頭から
TitleLoop:	di			; 貯まったキーは捨てる (下の AnyKey で見る)
		xor	a
		ld	(KeyHit), a
		ei
		call	AnyKey
		ld	hl, AnyPrev
		ld	b, (hl)
		ld	(hl), a
		or	a
		jr	z, .noKey
		ld	a, b
		or	a
		jr	z, .exit	; 新しく押された
.noKey:		ld	a, (PlaylistTable+PL_STARTUP+E_SBANK)
		or	a
		jr	nz, .song
		ld	a, (PlaylistTable+PL_FLAGS)	; 起動時の曲なし (無音)。自動再生なら少し CG を見せてから
		and	1
		jp	z, FrameLoop
		ld	hl, AutoWait
		inc	(hl)
		ld	a, (hl)
		cp	AUTO_WAIT
		jp	c, FrameLoop
		jr	.auto
.song:		ld	a, (FadeDone)
		or	a
		jr	nz, .again
		call	TickTime
		ld	a, CMD_CHKMUS
		call	DrvCmd
		jp	nz, FrameLoop
.again:		ld	a, (PlaylistTable+PL_FLAGS)	; 自動再生: 起動時の曲は 1 回で、リストの先頭の曲へ
		and	1
		jr	nz, .auto
		call	Silence
		jp	PlayStartup
.auto:		call	StopSound
		call	ClearCur
		xor	a
		ld	(Playing), a
		ld	(IsStartup), a
		call	ReturnToList
		jp	AutoStart
.exit:		call	HKeyDown	; H: 起動時の曲は止めずに、曲選択の画面にしてヘルプを出す
		jr	nz, .help
		di			; 抜けるのに押したキーは、離すまで曲選択の操作にしない
		ld	a, 0FFh
		ld	(KeyBlock), a
		xor	a
		ld	(KeyHit), a
		ei
		call	StopSound
		call	ClearCur
		xor	a
		ld	(Playing), a
		ld	(IsStartup), a
		call	ReturnToList
		jp	FrameLoop
.help:		di
		xor	a
		ld	(KeyHit), a
		ld	(KeyHHit), a
		ld	(LastMinLoop), a
		ld	hl, LoopCnt	; ループの数え直し: この先 1 周したら止める (曲選択の画面で鳴らす起動時の曲と同じ)
		ld	de, LoopCnt+1
		ld	bc, 11
		ld	(hl), a
		ldir
		ei
		call	ReturnToList
		call	HelpOpen	; 押している H は離すまで見ない
		jp	FrameLoop

; H キーを押しているか (NZ = 押している。キーマトリクスの行 3 bit5)
HKeyDown:	di
		in	a, (0AAh)
		ld	b, a
		and	0F0h
		or	3
		out	(0AAh), a
		in	a, (0A9h)
		ld	c, a
		ld	a, b
		out	(0AAh), a
		ei
		ld	a, c
		cpl
		and	20h
		ret

; 音をすぐ止める (割込みのドライバも止める)
StopSound:	di
		xor	a
		ld	(IntOn), a
		ei
		jp	Silence

; 起動時の曲が終わった: 自動再生ならリストの先頭の曲から鳴らす。そうでなければ停止状態へ
StartupDone:	ld	a, (PlaylistTable+PL_FLAGS)
		and	1
		jr	z, StopNow
		call	StopSound
		call	ClearCur
; リストの先頭の曲から鳴らす (再生モードは ALL / REPEAT のまま、最後まで行ったら先頭へ)
AutoStart:	xor	a
		ld	(IsStartup), a
		ld	hl, 0
		ld	(CurIdx), hl
		ld	(SelIdx), hl
		call	SetViewFromSel
		call	DrawGameSel
		jp	PlaySong

; 起動時の曲を止めて停止状態へ (TRACK・LOOP・TIME は空に戻す)
StopNow:	call	StopSound
		call	ClearCur
		jp	GoIdle

; 再生中の曲の情報を消す
ClearCur:	ld	hl, CurEntry
		ld	de, CurEntry+1
		ld	bc, ENTRY_SIZE-1
		ld	(hl), 0
		ldir
		xor	a
		ld	(LastMinLoop), a
		ld	(FrameCnt), a
		ld	hl, 0		; チャンネル名は全部灰色に
		ld	(ChUsed), hl
		ld	a, 0FFh
		ld	(MtLabelMode), a
		xor	a
		ld	hl, 0
		ld	(Seconds), hl
		ret

; 曲が終わった (自然に終わった / ループ回数・時間でフェードした / SPACE で止めた)
SongEnded:	di
		xor	a
		ld	(IntOn), a
		ei
		ld	a, (IsStartup)
		or	a
		jp	nz, StartupDone	; 起動時の曲が終わった
		ld	a, (StopAfter)
		or	a
		jr	z, .next
.stop:		xor	a		; SPACE で止めた / 再生モードで終わり: 停止状態にする
		ld	(SkipSilence), a
		ld	(Playing), a
		ld	(StopAfter), a
		ld	(Fading), a
		call	DrawPlayInfo
		jp	FrameLoop
.next:		ld	a, 1		; 次の曲の前に音源を初期化しない (自然に終わった曲の余韻を切ると「プチッ」と鳴る)
		ld	(SkipSilence), a
		ld	b, GAP_FRAMES
.gap:		ei
		halt
		push	bc
		call	MetersIfList
		pop	bc
		djnz	.gap
		; 選択が再生中の曲にあれば、選択も次の曲へ進める
		ld	hl, (SelIdx)
		ld	de, (CurIdx)
		or	a
		sbc	hl, de
		push	af
		call	NextByMode	; CY = 再生モードで終わり
		jr	c, .end
		pop	af
		jp	nz, PlaySong
		ld	hl, (CurIdx)
		ld	(SelIdx), hl
		call	SetViewFromSel
		call	DrawGameSel
		jp	PlaySong
.end:		pop	af
		jr	.stop

;=============================================================================
; 音を止める (ドライバの変数とチップを初期化)
; ドライバの inichips は FM の音量を最小にするだけでキーオフしないため、
; 前の曲の音が小さく鳴り続け、次の曲が音色を書き換えたときに雑音になる。
; ここで FM の全チャンネルとリズムをキーオフし、PSG の音量も 0 にする。
Silence:	ld	a, (Silenced)	; 演奏後の最初の1回だけ、初期化される前に
		or	a		; 今の曲のリズムモードを覚える (2回目以降は
		jr	nz, .keepMode	; ドライバの初期化で 20h に戻っているため)
		call	GetRhyMode
		ld	(RhyMode), a
		ld	a, 1
		ld	(Silenced), a
.keepMode:	ld	a, CMD_INICHIPS
		call	DrvCmd
; チップだけ止める (RhyMode のリズムモードにする)
SilenceChips:	di
		ld	b, 20h		; FM 20h-28h: キーオフ (サスティンも切る)
.keyOff:	xor	a
		call	WriteFM
		inc	b
		ld	a, b
		cp	29h
		jr	c, .keyOff
		ld	b, 0Eh		; リズム: モードは今の曲のまま (切り替えると「ポン」と鳴る)、キーは全部オフ
		ld	a, (RhyMode)
		call	WriteFM
		; リズム音量 36h-38h を全部最小にする。inichips は 37h/38h に 0Fh を書くため
		; HH/TOM (上位4ビット) が最大音量になり、余韻の残るタム等が「ポン」と鳴る
		ld	b, 36h
.rhyVol:	ld	a, 0FFh
		call	WriteFM
		inc	b
		ld	a, b
		cp	39h
		jr	c, .rhyVol
		ld	b, 8		; PSG R8-R10: 音量 0
		xor	a
		call	WritePSG
		inc	b
		call	WritePSG
		inc	b
		call	WritePSG
		ei
		ret

; 現在の曲のドライバにコマンドを送る (A=番号, HL/C=パラメータ)
; 戻りのフラグはドライバのものをそのまま返す
; A = CMD_* (ドライバごとの番号に直す)。ドライバがなければ何もしない
DrvCmd:		di			; 割込みのドライバ処理と重ならないように
		push	hl
		ld	hl, DrvDesc+D_CMDS
		add	a, l
		ld	l, a
		jr	nc, .n
		inc	h
.n:		ld	a, (hl)
		pop	hl
		call	DrvJpCmd
		ei
		ret

;-----------------------------------------------------------------------------
; 割込みフック (H.TIMI。BIOS がレジスタを全部保存してから呼ぶ。A = VDP の状態)
;  - 演奏中 (IntOn) はドライバの割込み処理と経過フレームの計数
;  - フェードが最小音量 (段数 0Fh) まで進んだらドライバを止めて FadeDone を立てる
;    (ドライバに終了処理をさせない。続きは本体の FrameLoop が Silence する)
;  - キーを読み、新しく押されたキーを KeyHit に貯める (描画中でも取りこぼさない)
IntHook:	push	af
		ld	a, (IntOn)
		or	a
		jr	z, .keys
		call	DrvInt
		ld	a, (FPS)	; PAL (50Hz): 割込み 5 回に 1 回ドライバをもう一度動かして 60 回/秒にする
		cp	50
		jr	nz, .tick
		ld	hl, PalCnt
		inc	(hl)
		ld	a, (hl)
		cp	5
		jr	c, .tick
		ld	(hl), 0
		call	DrvInt
.tick:		ld	hl, Ticks
		inc	(hl)
		ld	a, (Fading)
		or	a
		jr	z, .keys
		call	GetFadePass
		cp	0Fh
		jr	c, .keys
		xor	a
		ld	(IntOn), a
		inc	a
		ld	(FadeDone), a
.keys:		call	ScanKeys
		pop	af
		jp	OldTimi		; 元のフック

; キーマトリクスを PPI から直接読む (行の選択 AAh は元に戻す)
;  行6: bit0=SHIFT
;  行8: bit0=SPACE bit4=← bit5=↑ bit6=↓ bit7=→   (0=押されている)
;  行9: bit7=テンキー4 bit5=テンキー2
;  行10: bit3=テンキー8 bit1=テンキー6
ScanKeys:	in	a, (0AAh)
		ld	b, a
		and	0F0h
		ld	c, a
		; 行3 bit2=E  行4 bit7=R  行5 bit3=V
		ld	e, 0
		or	3
		out	(0AAh), a
		in	a, (0A9h)
		ld	l, a		; 行3 (H を見るのに使う)
		bit	2, a
		jr	nz, .noE
		set	5, e
.noE:		ld	a, l		; H (行3 bit5): 新しく押されたら KeyHHit
		cpl
		and	20h
		ld	h, a
		ld	a, (KeyHPrev)
		cpl
		and	h
		jr	z, .noH
		ld	(KeyHHit), a
.noH:		ld	a, h
		ld	(KeyHPrev), a
		ld	a, c
		or	4
		out	(0AAh), a
		in	a, (0A9h)
		bit	7, a
		jr	nz, .noR
		set	6, e
.noR:		ld	a, c
		or	5
		out	(0AAh), a
		in	a, (0A9h)
		bit	3, a
		jr	nz, .noV
		set	7, e
.noV:		ld	a, c
		or	6
		out	(0AAh), a
		in	a, (0A9h)
		cpl
		and	1
		ld	(KeyShift), a
		ld	a, c
		or	8
		out	(0AAh), a
		in	a, (0A9h)
		cpl
		ld	d, a		; D = 行8
		ld	a, c
		or	9
		out	(0AAh), a
		in	a, (0A9h)
		cpl
		ld	h, a		; H = 行9
		ld	a, c
		or	10
		out	(0AAh), a
		in	a, (0A9h)
		cpl
		ld	l, a		; L = 行10
		ld	a, b
		out	(0AAh), a
		; 押されているキーを K_* にまとめる
		bit	5, d
		jr	nz, .up
		bit	3, l
		jr	z, .noUp
.up:		set	0, e
.noUp:		bit	6, d
		jr	nz, .dn
		bit	5, h
		jr	z, .noDn
.dn:		set	1, e
.noDn:		bit	4, d
		jr	nz, .lt
		bit	7, h
		jr	z, .noLt
.lt:		set	2, e
.noLt:		bit	7, d
		jr	nz, .rt
		bit	1, l
		jr	z, .noRt
.rt:		set	3, e
.noRt:		bit	0, d
		jr	z, .noSp
		set	4, e
.noSp:		; 起動時から押し続けているキー (KeyBlock) は、一度離すまで無視する
		ld	a, (KeyBlock)
		and	e
		ld	(KeyBlock), a
		cpl
		and	e
		ld	e, a
		; 今回押されたキー = 押されている and not 前回
		ld	a, (KeyPrev)
		cpl
		and	e
		ld	c, a
		ld	a, e
		ld	(KeyPrev), a
		; ↑↓ のリピート
		and	K_UP+K_DOWN
		jr	z, .noRep
		ld	hl, KeyRep
		inc	(hl)
		ld	a, (hl)
		cp	KEY_REP_START
		jr	c, .hit
		ld	(hl), KEY_REP_START-KEY_REP_EVERY
		ld	a, e
		and	K_UP+K_DOWN
		or	c
		ld	c, a
		jr	.hit
.noRep:		ld	(KeyRep), a
.hit:		ld	a, (KeyHit)
		or	c
		ld	(KeyHit), a
		ret

; 現在の曲のドライバのフェードアウトの段数 -> A (0-10h。0Fh で最小音量)
GetFadePass:	ld	hl, (DrvDesc+D_FADEPASS)
		ld	a, (hl)
		ret

; 現在の曲のドライバが FM 0Eh に書いているリズムモード (bit5) -> A (ドライバがなければ 0)
GetRhyMode:	ld	a, (LoadedDrv)
		inc	a
		ret	z
		ld	hl, (DrvDesc+D_SHDFME)
		ld	a, (hl)
		and	20h
		ret

; 現在の曲のドライバの割込み処理 (DI で呼ぶ)
DrvInt:		jp	DrvJpInt

;-----------------------------------------------------------------------------
; ドライバがない状態にする (コマンドは xor a / ret、割込みは ret)
NoDriver:	ld	a, 0AFh		; xor a
		ld	(DrvJpCmd), a
		ld	a, 0C9h		; ret
		ld	(DrvJpCmd+1), a
		ld	(DrvJpInt), a
		ld	a, 0FFh
		ld	(LoadedDrv), a
		ret

; メーター: チャンネルのワーク IX (FM ch C) がリズムのチャンネルか (NZ = リズム)。HL, DE は壊さない
MtIsRhy:	ld	a, (DrvDesc+D_RHY)
		cp	0FFh
		jr	z, .fixed
		push	hl
		push	de
		push	ix
		pop	hl
		ld	e, a
		ld	d, 0
		add	hl, de
		ld	a, (hl)
		pop	de
		pop	hl
		and	20h
		ret
.fixed:		ld	a, c		; ch6-8 は常にリズム (リズムモードのとき)
		cp	6
		jr	nc, .r
		xor	a
		ret
.r:		ld	a, (MtShdE)
		and	20h
		ret

;-----------------------------------------------------------------------------
; RAM に置くルーチン (ドライバから呼ばれるフックと、ページ1のドライバを呼ぶ処理)
;  ページ1で動くドライバ (ファイナルファンタジー) を呼ぶ間はページ1が RAM になり、この ROM は見えないので、
;  ドライバから呼ばれる所とページ1を切り替える所はすべてページ3の RAM に置く。DI で使う
RamHooksImg:
		disp	RamHooks
; ドライバのループの終わり (endl) の ld a,(ix+ループ先) をこの call に差し替える (build_rom.py)
; ループ回数 (ix+D_CNT) が 0 なら無限ループの折り返しなので LoopCnt を数える。A = (ix+D_CNT+1) で戻る
HookLoop:	push	hl
		push	de
		push	ix
		pop	hl
		ld	a, (DrvDesc+D_CNT)
		ld	e, a
		ld	d, 0
		add	hl, de
		ld	a, (hl)
		inc	hl
		push	hl
		or	a
		jr	nz, .ret
		ld	hl, (DrvDesc+D_CHACT)
		ld	a, (hl)
		call	ChIndex
		jr	nc, .ret
		ld	hl, LoopCnt
		ld	e, a
		add	hl, de
		inc	(hl)
		jr	nz, .ret
		dec	(hl)
.ret:		pop	hl
		ld	a, (hl)
		pop	de
		pop	hl
		ret

; 処理中のチャンネル番号 A (80h-82h=PSG0-2, 0-8=FM0-8) -> A = 0-11 (CY=1)。効果音のチャンネルなどは CY=0
ChIndex:	bit	7, a
		jr	z, .fm
		and	7Fh
		jr	.chk
.fm:		add	a, 3
.chk:		cp	12
		ret

; 発音フック (レベルメーター用)。ドライバの音を出す処理の ld c,(ix+4) をこの call に差し替える (build_rom.py)
; 処理中のチャンネルの MtNoteOnF を 1 にする。A とフラグは壊さない
HookNote:	push	af
		push	hl
		ld	hl, (DrvDesc+D_CHACT)
		ld	a, (hl)
		call	ChIndex
		jr	nc, .ret	; 効果音のチャンネル等は無視
		add	a, MtNoteOnF & 0FFh
		ld	l, a
		ld	a, 0
		adc	a, MtNoteOnF >> 8
		ld	h, a
		ld	(hl), 1
.ret:		pop	hl
		pop	af
		ld	c, (ix+4)
		ret

; ページ1を RAM にする / ROM (このカートリッジ) に戻す。レジスタは壊さない
P1Ram:		push	af
		ld	a, (P1RamA8)
		out	(0A8h), a
		ld	a, (P1Exp)
		or	a
		jr	z, .n
		ld	a, (P1SubRam)
		ld	(0FFFFh), a
.n:		pop	af
		ret
P1Rom:		push	af
		ld	a, (P1Exp)
		or	a
		jr	z, .n
		ld	a, (P1SubRom)
		ld	(0FFFFh), a
.n:		ld	a, (P1RomA8)
		out	(0A8h), a
		pop	af
		ret
; ページ1のドライバのコマンド・割込み処理 (DrvJpCmd / DrvJpInt からここへ来る)
P1Cmd:		call	P1Ram
		call	P1CmdJp
		jr	P1Rom
P1Int:		call	P1Ram
		call	P1IntJp
		jr	P1Rom
; ページ1のドライバを SONG_RAM から元の番地へ写す
P1Copy:		call	P1Ram
		ld	hl, SONG_RAM
		ld	de, (DrvDesc+D_BASE)
		ld	bc, (DrvDesc+D_COPY)
		ldir
		jr	P1Rom
; ページ1に RAM があるか -> P1Ok (1 = ある)
P1Test:		call	P1Ram
		ld	hl, 7FFFh
		ld	a, (hl)
		cpl
		ld	(hl), a
		cp	(hl)
		ld	a, 0
		jr	nz, .no
		inc	a
.no:		call	P1Rom
		ld	(P1Ok), a
		ret
RamHooksEndD:
		ent
RAMHOOKS_SIZE	equ	RamHooksEndD-HookLoop

;-----------------------------------------------------------------------------
; 曲のドライバとゲームの表を用意する
;  E_DRV = ドライバと表の組の番号 (SetDir の 1 から。SetDir: ドライバの番号, 表のバンク, 表のアドレス (2))
;  ドライバが今のものと違えば写し直す。表はドライバの表の番地 (D_TBLRAM) へ毎回写す
LoadSet:	ld	a, (CurEntry+E_DRV)
		dec	a
		add	a, a
		add	a, a
		ld	l, a
		ld	h, 0
		ld	de, SetDir
		add	hl, de
		ld	a, (hl)		; ドライバの番号
		inc	hl
		push	hl
		ld	hl, LoadedDrv
		cp	(hl)
		call	nz, LoadDrv
		pop	hl
		ld	a, (hl)		; 表のバンク
		inc	hl
		ld	e, (hl)
		inc	hl
		ld	d, (hl)
		ex	de, hl
		ld	de, (DrvDesc+D_TBLRAM)
		ld	bc, TBL_LEN
		di
		call	RamCopy
		ei
		ret

; ドライバ A (DrvDir の番号) を元の番地へ写し、ワークを 0 にして初期化する
LoadDrv:	ld	(LoadedDrv), a
		ld	l, a
		ld	h, 0
		add	hl, hl
		add	hl, hl
		add	hl, hl		; x8
		ld	d, h
		ld	e, l
		add	hl, hl
		add	hl, hl		; x32
		add	hl, de		; x40 (DRV_DESC)
		ld	de, DrvDir
		add	hl, de
		ld	de, DrvDesc
		ld	bc, DRV_DESC
		ldir
		di
		ld	a, 0C3h		; jp
		ld	(DrvJpCmd), a
		ld	(DrvJpInt), a
		ld	hl, (DrvDesc+D_CMD)
		ld	(DrvJpCmd+1), hl
		ld	hl, (DrvDesc+D_INT)
		ld	(DrvJpInt+1), hl
		ld	a, (DrvDesc+D_PAGE1)
		or	a
		jr	nz, .p1
		ld	a, (DrvDesc+D_BANK)
		ld	hl, (DrvDesc+D_ADDR)
		ld	de, (DrvDesc+D_BASE)
		ld	bc, (DrvDesc+D_COPY)
		call	RamCopy
		jr	.clear
.p1:		; ページ1のドライバ: いったん SONG_RAM に読み、ページ1を RAM にして写す。呼ぶときも RAM にする
		ld	a, (P1Ok)
		or	a
		jr	nz, .p1ok
		ei			; ページ1に RAM がない機種では鳴らさない
		jp	NoDriver
.p1ok:		ld	a, 0C3h
		ld	(P1CmdJp), a
		ld	(P1IntJp), a
		ld	hl, (DrvDesc+D_CMD)
		ld	(P1CmdJp+1), hl
		ld	hl, (DrvDesc+D_INT)
		ld	(P1IntJp+1), hl
		ld	hl, P1Cmd
		ld	(DrvJpCmd+1), hl
		ld	hl, P1Int
		ld	(DrvJpInt+1), hl
		ld	a, (DrvDesc+D_BANK)
		ld	hl, (DrvDesc+D_ADDR)
		ld	de, SONG_RAM
		ld	bc, (DrvDesc+D_COPY)
		call	RamCopy
		call	P1Copy
.clear:		ld	hl, (DrvDesc+D_WORK)
		ld	bc, (DrvDesc+D_CLEAR)
		ld	(hl), 0
		ld	d, h
		ld	e, l
		inc	de
		dec	bc
		ldir
		ei
		ld	a, CMD_INICHIPS
		call	DrvCmd
		jp	SilenceChips

;-----------------------------------------------------------------------------
; マッパーの確認 (RAM で動かす): 6000h にバンク 1 を選び、4000h にバンク 1 の目印 "MC16" が見えるか (Z = 見える)。
;  ASCII16 なら 4000h-7FFFh がバンク 1 になる。ASCII8 では 4000h-5FFFh が 8KB の 1 番 (ROM の 2000h) になり、
;  ほかのマッパーでもふつうは目印は見えない。最後に 6000h に 0 を書いて先頭のバンクに戻す
MapChkImg:
		disp	MapChk
MapChkD:	ld	a, 1
		ld	(BANK_P1), a
		ld	hl, (4000h)
		ld	de, (4002h)
		xor	a
		ld	(BANK_P1), a
		ld	a, l
		cp	'M'
		ret	nz
		ld	a, h
		cp	'C'
		ret	nz
		ld	a, e
		cp	'1'
		ret	nz
		ld	a, d
		cp	'6'
		ret
; マッパーが違うときに止まる所: 割込みを止めて HALT (ROM を読みに行かないように RAM で止まる)
MapStop:	di
		halt
		jr	MapStop
MapChkEndD:
		ent
MAPCHK_SIZE	equ	MapChkEndD-MapChkD

; マッパーが ASCII16 でない: テキスト画面にメッセージを出して止まる (BIOS だけを使う)
MapError:	call	INITXT
		ld	hl, MsgMapper
.lp:		ld	a, (hl)
		or	a
		jp	z, MapStop
		call	CHPUT
		inc	hl
		jr	.lp
MsgMapper:	db	"MCPLAYER:", 13, 10
		db	"The ROM is not in ASCII16 mode.", 13, 10
		db	"(ESE-RAM: set 16K bank, reset)", 0
MapErrEnd:
		assert	MapErrEnd <= 6000h	; 6000h 以降はマッパーが違うと見えない

;-----------------------------------------------------------------------------
; RAM に置くバンク読み出しルーチン (ページ1のバンクを一時的に切り替える)
;  A=バンク, HL=バンク内アドレス(8000h-BFFFh), DE=転送先, BC=長さ。DI で呼ぶ
RamCopyImg:
		disp	RamCopy
RamCopyD:	ld	(BANK_P1), a
		ld	a, h
		sub	40h		; ページ1から見たアドレス
		ld	h, a
		ldir
		xor	a
		ld	(BANK_P1), a
		ret
RamCopyEndD:
		ent
RAMCOPY_SIZE	equ	RamCopyEndD-RamCopyD

; RAM に置く CG の展開ルーチン: ROM の圧縮した CG (CgBank:CgPtr から) を展開して、ポート C へ 256 バイト出す
;  まとまりは 256 バイトの区切りをまたがない (build_rom.py の cgrle.py が分けている) ので、続きは CgBank:CgPtr だけ
;  圧縮の形: 01h-7Fh = 続く n バイトをそのまま (OTIR。ROM のバンクの境目はまたがない)、80h+n = 続く 1 バイトを n+3 回
;  DI で呼ぶ
CgDecImg:
		disp	CgDec
CgDecD:		ld	a, (CgBank)
		ld	(BANK_P1), a
		ld	hl, (CgPtr)
		ld	e, 0		; 出した数 (256 で 0 に戻る)
.loop:		bit	7, h		; まとまりの頭
		call	nz, .nb
		ld	a, (hl)
		inc	hl
		bit	7, a
		jr	nz, .run
		ld	b, a		; そのまま
		add	a, e
		ld	e, a
		bit	7, h
		call	nz, .nb
		otir
		jr	.next
.run:		and	7Fh		; くり返し
		add	a, 3
		ld	b, a
		add	a, e
		ld	e, a
		bit	7, h
		call	nz, .nb
		ld	a, (hl)
		inc	hl
.r:		out	(c), a
		djnz	.r
.next:		ld	a, e
		or	a
		jr	nz, .loop
		ld	(CgPtr), hl
		xor	a
		ld	(BANK_P1), a
		ret
.nb:		ld	h, 40h		; バンクの終わり: 次のバンクへ
		push	af
		ld	a, (CgBank)
		inc	a
		ld	(CgBank), a
		ld	(BANK_P1), a
		pop	af
		ret
CgDecEndD:
		ent
CGDEC_SIZE	equ	CgDecEndD-CgDecD

; CG の展開を始める (CG HL: バンク, ...)。パレットは先頭の 32 バイト、圧縮したデータはその後ろ
CgDecStart:	ld	a, (hl)
		ld	(CgBank), a
		ld	hl, 4020h
		ld	(CgPtr), hl
		ret

; CG (バンク A) のパレット 32 バイトを TextBuf へ
CgPalette:	ld	hl, 8000h	; RamCopy はページ2 から見たアドレス (= ページ1 の 4000h)
		ld	de, TextBuf
		ld	bc, 32
		di
		call	RamCopy
		ei
		ret

; 再生モードに従って CurIdx を次の曲にする。戻り: CY = 次の曲はない (止める)
;  PlayMode 0 (ALL): 全曲を順に  1 (GAME): 再生中のゲームの曲を順に  2 (ONE): 同じ曲
;  RepeatOff 0: 最後まで行ったら先頭へ (ONE は同じ曲をもう一度)  1: 最後で止める (ONE は 1 回)
NextByMode:	ld	a, (PlayMode)
		cp	2
		jr	nz, .notOne
		ld	a, (RepeatOff)	; ONE: リピートなら同じ曲、しないなら止める
		rrca
		ret
.notOne:	ld	hl, (CurIdx)
		inc	hl
		ld	de, (PlaylistTable)
		or	a
		sbc	hl, de
		add	hl, de
		jr	nc, .last	; 全曲の最後を過ぎた
		ld	a, (PlayMode)
		or	a
		jr	z, .set		; ALL
		; GAME: 次の曲が同じゲームか
		push	hl
		ld	hl, (CurIdx)
		call	GameKey
		ld	(GkCur), de
		pop	hl
		call	GameKey
		call	GkSame
		jr	z, .set
.last:		ld	a, (RepeatOff)
		or	a
		scf
		ret	nz		; リピートしない: 止める
		ld	a, (PlayMode)
		or	a
		ld	hl, 0
		jr	z, .set		; ALL: 先頭へ
		; GAME: そのゲームの先頭へ
		ld	hl, (CurIdx)
		call	GameKey
		ld	(GkCur), de
.back:		ld	a, h
		or	l
		jr	z, .set
		dec	hl
		call	GameKey
		call	GkSame
		jr	z, .back
		inc	hl
.set:		ld	(CurIdx), hl
		or	a
		ret

; HL = 曲番号 -> HL = エントリのアドレス
GetEntry:	add	hl, hl
		add	hl, hl		; x4
		ld	d, h
		ld	e, l
		add	hl, hl		; x8
		add	hl, de		; x12 (ENTRY_SIZE)
		ld	de, PlaylistTable+PL_ENTRIES
		add	hl, de
		ret

;-----------------------------------------------------------------------------
; 演奏中チャンネルの最小ループ回数 -> A (演奏中のチャンネルがなければ 255)
CalcMinLoop:
		ld	hl, (DrvDesc+D_STRIDE)
		ld	(ChnStride), hl
		ld	hl, (DrvDesc+D_CHN)
		ld	c, 255
		ld	b, 12
		ld	de, LoopCnt
.lp:		ld	a, (hl)		; +0 = 残り時間 (0=停止中)
		or	a
		jr	z, .skip
		ld	a, (de)
		cp	c
		jr	nc, .skip
		ld	c, a
.skip:		push	bc
		ld	bc, (ChnStride)
		add	hl, bc
		pop	bc
		inc	de
		djnz	.lp
		ld	a, c
		ret

;-----------------------------------------------------------------------------
; 経過時間
TickTime:	di
		ld	a, (Ticks)
		ld	c, a
		xor	a
		ld	(Ticks), a
		ei
		ld	a, (FPS)
		ld	d, a
		ld	e, 0
		ld	a, (FrameCnt)
		add	a, c
.s:		cp	d
		jr	c, .st
		sub	d
		ld	hl, (Seconds)
		inc	hl
		ld	(Seconds), hl
		ld	e, 1
		jr	.s
.st:		ld	(FrameCnt), a
		ld	a, e
		or	a
		ret	z
		jp	DrawTime

;-----------------------------------------------------------------------------
; キー入力 (MGSEL 風)
;   ↑ / テンキー8   : 同じゲームの中で選択を上へ (SHIFT で 10 曲)。先頭で止まる
;   ↓ / テンキー2   : 同じゲームの中で選択を下へ (SHIFT で 10 曲)。最後で止まる
;   ← / テンキー4   : 前のゲームのリストにして 1 曲目を選ぶ (先頭のゲームでは何もしない)
;   → / テンキー6   : 次のゲームのリストにして 1 曲目を選ぶ (最後のゲームでは何もしない)
;   SPACE           : 選択曲が再生中の曲と違えば KEY_PLAY、同じなら KEY_STOP、停止中は KEY_PLAY
;   E               : 再生の範囲 ALL (全曲) -> GAME (再生中のゲーム) -> ONE (再生中の曲) -> ALL
;   R               : リピート REPEAT (する) <-> ONCE (しない)
;   V               : 再生中のゲームの CG とリストを切り替える (MSX2 以降、CG があるとき)
; ↑↓ は押し続けるとリピートする。戻り: A = KEY_NONE / KEY_PLAY / KEY_STOP / KEY_VIEW
KEY_NONE	equ	0
KEY_PLAY	equ	1
KEY_STOP	equ	2
KEY_VIEW	equ	3
K_UP		equ	1
K_DOWN		equ	2
K_LEFT		equ	4
K_RIGHT		equ	8
K_SPACE		equ	16
K_E		equ	32
K_R		equ	64
K_V		equ	128
KEY_REP_START	equ	20		; リピートが始まるまでのフレーム数
KEY_REP_EVERY	equ	4		; リピートの間隔

KeyInput:	call	KILBUF		; BIOS のキーバッファは使わない
		ld	a, (HelpPage)
		or	a
		jp	nz, HelpKeys
		di
		ld	a, (KeyHHit)
		ld	b, a
		xor	a
		ld	(KeyHHit), a
		ld	a, (KeyHit)
		ld	c, a
		xor	a
		ld	(KeyHit), a
		ei
		ld	a, b		; H: ヘルプ (リスト表示のときだけ。CG 表示中は無視)
		or	a
		jr	z, .keys
		ld	a, (ViewMode)
		or	a
		jp	z, HelpOpen
.keys:		ld	a, c
		and	K_UP+K_DOWN+K_LEFT+K_RIGHT
		jr	z, .noNav
		ld	a, 1		; CG 表示中は選択した曲を最下行に出す
		ld	(CgShowSel), a
		ld	a, c
		bit	0, a
		jp	nz, SelUpCg
		bit	1, a
		jp	nz, SelDownCg
		bit	2, a
		jp	nz, GamePrevCg
		jp	GameNextCg
.noNav:		ld	a, c
		bit	4, a
		jr	nz, .space
		bit	5, a
		jr	nz, .mode
		bit	6, a
		jr	nz, .repeat
		bit	7, a
		ld	a, KEY_VIEW
		ret	nz
		xor	a		; KEY_NONE
		ret
.mode:		ld	a, (PlayMode)	; E: ALL -> GAME -> ONE -> ALL
		inc	a
		cp	3
		jr	c, .m
		xor	a
.m:		ld	(PlayMode), a
		call	DrawTime
		xor	a
		ret
.repeat:	ld	a, (RepeatOff)	; R: REPEAT <-> ONCE
		xor	1
		ld	(RepeatOff), a
		call	DrawTime
		xor	a
		ret
.space:		ld	a, (Playing)
		or	a
		ld	a, KEY_PLAY
		ret	z		; 停止中: 選択曲を鳴らす
		ld	a, (IsStartup)
		or	a
		ld	a, KEY_PLAY
		ret	nz		; 起動時の曲を鳴らしている: 選択曲を鳴らす
		ld	hl, (SelIdx)
		ld	de, (CurIdx)
		or	a
		sbc	hl, de
		ld	a, KEY_PLAY
		ret	nz		; 別の曲を選んでいる: その曲を鳴らす
		ld	a, KEY_STOP	; 再生中の曲: フェードアウトして止める
		ret

; 選択を動かしたあと、CG 表示中なら最下行を描き直す
SelUpCg:	call	SelUp
		jr	CgNavDone
SelDownCg:	call	SelDown
		jr	CgNavDone
GamePrevCg:	call	GamePrev
		jr	GameNavDone
GameNextCg:	call	GameNext
GameNavDone:	; 停止中にゲームを替えたら、選んでいるゲームの CG にする
		ld	a, (Playing)
		or	a
		jr	nz, CgNavDone
		call	SelGameRec
		jr	z, CgNavDone
		ld	a, (HasExtVdp)
		or	a
		jr	z, .int
		push	hl
		call	V9ShowCG	; V9990 (CG がないゲームなら消す)
		pop	hl
.int:		ld	a, (ViewMode)	; 内蔵 VDP の CG 表示中 (CG がないゲームではそのまま)
		cp	VIEW_CG
		jr	nz, CgNavDone
		ld	a, (hl)
		or	a
		jr	z, CgNavDone
		ld	b, a
		ld	a, (CgCur)
		cp	b
		call	nz, ShowCG
CgNavDone:	ld	a, (ViewMode)
		cp	VIEW_CG
		jr	nz, .ret
		; まだ何も鳴らしていなければ、選んでいるゲームの CG に替える (CG がないゲームではそのまま)
		ld	a, (CurEntry+E_SBANK)
		or	a
		jr	nz, .line
		call	CgGame
		jr	z, .line
		ld	a, (hl)
		or	a
		jr	z, .line
		ld	b, a
		ld	a, (CgCur)
		cp	b
		call	nz, ShowCG
.line:		call	DrawCgLine
.ret:		xor	a
		ret

; 再生中の曲の CG -> HL (バンク, 画面モード, 文字色, 背景色。Z = なし)
;  曲ごとの CG (SongCgTbl。プレイリストの @song_cg) があればそれ、なければゲームの CG (ゲームの情報の先頭)
PlayCgRec:	ld	hl, (CurEntry+E_GAME)
		ld	a, (IsStartup)
		or	a
		jr	nz, .chk
		push	hl
		ld	de, (CurIdx)
		ld	hl, SongCgTbl
.l:		ld	c, (hl)		; 曲番号 (0FFFFh = 終わり)
		inc	hl
		ld	b, (hl)
		inc	hl
		ld	a, b
		and	c
		inc	a
		jr	z, .none
		ld	a, c
		cp	e
		jr	nz, .nx
		ld	a, b
		cp	d
		jr	z, .found
.nx:		inc	hl
		inc	hl
		inc	hl
		inc	hl
		jr	.l
.found:		pop	de		; ゲームの情報は使わない
		jr	.chk
.none:		pop	hl
.chk:		ld	a, h
		or	l
		ret

; 選んでいる曲のゲームの情報 -> HL (Z = なし)
SelGameRec:	ld	hl, (SelIdx)
		call	GetEntry
		ld	de, E_GAME
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	h, (hl)
		ld	l, a
		or	h
		ret

; 選択を上へ (SHIFT で 10)。ゲームの先頭で止まる
SelUp:		ld	hl, (SelIdx)
		ld	de, (ViewStart)
		or	a
		sbc	hl, de		; HL = ゲーム内の位置
		ld	a, h
		or	l
		jr	z, .none
		ld	bc, 1
		ld	a, (KeyShift)
		or	a
		jr	z, .s
		ld	c, 10
.s:		or	a
		sbc	hl, bc
		jr	nc, .ok
		ld	hl, 0
.ok:		add	hl, de
		call	SelChanged
.none:		xor	a
		ret

; 選択を下へ (SHIFT で 10)。ゲームの最後で止まる
SelDown:	ld	hl, (ViewEnd)
		ld	de, (SelIdx)
		or	a
		sbc	hl, de		; HL = 最後までの残り
		ld	a, h
		or	l
		jr	z, .none
		ld	bc, 1
		ld	a, (KeyShift)
		or	a
		jr	z, .s
		ld	c, 10
.s:		push	hl
		or	a
		sbc	hl, bc
		pop	hl
		jr	c, .last	; 残りより多く進むなら最後へ
		ld	h, b
		ld	l, c
.last:		add	hl, de
		call	SelChanged
.none:		xor	a
		ret

; 前のゲーム (先頭のゲームでは何もしない)
GamePrev:	ld	hl, (ViewStart)
		ld	a, h
		or	l
		jr	z, .none
		dec	hl
		ld	(SelIdx), hl
		call	SetViewFromSel
		ld	hl, (ViewStart)
		ld	(SelIdx), hl
		call	DrawList
		call	DrawGameSel
.none:		xor	a
		ret

; 次のゲーム (最後のゲームでは何もしない)
GameNext:	ld	hl, (ViewEnd)
		inc	hl
		ld	de, (PlaylistTable)
		or	a
		sbc	hl, de
		jr	nc, .none
		add	hl, de
		ld	(SelIdx), hl
		call	SetViewFromSel
		call	DrawList
		call	DrawGameSel
.none:		xor	a
		ret

;-----------------------------------------------------------------------------
; ゲームの区切り (プレイリストで隣り合う曲のゲーム名のアドレスが同じなら同じゲーム)

; HL = 曲番号 -> DE = ゲーム名のアドレス (HL は保存)
GameKey:	push	hl
		call	GetEntry
		ld	de, E_GAME
		add	hl, de
		ld	e, (hl)
		inc	hl
		ld	d, (hl)
		pop	hl
		ret

; SelIdx のゲームの範囲を ViewStart - ViewEnd に求める
SetViewFromSel:	ld	hl, (SelIdx)
		call	GameKey
		ld	(GkCur), de
.back:		ld	a, h		; 前の曲が同じゲームなら戻る
		or	l
		jr	z, .start
		dec	hl
		call	GameKey
		call	GkSame
		jr	z, .back
		inc	hl
.start:		ld	(ViewStart), hl
		ld	hl, (SelIdx)
.fwd:		inc	hl		; 次の曲が同じゲームなら進む
		push	hl
		ld	de, (PlaylistTable)
		or	a
		sbc	hl, de
		pop	hl
		jr	nc, .end
		call	GameKey
		call	GkSame
		jr	z, .fwd
.end:		dec	hl
		ld	(ViewEnd), hl
		ret

; DE とGkCur が同じなら Z
GkSame:		ld	a, (GkCur)
		cp	e
		ret	nz
		ld	a, (GkCur+1)
		cp	d
		ret

;=============================================================================
; 画面表示 (SCREEN 2 に k8x12L フォントで描く)
;
;  SCREEN 2 は名前表が 0-255 の連番なので、パターン表がそのまま 256x192 の
;  ビットマップになる (8x8 マス単位。マス内は1ドット行1バイト)。
;  文字の行は高さ 12 ドットで 16 行 (y = 行*12)。行の境目はマスの境目と揃わないので、
;  行を描くときは、その行が受け持つバイトだけを VDP に直接書く (隣の行と重ならない)。
;   y が 8 の倍数の行:   上 8 ドット = マス行 R の全体、下 4 ドット = マス行 R+1 の上半分
;   y が 8 の倍数+4 の行: 上 4 ドット = マス行 R の下半分、下 8 ドット = マス行 R+1 の全体
;  行は左右に分けて描ける (マスの範囲 RlCell0 - RlCellN)。上の 4 行は左が情報、右がメーター。
;  半角 (ASCII) は幅 4 ドット、全角は 8 ドット。x 位置は 4 ドット単位。
;
;  文字列の形式 (build_rom.py が作る):
;   20h-7Eh      半角文字 (バンク0 の HalfFont)
;   80h以上 x 2  全角文字。番号 = (1バイト目 and 7Fh) * 128 + (2バイト目 and 7Fh)
;                全角フォントは GlyphBank から 1字 16 バイト、1バンク 1024 字
;   00h          終わり

; 色 (上位4ビット=文字 下位4ビット=背景)
COL_HEAD	equ	0B1h		; 薄い黄 / 黒
COL_INFO	equ	0F1h		; 白 / 黒
COL_GAME	equ	031h		; 薄い緑 / 黒
COL_TITLE	equ	0F5h		; 白 / 薄い青 (帯)
COL_LIST	equ	0F1h		; 白 / 黒
COL_CUR		equ	01Bh		; 黒 / 薄い黄 (選択中の曲の帯)
COL_PLAYING	equ	031h		; 薄い緑 / 黒 (再生中の曲)
COL_LABEL	equ	0E1h		; 灰 / 黒
COL_HELP	equ	01Eh		; 黒 / 灰 (帯)

; 行の割り当て (1行 12 ドット、16 行)
LN_HEAD		equ	0		; 左: タイトル
LN_SOUND	equ	1		; 左: 音源
LN_TRACK	equ	2		; 左: TRACK / LOOP
LN_TIME		equ	3		; 左: TIME   右: チャンネル番号
LN_PLAY		equ	4		; 再生中のゲーム名 / 曲名
LN_GAMESEL	equ	5		; 前のゲーム <- 【選んでいるゲーム】 -> 次のゲーム
LN_LIST		equ	6		; 曲リストの先頭行 (選んでいるゲームの曲)
LIST_ROWS	equ	10
COL_SEL		equ	0B1h		; 薄い黄 / 黒 (選んでいるゲーム)
COL_SIDE	equ	0E1h		; 灰 / 黒 (前後のゲーム)
VIEW_LIST	equ	0		; ViewMode: リスト
VIEW_CG		equ	1		;           再生中のゲームの CG
VIEW_TITLE	equ	2		;           起動時の CG
RF_BMP		equ	8		; RenderLine: CG の最下行に描く
TOP_CELLS	equ	18		; 上 4 行の左側 (情報) のマス数。右側はメーター

; RenderLine の E (フラグ)
RF_NOCOL	equ	2		; 色表を書き換えない
RF_SHIFT2	equ	4		; 描いた字を右へ 2 ドットずらす (チャンネル番号をバーの真下に)

;-----------------------------------------------------------------------------
; ヘルプ (H キー): 曲リストの上にウィンドウを重ねる。何かキーで 2 ページ目、もう一度で閉じる
;  表示中も曲は鳴り続け、上の情報 (TRACK・TIME・メーター) も動く。表示中に押したキーは操作にしない
;  文字列 (HelpText) は build_rom.py がフォントに合わせて書く:
;   0 = 上の枠、1 = 下の枠、2 = 左右の枠、3-7 = 1 ページ目、8-12 = 2 ページ目
HELP_ROW	equ	7		; ウィンドウの上の枠の行 (7-13 行)
HELP_LINES	equ	5		; 1 ページの行数
COL_WIN		equ	0F4h		; 白 / 濃い青

HelpOpen:	ld	a, 1
		ld	(HelpPage), a
		call	AnyKey		; 今押されているキー (H) は離すまで見ない
		ld	(HelpAny), a
		call	DrawHelp
		xor	a		; KEY_NONE
		ret

HelpKeys:	di			; 表示中に押したキーは捨てる
		xor	a
		ld	(KeyHit), a
		ld	(KeyHHit), a
		ei
		call	AnyKey
		ld	hl, HelpAny
		ld	b, (hl)
		ld	(hl), a
		or	a
		jr	z, .none
		ld	a, b
		or	a
		jr	nz, .none	; 押し続けている
		ld	a, (HelpPage)
		cp	1
		jr	nz, .close
		inc	a		; 2 ページ目へ
		ld	(HelpPage), a
		call	DrawHelp
		jr	.none
.close:		xor	a
		ld	(HelpPage), a
		di			; 閉じるのに押したキーは、離すまで操作にしない
		ld	a, 0FFh
		ld	(KeyBlock), a
		ld	a, 20h		; H も: 割込みのキー読みより先にここで押したのを見つけたとき、
		ld	(KeyHPrev), a	; 次の割込みで「新しく押された」とされてヘルプがまた開かないように
		xor	a
		ld	(KeyHit), a
		ld	(KeyHHit), a
		ei
		call	DrawList
.none:		xor	a		; KEY_NONE
		ret

; ウィンドウを描く (HelpPage のページ)
DrawHelp:	xor	a		; 上の枠
		call	HelpStr
		ld	a, HELP_ROW
		ld	c, COL_WIN
		ld	e, 0
		call	RenderLine
		ld	a, 1		; 下の枠
		call	HelpStr
		ld	a, HELP_ROW+HELP_LINES+1
		ld	c, COL_WIN
		ld	e, 0
		call	RenderLine
		ld	a, (HelpPage)	; 最初の行の文字列の番号 = 3 + (ページ-1)*5
		dec	a
		ld	b, a
		add	a, a
		add	a, a
		add	a, b
		add	a, 3
		ld	(HelpIdx), a
		ld	a, HELP_ROW+1
.row:		ld	(HelpRow), a
		ld	a, 2		; 左の枠 (マス 0)
		call	HelpStr
		ld	a, (HelpRow)
		ld	c, COL_WIN
		ld	e, 0
		ld	b, 0
		ld	d, 1
		call	RenderLineAt
		ld	a, (HelpIdx)	; 文 (マス 1-30)
		call	HelpStr
		ld	a, (HelpRow)
		ld	c, COL_WIN
		ld	e, 0
		ld	b, 1
		ld	d, 31
		call	RenderLineAt
		ld	a, 2		; 右の枠 (マス 31)
		call	HelpStr
		ld	a, (HelpRow)
		ld	c, COL_WIN
		ld	e, 0
		ld	b, 31
		ld	d, 32
		call	RenderLineAt
		ld	hl, HelpIdx
		inc	(hl)
		ld	a, (HelpRow)
		inc	a
		cp	HELP_ROW+HELP_LINES+1
		jr	c, .row
		ret

; HelpText の A 番目の文字列 -> HL
HelpStr:	ld	hl, HelpText
		or	a
		ret	z
		ld	b, a
.s:		ld	a, (hl)
		inc	hl
		or	a
		jr	nz, .s
		djnz	.s
		ret

;-----------------------------------------------------------------------------
; 画面初期化 (SCREEN 2、背景を黒で塗る)
InitScreen:	ld	a, 15
		ld	(FORCLR), a
		ld	a, 1
		ld	(BAKCLR), a
		ld	(BDRCLR), a
		call	CHGCLR
		call	INIGRP		; 名前表は 0-255 x3 の連番になる
		ld	hl, (GRPCOL)
		ld	bc, 1800h
		ld	a, COL_INFO
		call	FILVRM
		ld	hl, (GRPCGP)
		ld	bc, 1800h
		xor	a
		jp	FILVRM

;-----------------------------------------------------------------------------
; VDP の書き込み位置を DE にする。戻り: C = データポート。DI で呼ぶ
VdpSetW:	ld	a, (0007h)	; VDP の書き込みポート (普通は 98h)
		ld	c, a
		inc	c
		out	(c), e
		ld	a, d
		and	3Fh
		or	40h
		out	(c), a
		dec	c
		ret

;-----------------------------------------------------------------------------
; 文字列 HL を 行 A に描く。C = 色, E = フラグ (RF_*)
; RenderLine は行全体、RenderLineAt はマス B から D の手前まで
RenderLine:	ld	b, 0
		ld	d, 32
RenderLineAt:	ld	(RlLine), a
		ld	a, c
		ld	(RlColor), a
		ld	a, e
		ld	(RlFlags), a
		ld	a, b
		ld	(RlCell0), a
		add	a, a
		add	a, a
		ld	(RlX), a	; 2 ドット単位
		ld	a, d
		ld	(RlCellN), a
		add	a, a
		add	a, a
		ld	(RlXMax), a
		push	hl
		ld	hl, LineBuf	; 行バッファを空にする
		ld	de, LineBuf+1
		ld	bc, 511
		ld	(hl), 0
		ldir
		pop	hl
.ch:		ld	a, (hl)
		or	a
		jp	z, .done
		inc	hl
		bit	7, a
		jr	nz, .full
		cp	2		; 02h: 2 ドット進む
		jr	nz, .notAdv2
		ld	a, (RlX)
		inc	a
		ld	(RlX), a
		jp	.ch
.notAdv2:	cp	1		; 01h: 次のマスの先頭へ進む
		jr	nz, .half
		ld	a, (RlX)
		add	a, 3
		and	0FCh
		ld	(RlX), a
		jr	.ch
.half:		; 半角: HalfFont + (A-20h)*12
		sub	20h
		jr	c, .sp
		cp	5Fh
		jr	c, .hok
.sp:		xor	a		; 制御文字・7Fh は空白
.hok:		push	hl
		ld	l, a
		ld	h, 0
		add	hl, hl
		add	hl, hl		; x4
		ld	d, h
		ld	e, l
		add	hl, hl		; x8
		add	hl, de		; x12
		ld	de, HalfFont
		add	hl, de
		ex	de, hl		; DE = 字形
		ld	b, 3		; 6 ドット
		jr	.put
.full:		; 全角: 番号 = (A and 7Fh)*128 + ((HL) and 7Fh)
		and	7Fh
		ld	d, a
		ld	a, (hl)
		inc	hl
		push	hl
		and	7Fh
		ld	e, a		; DE = D*128 + A
		srl	d		; (D の最下位を E の最上位へ)
		jr	nc, .n0
		set	7, e
.n0:		; バンク = GlyphBank + 番号/1024、アドレス = 8000h + (番号 and 3FFh)*16
		ld	a, d
		srl	a
		srl	a
		ld	hl, PlaylistTable+PL_GLYPH_BANK
		add	a, (hl)
		push	af
		ld	a, d
		and	3
		ld	h, a
		ld	l, e
		add	hl, hl
		add	hl, hl
		add	hl, hl
		add	hl, hl		; x16
		ld	a, h
		add	a, 80h
		ld	h, a
		pop	af
		ld	de, GlyphBuf
		ld	bc, 12
		di
		call	RamCopy
		ei
		ld	de, GlyphBuf
		ld	b, 4		; 8 ドット
.put:		; DE = 字形 12 バイト, B = 幅 (2 ドット単位)
		ld	a, (RlXMax)
		ld	c, a
		ld	a, (RlX)
		add	a, b
		cp	c
		jr	z, .fits
		jr	nc, .over	; 範囲からはみ出すので終わり
.fits:		call	Blit
		ld	a, (RlX)
		add	a, b
		ld	(RlX), a
		pop	hl
		jp	.ch
.over:		pop	hl
.done:		ld	a, (RlFlags)
		and	RF_SHIFT2
		call	nz, ShiftRight2
		ld	a, (RlFlags)
		and	RF_BMP
		jp	nz, BmpWriteLine
		jp	WriteLine

; 行バッファのマス RlCell0 - RlCellN を右へ 2 ドットずらす (はみ出した分は捨てる)
ShiftRight2:	ld	c, 0		; ドット行
.row:		ld	a, (RlCell0)
		ld	b, a
		ld	e, 0		; 左のマスからはみ出した 2 ドット (bit7-6)
.cell:		ld	l, b		; HL = LineBuf + マス*16 + ドット行
		ld	h, 0
		add	hl, hl
		add	hl, hl
		add	hl, hl
		add	hl, hl
		ld	a, l
		add	a, c
		ld	l, a
		push	de
		ld	de, LineBuf
		add	hl, de
		pop	de
		ld	a, (hl)
		ld	d, a
		srl	a
		srl	a
		or	e
		ld	(hl), a
		ld	a, d
		and	3
		rrca
		rrca
		ld	e, a
		inc	b
		ld	a, (RlCellN)
		cp	b
		jr	nz, .cell
		inc	c
		ld	a, c
		cp	12
		jr	c, .row
		ret

; 字形 DE (12 バイト。左詰め) を x = RlX*2 ドットに重ねる (BC は保存)
; 行バッファはマスごとに 16 バイト (ドット行 0-11 + 余り)。マスをまたぐ分は隣のマスへ
Blit:		push	bc
		push	hl
		ld	a, (RlX)
		ld	c, a
		and	3
		add	a, a
		ld	(BlitShift), a	; マスの中の位置 (0, 2, 4, 6 ドット)
		ld	a, c
		srl	a
		srl	a		; マスの番号
		ld	l, a
		ld	h, 0
		add	hl, hl
		add	hl, hl
		add	hl, hl
		add	hl, hl
		ld	bc, LineBuf
		add	hl, bc		; HL = そのマスのドット行 0
		ld	c, 12
.row:		ld	a, (de)
		inc	de
		or	a
		jr	z, .next
		push	de
		ld	d, a		; DE = 字形の 1 行を右へずらしたもの (D = このマス、E = 次のマス)
		ld	e, 0
		ld	a, (BlitShift)
		or	a
		jr	z, .put
		ld	b, a
.sh:		srl	d
		rr	e
		djnz	.sh
.put:		ld	a, (hl)
		or	d
		ld	(hl), a
		ld	a, e
		or	a
		jr	z, .nl
		push	hl
		ld	de, 16
		add	hl, de
		or	(hl)
		ld	(hl), a
		pop	hl
.nl:		pop	de
.next:		inc	hl
		dec	c
		jr	nz, .row
		pop	hl
		pop	bc
		ret

;-----------------------------------------------------------------------------
; 行バッファを VRAM に書く (行 RlLine、マス RlCell0 - RlCellN)
WriteLine:	ld	a, (ViewMode)	; CG 表示中は書かない
		or	a
		ret	nz
		ld	a, (RlLine)	; y = 行*12
		ld	b, a
		add	a, a
		add	a, b
		add	a, a
		add	a, a
		ld	b, a
		and	7
		ld	(WlOff), a
		ld	a, b
		rrca
		rrca
		rrca
		and	1Fh
		ld	(WlRow), a
		xor	a		; パターン表には字形
		ld	(WlConst), a
		ld	hl, (GRPCGP)
		call	WlTable
		ld	a, (RlFlags)
		and	RF_NOCOL
		ret	nz
		ld	a, 1		; 色表には同じ色を並べる
		ld	(WlConst), a
		ld	hl, (GRPCOL)
		; そのまま WlTable へ

; 表 HL (パターン表 or 色表) に行を書く
WlTable:	ld	(WlBase), hl
		ld	a, (WlOff)
		or	a
		jr	nz, .off4
		ld	a, (WlRow)	; ドット行 0-7 -> マス行 R の全体
		ld	b, 0
		call	WlFull
		ld	a, (WlRow)	; ドット行 8-11 -> マス行 R+1 の上半分
		inc	a
		ld	b, 0
		ld	e, 8
		jp	WlPart
.off4:		ld	a, (WlRow)	; ドット行 0-3 -> マス行 R の下半分
		ld	b, 4
		ld	e, 0
		call	WlPart
		ld	a, (WlRow)	; ドット行 4-11 -> マス行 R+1 の全体
		inc	a
		ld	b, 4
		; そのまま WlFull へ

; マス行 A の全体 (マスごとに 8 バイト) を続けて書く。B = 行バッファ内の開始ドット行
WlFull:		ld	d, a
		ld	a, b
		ld	(WlSrc), a
		ld	a, (RlCell0)
		add	a, a
		add	a, a
		add	a, a
		ld	e, a		; DE = マス行*256 + 先頭マス*8
		ld	hl, (WlBase)
		add	hl, de
		ex	de, hl
		di
		call	VdpSetW		; C = ポート
		ld	a, (RlCell0)
		ld	b, a
.c:		push	bc
		call	WlSrcPtr
		ld	b, 8
		call	WlOut
		pop	bc
		inc	b
		ld	a, (RlCellN)
		cp	b
		jr	nz, .c
		ei
		ret

; マス行 A の各マスの 4 バイト (バイト位置 B から) を書く。E = 行バッファ内の開始ドット行
WlPart:		ld	(WlCRow), a
		ld	a, b
		ld	(WlBOff), a
		ld	a, e
		ld	(WlSrc), a
		ld	a, (RlCell0)
		ld	b, a
.c:		push	bc
		ld	a, b		; VRAM = 表 + マス行*256 + マス*8 + バイト位置
		add	a, a
		add	a, a
		add	a, a
		ld	hl, WlBOff
		add	a, (hl)
		ld	e, a
		ld	a, (WlCRow)
		ld	d, a
		ld	hl, (WlBase)
		add	hl, de
		ex	de, hl
		call	WlSrcPtr
		di
		call	VdpSetW
		ld	b, 4
		call	WlOut
		ei
		pop	bc
		inc	b
		ld	a, (RlCellN)
		cp	b
		jr	nz, .c
		ret

; B = マス -> HL = LineBuf + マス*16 + WlSrc (C, DE は壊さない)
WlSrcPtr:	ld	l, b
		ld	h, 0
		add	hl, hl
		add	hl, hl
		add	hl, hl
		add	hl, hl
		ld	a, (WlSrc)
		add	a, l
		ld	l, a
		jr	nc, .n
		inc	h
.n:		push	de
		ld	de, LineBuf
		add	hl, de
		pop	de
		ret

; B バイトを ポート C へ。WlConst = 0: HL から / 1: 色 RlColor を並べる
; (TMS9918 は 1 バイトごとに 29 クロック以上空ける必要がある)
WlOut:		ld	a, (WlConst)
		or	a
		jr	nz, .k
.l:		ld	a, (hl)
		out	(c), a
		inc	hl
		djnz	.l
		ret
.k:		ld	a, (RlColor)
.kl:		out	(c), a
		nop
		nop
		djnz	.kl
		ret

;-----------------------------------------------------------------------------
; 文字列の組み立て (TextBuf に追記していく)
TxStart:	ld	hl, TextBuf
		ld	(TxPtr), hl
		ld	(hl), 0
		ret

; 0終端の文字列 HL を追記 (全角の2バイトもそのまま写す)
TxStr:		ld	de, (TxPtr)
.lp:		ld	a, (hl)
		ld	(de), a
		or	a
		jr	z, .end
		inc	hl
		inc	de
		jr	.lp
.end:		ld	(TxPtr), de
		ret

; 1文字 A を追記
TxChar:		ld	hl, (TxPtr)
		ld	(hl), a
		inc	hl
		ld	(hl), 0
		ld	(TxPtr), hl
		ret

; 空白を B 個追記
TxSpaces:	ld	a, ' '
		push	bc
		call	TxChar
		pop	bc
		djnz	TxSpaces
		ret

; A (0-99) を2桁で追記
TxDec2:		ld	b, '0'-1
.t:		inc	b
		sub	10
		jr	nc, .t
		add	a, 10+'0'
		push	af
		ld	a, b
		call	TxChar
		pop	af
		jp	TxChar

; HL (0-999) を3桁で追記
TxDec3:		ld	de, 100
		call	.dig
		ld	de, 10
		call	.dig
		ld	a, l
		add	a, '0'
		jp	TxChar
.dig:		ld	a, '0'-1
.d1:		inc	a
		or	a
		sbc	hl, de
		jr	nc, .d1
		add	hl, de
		push	hl
		call	TxChar
		pop	hl
		ret

; TextBuf を 行 A に描く (色 C, フラグ E)
TxRender:	ld	hl, TextBuf
		jp	RenderLine

; TextBuf を 行 A の左側 (上 4 行の情報欄) に描く (色 C)
TxRenderLeft:	ld	hl, TextBuf
		ld	e, 0
		ld	b, 0
		ld	d, TOP_CELLS
		jp	RenderLineAt

;-----------------------------------------------------------------------------
; 1行だけのメッセージ HL を出す (RAM がない等)
ShowMessage:	ld	a, LN_PLAY
		ld	c, COL_HEAD
		ld	e, 0
		jp	RenderLine

;-----------------------------------------------------------------------------
DrawStatic:	ld	hl, MsgTitle
		ld	a, LN_HEAD
		ld	c, COL_HEAD
		ld	e, 0
		ld	b, 0
		ld	d, TOP_CELLS
		call	RenderLineAt
		call	TxStart
		ld	hl, MsgSound
		call	TxStr
		ld	a, (FMType)
		ld	hl, MsgFMNone
		or	a
		jr	z, .p
		ld	hl, MsgFMInt
		dec	a
		jr	z, .p
		ld	hl, MsgFMPac
.p:		call	TxStr
		ld	a, LN_SOUND
		ld	c, COL_INFO
		jp	TxRenderLeft

; TRACK / LOOP の行
DrawLoop:	call	TxStart
		ld	hl, MsgTrack
		call	TxStr
		ld	a, (IsStartup)
		ld	hl, CurEntry+E_SBANK
		or	a
		jr	nz, .none
		or	(hl)
		jr	nz, .num
.none:		ld	hl, MsgNoTrack	; 起動時の曲 / まだ何も鳴らしていない
		call	TxStr
		jr	.total
.num:		ld	hl, (CurIdx)
		inc	hl
		call	TxDec3
.total:		ld	a, '/'
		call	TxChar
		ld	hl, (PlaylistTable)
		call	TxDec3
		ld	b, 1
		call	TxSpaces
		ld	hl, MsgLoop
		call	TxStr
		; 何周目か (1 周目 = 01)。停止中は 00、回数を超えた (フェード中) ときは設定の回数
		ld	a, (Playing)
		or	a
		jr	z, .n
		ld	a, (LastMinLoop)
		cp	255
		jr	z, .end
		cp	99
		jr	nc, .max
		inc	a
		ld	b, a
		ld	a, (CurEntry+E_LOOPS)
		or	a
		jr	z, .nocap
		cp	b
		jr	c, .n
.nocap:		ld	a, b
		jr	.n
.end:		ld	a, (CurEntry+E_LOOPS)	; 全チャンネルが終わった: 設定の回数 (ループしない曲は 1)
		or	a
		jr	nz, .n
.max:		ld	a, 99
.n:		call	TxDec2
		ld	a, '/'
		call	TxChar
		ld	a, (CurEntry+E_LOOPS)
		or	a
		jr	z, .inf
		call	TxDec2
		jr	.out
.inf:		ld	hl, MsgInf
		call	TxStr
.out:		ld	a, LN_TRACK
		ld	c, COL_INFO
		jp	TxRenderLeft

; TIME の行
DrawTime:	call	TxStart
		ld	hl, MsgTime
		call	TxStr
		ld	hl, (Seconds)
		ld	b, 0
.min:		ld	de, 60		; HL / 60
		or	a
		sbc	hl, de
		jr	c, .minEnd
		inc	b
		jr	.min
.minEnd:	add	hl, de
		push	hl
		ld	a, b
		cp	100
		jr	c, .m
		ld	a, 99
.m:		call	TxDec2
		ld	a, ':'
		call	TxChar
		pop	hl
		ld	a, l
		call	TxDec2
		; 再生モード
		ld	b, 2
		call	TxSpaces
		ld	a, (PlayMode)
		add	a, a
		add	a, a
		add	a, a		; x8
		ld	e, a
		ld	d, 0
		ld	hl, MsgModes
		add	hl, de
		call	TxStr
		ld	a, ' '
		call	TxChar
		ld	hl, MsgRpt
		ld	a, (RepeatOff)
		or	a
		jr	z, .r
		ld	hl, MsgOnce
.r:		call	TxStr
		ld	a, LN_TIME
		ld	c, COL_INFO
		jp	TxRenderLeft

; 再生中のゲーム名 / 曲名 (停止中は STOP)
DrawPlaying:	call	TxStart
		ld	a, (Playing)
		or	a
		jr	nz, .play
		ld	hl, MsgStop
		call	TxStr
		jr	.draw
.play:		ld	hl, CurEntry
		call	TxGameTitle
.draw:		ld	a, LN_PLAY
		ld	c, COL_TITLE
		ld	e, 0
		jp	TxRender

; 選んでいるゲームの曲リスト。選択曲が見えるようにずらす
; リストを全部描く (選択曲が見えるように先頭を決めてから)
DrawList:	call	FixTop
DrawRows:	ld	hl, (ListTop)
		ld	a, LN_LIST
		ld	b, LIST_ROWS
.r:		push	bc
		push	af
		push	hl
		call	DrawRow
		pop	hl
		inc	hl
		pop	af
		inc	a
		pop	bc
		djnz	.r
		ret

; 選択を HL に変えて描き直す。リストが動かなければ前後の選択の 2 行だけ
SelChanged:	ld	de, (SelIdx)
		ld	(OldSel), de
		ld	(SelIdx), hl
		call	FixTop
		jr	nz, DrawRows
		ld	hl, (OldSel)
		call	DrawRowIdx
		ld	hl, (SelIdx)
		; そのまま DrawRowIdx へ

; 曲 HL の行がリストに見えていれば描き直す
DrawRowIdx:	ld	de, (ListTop)
		or	a
		sbc	hl, de		; HL = リスト内の位置
		ret	c
		ld	a, h
		or	a
		ret	nz
		ld	a, l
		cp	LIST_ROWS
		ret	nc
		add	hl, de
		add	a, LN_LIST
		; そのまま DrawRow へ

; 曲 HL を 行 A に描く (ゲームの最後より後ろは空行)
DrawRow:	ld	(ListRow), a
		push	hl
		call	TxStart
		pop	hl
		push	hl
		ld	a, COL_LIST
		ld	(ListColor), a
		ld	de, (ViewEnd)
		ex	de, hl
		or	a
		sbc	hl, de
		ex	de, hl
		jr	c, .draw
		; 再生中の曲は '>' と緑、選択中の曲は黄色の帯
		ld	de, (CurIdx)
		or	a
		sbc	hl, de
		ld	a, ' '
		jr	nz, .notPlay
		ld	a, (IsStartup)
		or	a
		ld	a, ' '
		jr	nz, .notPlay
		ld	a, (Playing)
		or	a
		ld	a, ' '
		jr	z, .notPlay
		ld	a, COL_PLAYING
		ld	(ListColor), a
		ld	a, '>'
.notPlay:	call	TxChar
		pop	hl
		push	hl
		ld	de, (SelIdx)
		or	a
		sbc	hl, de
		jr	nz, .notSel
		ld	a, COL_CUR
		ld	(ListColor), a
.notSel:	pop	hl		; ゲーム内の番号 (1-)
		push	hl
		ld	de, (ViewStart)
		or	a
		sbc	hl, de
		inc	hl
		ld	a, l
		ld	b, h
		inc	b
		dec	b
		jr	z, .n99
		ld	a, 99
.n99:		cp	100
		jr	c, .num
		ld	a, 99
.num:		call	TxDec2
		ld	a, ' '
		call	TxChar
		pop	hl
		push	hl
		call	LoadTitle
		call	TxStr
.draw:		ld	a, (HelpPage)	; ヘルプの表示中は、ウィンドウに重なる行は描かない (閉じたときに描く)
		or	a
		jr	z, .vis
		ld	a, (ListRow)
		cp	HELP_ROW
		jr	c, .vis
		cp	HELP_ROW+HELP_LINES+2
		jr	c, .skip
.vis:		ld	a, (ListColor)
		ld	c, a
		ld	a, (ListRow)
		ld	e, 0
		call	TxRender
.skip:		pop	hl
		ret

; リストの先頭 ListTop を決める。選択曲が見えていれば動かさず、
; はみ出したときだけその端まで動かす。戻り: Z = 先頭が変わらなかった
FixTop:		; ListMax = 最後のページの先頭 (ViewEnd-LIST_ROWS+1。ViewStart より前にはしない)
		ld	hl, (ViewEnd)
		ld	de, LIST_ROWS-1
		or	a
		sbc	hl, de
		jr	c, .useStart
		ld	de, (ViewStart)
		or	a
		sbc	hl, de
		add	hl, de
		jr	nc, .maxOk
.useStart:	ld	hl, (ViewStart)
.maxOk:		ld	(ListMax), hl
		; ゲームより前にあれば、ゲームの先頭へ
		ld	hl, (ListTop)
		ld	de, (ViewStart)
		or	a
		sbc	hl, de
		add	hl, de
		jr	nc, .t1
		ex	de, hl
.t1:		ex	de, hl		; DE = 先頭
		ld	hl, (SelIdx)
		or	a
		sbc	hl, de
		add	hl, de
		jr	c, .clamp	; 選択が先頭より上: 選択を先頭に (HL = 選択)
		push	hl
		or	a
		sbc	hl, de		; HL = 選択 - 先頭
		ld	bc, LIST_ROWS
		or	a
		sbc	hl, bc
		pop	hl
		jr	nc, .below
		ex	de, hl		; 見えている: そのまま
		jr	.clamp
.below:		ld	bc, LIST_ROWS-1	; 選択が下にはみ出す: 選択を最下行に
		or	a
		sbc	hl, bc
.clamp:		ld	de, (ListMax)	; 最後のページより先には行かない
		or	a
		sbc	hl, de
		add	hl, de
		jr	c, .ok
		ex	de, hl
.ok:		ld	de, (ListTop)
		ld	(ListTop), hl
		or	a
		sbc	hl, de
		ret

; 前後のゲーム名 (左半分 PREV、右半分 NEXT。ない方は '-')
; 再生中の曲の情報を描き直す (リスト表示: 再生中の行・リスト・時間・TRACK。CG 表示: 最下行と CG)
DrawPlayInfo:	ld	a, (ViewMode)
		cp	VIEW_CG
		jp	z, CgSongChanged
		or	a
		ret	nz		; 起動時の CG を表示中
		call	DrawPlaying
		call	DrawList
		call	DrawTime
		jp	DrawLoop

; レベルメーター (リスト表示のときだけ)
MetersIfList:	ld	a, (ViewMode)
		or	a
		ret	nz
		jp	UpdateMeters

; エントリ HL の「ゲーム名 / 曲名」を TextBuf に追記
TxGameTitle:	push	hl
		ld	de, E_GAME
		add	hl, de
		ld	e, (hl)
		inc	hl
		ld	d, (hl)
		ex	de, hl
		ld	a, h
		or	l
		jr	z, .noGame
		call	GameName
		call	TxStr
		ld	hl, MsgSep
		call	TxStr
.noGame:	pop	hl
		call	LoadTitleEntry
		jp	TxStr

; ゲームの情報 HL -> HL = 表示するゲーム名
GameName:	ld	de, G_NAME
		add	hl, de
		; そのまま PickLang へ

; 「日本語\0英語\0」の HL -> 英語表示で英語があれば英語、なければ日本語を指す
PickLang:	ld	a, (LangEn)
		or	a
		ret	z
		push	hl
.skip:		ld	a, (hl)
		inc	hl
		or	a
		jr	nz, .skip
		ld	a, (hl)
		or	a
		jr	z, .ja
		pop	de
		ret
.ja:		pop	hl
		ret

; HL = 曲番号 -> HL = 曲名 (TitleBuf の中)
LoadTitle:	call	GetEntry
; HL = エントリ -> HL = 曲名 (TitleBuf の中)
LoadTitleEntry:	ld	de, E_TBANK
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	e, (hl)
		inc	hl
		ld	d, (hl)
		ex	de, hl
		ld	de, TitleBuf
		ld	bc, TITLE_BUF
		di
		call	RamCopy
		ei
		xor	a
		ld	(TitleBuf+TITLE_BUF), a
		ld	hl, TitleBuf
		jr	PickLang

; 文字列 HL を幅 B (2 ドット単位。半角 = 3、全角 = 4) までで切る
TruncUnits:	ld	a, (hl)
		or	a
		ret	z
		ld	c, 3
		bit	7, a
		jr	z, .w
		inc	c
.w:		ld	a, b
		sub	c
		jr	c, .cut
		ld	b, a
		ld	a, c
		cp	4		; 全角は 2 バイト
		jr	c, .adv1
		ld	a, 2
		jr	.adv
.adv1:		ld	a, 1
.adv:		add	a, l
		ld	l, a
		jr	nc, TruncUnits
		inc	h
		jr	TruncUnits
.cut:		ld	(hl), 0
		ret

; 文字列 HL の幅 (2 ドット単位。半角 = 3、全角 = 4) -> A。HL は保存
StrUnits:	push	hl
		ld	b, 0
.l:		ld	a, (hl)
		or	a
		jr	z, .e
		inc	hl
		inc	b
		inc	b
		inc	b
		bit	7, a
		jr	z, .l
		inc	hl
		inc	b
		jr	.l
.e:		ld	a, b
		pop	hl
		ret

;-----------------------------------------------------------------------------
; ゲームの行: 前のゲーム <- 【選んでいるゲーム】 -> 次のゲーム
; 中央を真ん中に置き、左右のゲーム名は入る分だけ (左は右寄せ。入らなければ先頭から)
DrawGameSel:	ld	hl, 0
		ld	(GsPrev), hl
		ld	(GsNext), hl
		ld	hl, (ViewStart)
		ld	a, h
		or	l
		jr	z, .np
		dec	hl
		call	GameKey
		ld	(GsPrev), de
.np:		ld	hl, (ViewEnd)
		inc	hl
		push	hl
		ld	de, (PlaylistTable)
		or	a
		sbc	hl, de
		pop	hl
		jr	nc, .nn
		call	GameKey
		ld	(GsNext), de
.nn:		; 中央の文字列
		call	TxStart
		ld	hl, (GsPrev)
		ld	a, h
		or	l
		jr	z, .lsp
		ld	hl, MsgLArrow
		call	TxStr
		jr	.lb
.lsp:		ld	b, 3
		call	TxSpaces
.lb:		ld	hl, UiBrkL
		call	TxStr
		ld	hl, (ViewStart)
		call	GameKey
		ex	de, hl
		ld	a, h
		or	l
		jr	z, .nog
		call	GameName
		call	TxStr
.nog:		ld	hl, UiBrkR
		call	TxStr
		ld	hl, (GsNext)
		ld	a, h
		or	l
		jr	z, .rsp
		ld	hl, MsgRArrow
		call	TxStr
		jr	.rb
.rsp:		ld	b, 3
		call	TxSpaces
.rb:		ld	hl, TextBuf
		call	StrUnits	; A = 中央の幅
		ld	b, a
		ld	a, 128		; 先頭のマス = (128 - 幅) / 8  (1 行 = 128、1 マス = 4)
		sub	b
		jr	nc, .c
		xor	a
.c:		srl	a
		srl	a
		srl	a
		ld	(GsCell0), a
		ld	a, b		; 終わりのマス = 先頭 + (幅 + 3) / 4
		add	a, 3
		srl	a
		srl	a
		ld	c, a
		ld	a, (GsCell0)
		add	a, c
		cp	33
		jr	c, .cn
		ld	a, 32
.cn:		ld	(GsCellN), a
		ld	b, a
		ld	a, (GsCell0)
		cp	b
		jr	z, .left	; 幅 0 (ありえないが念のため)
		ld	d, b
		ld	b, a
		ld	hl, TextBuf
		ld	a, LN_GAMESEL
		ld	c, COL_SEL
		ld	e, 0
		call	RenderLineAt
.left:		; 左: 前のゲーム (マス 0 - GsCell0)
		ld	a, (GsCell0)
		or	a
		jr	z, .right
		call	TxStart
		ld	hl, (GsPrev)
		ld	a, h
		or	l
		jr	z, .lDraw
		call	GameName
		push	hl
		call	StrUnits
		ld	b, a		; 入るなら右寄せ (幅 = 4*GsCell0 - 3: 中央との間に半角 1 文字)
		ld	a, (GsCell0)
		add	a, a
		add	a, a
		sub	3
		jr	c, .lnone
		ld	c, a		; C = 入る幅
		sub	b
		jr	c, .lcut
		ld	b, 0		; 空白の数 = 余り / 3
.dv:		sub	3
		jr	c, .dve
		inc	b
		jr	.dv
.dve:		ld	a, b
		or	a
		jr	z, .lnopad
		call	TxSpaces
.lnopad:	pop	hl
		call	TxStr
		jr	.lDraw
.lcut:		pop	hl		; 入らない: 入る幅で切る
		call	TxStr
		ld	b, c
		ld	hl, TextBuf
		call	TruncUnits
		jr	.lDraw
.lnone:		pop	hl
.lDraw:		ld	a, (GsCell0)
		ld	d, a
		ld	b, 0
		ld	hl, TextBuf
		ld	a, LN_GAMESEL
		ld	c, COL_SIDE
		ld	e, 0
		call	RenderLineAt
.right:		; 右: 次のゲーム (マス GsCellN - 32)
		ld	a, (GsCellN)
		cp	32
		ret	nc
		call	TxStart
		ld	a, ' '
		call	TxChar
		ld	hl, (GsNext)
		ld	a, h
		or	l
		jr	z, .rDraw
		call	GameName
		call	TxStr
.rDraw:		ld	a, (GsCellN)
		ld	b, a
		ld	d, 32
		ld	hl, TextBuf
		ld	a, LN_GAMESEL
		ld	c, COL_SIDE
		ld	e, 0
		jp	RenderLineAt

;-----------------------------------------------------------------------------
; キーボードのどれかが押されているか -> A (0 = 押されていない)
AnyKey:		di
		in	a, (0AAh)
		ld	b, a
		and	0F0h
		ld	c, a
		ld	d, 0FFh
		ld	h, 0
.r:		ld	a, c
		or	h
		out	(0AAh), a
		in	a, (0A9h)
		and	d
		ld	d, a
		inc	h
		ld	a, h
		cp	11
		jr	c, .r
		ld	a, b
		out	(0AAh), a
		ei
		ld	a, d
		cpl
		ret

;=============================================================================
; V9990 (GFX9000 など) に CG を出す。内蔵 VDP は曲選択の画面のまま
;  SCREEN 5 -> B1 (256x212) の BP4、SCREEN 7 -> B3 (512x212) の BP4、SCREEN 8 -> B1 の BD8 (同じ GGGRRRBB)
;  パレットは 3 ビットを 5 ビットにして送る。CG のないゲームでは表示を消す
V9_VRAM		equ	60h		; VRAM データ
V9_PAL		equ	61h		; パレット データ
V9_DATA		equ	63h		; レジスタ データ
V9_SEL		equ	64h		; レジスタの選択
V9_SYS		equ	67h		; システム制御 (bit1 = ソフトリセット)

; V9990 があるか調べる -> HasExtVdp。あればリセットして表示を消しておく
V9Detect:	ld	a, 2		; ソフトリセット
		out	(V9_SYS), a
		xor	a
		out	(V9_SYS), a
		ld	a, 15		; R#15 (周辺の色) に書いて読み返す
		out	(V9_SEL), a
		ld	a, 2Ah
		out	(V9_DATA), a
		ld	a, 15
		out	(V9_SEL), a
		in	a, (V9_DATA)
		cp	2Ah
		ld	a, 0
		jr	nz, .no
		ld	b, 0		; 周辺の色は黒
		ld	a, 15
		call	V9Reg
		ld	b, 42h		; 表示しない、カーソル (スプライト) なし、VRAM 512KB
		ld	a, 8
		call	V9Reg
		ld	a, 1
.no:		ld	(HasExtVdp), a
		or	a
		ret	nz
		jp	V8Detect	; V9990 がなければ V9968 (I/O 88h) を調べる

; V9990 のレジスタ A に B を書く
V9Reg:		out	(V9_SEL), a
		ld	a, b
		out	(V9_DATA), a
		ret

; 曲を始めた: V9990 があれば、そのゲームの CG にする (起動時の曲は起動時の CG のまま)
V9SongCG:	ld	a, (HasExtVdp)
		or	a
		ret	z
		ld	a, (IsStartup)
		or	a
		ret	nz
		call	PlayCgRec
		jr	nz, V9ShowCG
		ld	hl, V9None
		; そのまま V9ShowCG へ

; V9990 に CG HL (バンク, 画面モード, 文字色, 背景色) を出す。バンク 0 なら表示を消す
V9ShowCG:	ld	a, (HasExtVdp)
		cp	2
		jp	z, V8ShowCG	; V9968
		ld	a, (hl)
		ld	b, a
		ld	a, (V9Cur)
		cp	b
		ret	z		; もう出している
		ld	de, V9Cur
		ld	bc, 4
		ldir
		ld	a, (V9Cur+1)	; bit7 = インターレース (512x424)
		ld	b, a
		and	7Fh
		ld	(V9Cur+1), a
		ld	a, b
		rlca
		and	1
		ld	(V9IL), a
		ld	b, 42h		; 転送の間は表示しない (カーソルなし)
		ld	a, 8
		call	V9Reg
		ei			; 表示を止めるのは次のフレームからなので、2 フレーム待ってから
		halt			; 画面モードを替える (替えた直後の 1 フレームに前の CG が崩れて見える)
		halt
		ld	a, (V9Cur)
		or	a
		ret	z		; CG なし: 消したまま
		; 画面モード
		ld	a, (V9Cur+1)
		ld	b, 81h		; SCREEN 5: ビットマップ、256 ドット、幅 256、4 ビット
		ld	c, 00h
		cp	5
		jr	z, .mode
		ld	b, 95h		; SCREEN 7: ビットマップ、512 ドット、幅 512、4 ビット
		cp	7
		jr	z, .mode
		ld	b, 82h		; SCREEN 8: ビットマップ、256 ドット、幅 256、8 ビット
		ld	c, 40h		;           R#13 = 40h で BD8 (GGGRRRBB)
.mode:		push	bc
		ld	a, 6
		call	V9Reg
		ld	b, 0		; R#7: NTSC、ノンインターレース
		ld	a, (V9IL)
		or	a
		jr	z, .r7
		ld	b, 06h		;       インターレース (IL) で偶数・奇数ラインを交互に (EO)
.r7:		ld	a, 7
		call	V9Reg
		pop	bc
		ld	b, c
		ld	a, 13
		call	V9Reg
		; パレット (SCREEN 5 / 7)
		ld	a, (V9Cur+1)
		cp	8
		jr	z, .data
		ld	a, (V9Cur)	; CG の先頭 32 バイト
		call	CgPalette
		ld	b, 0		; パレットの書き込み位置 0
		ld	a, 14
		call	V9Reg
		ld	hl, TextBuf
		ld	b, 16
.pal:		push	bc
		ld	a, (hl)		; RB
		rrca
		rrca
		rrca
		rrca
		call	V9Pal5		; R
		inc	hl
		ld	a, (hl)		; G
		call	V9Pal5
		dec	hl
		ld	a, (hl)		; B
		call	V9Pal5
		inc	hl
		inc	hl
		pop	bc
		djnz	.pal
.data:		; VRAM 0 から送る (256 バイトずつ。間に割込みを通す)
		ld	b, 0
		ld	a, 0
		call	V9Reg
		ld	b, 0
		ld	a, 1
		call	V9Reg
		ld	b, 0
		ld	a, 2
		call	V9Reg
		ld	a, (V9Cur+1)
		cp	5
		ld	hl, 27136/256
		jr	z, .n
		ld	hl, 54272/256
		ld	a, (V9IL)
		or	a
		jr	z, .n
		ld	hl, 212*2	; インターレース: 偶数ライン 212 + 奇数ライン 212
.n:		ld	(CgLeft), hl
		ld	hl, 0
		ld	(V9Y), hl
		ld	hl, V9Cur
		call	CgDecStart
.chunk:		ld	a, (V9IL)
		or	a
		jr	z, .out
		; インターレース: 1 ライン (256 バイト) ごとに VRAM の位置を V9Y*256 にする (V9Y = 0,2,4.. の後 1,3,5..)
		ld	hl, (CgLeft)
		ld	de, 212
		or	a
		sbc	hl, de
		jr	nz, .addr
		ld	hl, 1		; 偶数ラインを送り終えた: 奇数ラインへ
		ld	(V9Y), hl
.addr:		ld	b, 0
		ld	a, 0
		call	V9Reg
		ld	a, (V9Y)
		ld	b, a
		ld	a, 1
		call	V9Reg
		ld	a, (V9Y+1)
		ld	b, a
		ld	a, 2
		call	V9Reg
		ld	hl, (V9Y)
		inc	hl
		inc	hl
		ld	(V9Y), hl
.out:		ld	c, V9_VRAM
		ld	b, 0
		di
		call	CgDec
		ei
		ld	hl, (CgLeft)
		dec	hl
		ld	(CgLeft), hl
		ld	a, h
		or	l
		jp	nz, .chunk
		ld	b, 0C2h		; 表示する、カーソル (スプライト) なし、VRAM 512KB
		ld	a, 8
		jp	V9Reg

; パレットの 1 色 (A の下位 3 ビット) を 5 ビットにして送る
V9Pal5:		push	hl
		and	7
		ld	e, a
		ld	d, 0
		ld	hl, V9Lv5
		add	hl, de
		ld	a, (hl)
		out	(V9_PAL), a
		pop	hl
		ret

V9Lv5:		db	0, 4, 9, 13, 18, 22, 27, 31
V9None:		db	0, 0, 0, 0

;=============================================================================
; V9968 (HRA! 氏の V9968 カートリッジ、I/O 88h-8Bh) に CG を出す。内蔵 VDP は曲選択の画面のまま
;  V9958 として使う (拡張レジスタは触らない) ので、88h にある V9938 / V9958 でも動く。
;  SCREEN 5 / 7 / 8 を内蔵 VDP と同じ画面モード・同じ VRAM 配置で出す (インターレースは SCREEN 7 のページ 0 / 1)。
;  割込みは使わない (R#0 IE1 = 0、R#1 IE0 = 0)
V8_VRAM		equ	88h		; VRAM データ
V8_CTRL		equ	89h		; レジスタの書き込み / 状態の読み出し / VRAM のアドレス
V8_PAL		equ	8Ah		; パレット

; V9968 (88h の VDP) があるか調べる -> HasExtVdp = 2。あれば表示を消しておく
;  S#1 の ID が V9938 (0) か V9958 (2) で、VRAM に書いた 2 バイトが読み返せること
V8Detect:	ld	a, (0006h)	; 本体の VDP が 88h にある (MSX1 + MSX2 アップグレードキット) なら、それは使わない
		cp	V8_VRAM
		jr	z, .no
		di
		in	a, (V8_CTRL)	; 書き込みの順番 (1 バイト目 / 2 バイト目) を戻す
		ld	bc, 1*256+15	; S#1 を読む
		call	V8Reg
		in	a, (V8_CTRL)
		ld	d, a
		ld	bc, 0*256+15
		call	V8Reg
		ld	a, d
		rrca
		and	1Fh		; ID (何もなければ FFh なので 1Fh)
		jr	z, .vram
		cp	2
		jr	nz, .no
.vram:		ld	bc, 0*256+1	; 表示しない、割込みなし
		call	V8Reg
		ld	bc, 0*256+14	; VRAM 0 に 55h, AAh を書いて読み返す
		call	V8Reg
		xor	a
		out	(V8_CTRL), a
		ld	a, 40h
		out	(V8_CTRL), a
		ld	a, 55h
		out	(V8_VRAM), a
		cpl
		out	(V8_VRAM), a
		xor	a
		out	(V8_CTRL), a
		out	(V8_CTRL), a	; 読み出しのアドレス 0
		ex	(sp), hl	; 先読みを待つ
		ex	(sp), hl
		in	a, (V8_VRAM)
		cp	55h
		jr	nz, .no
		ex	(sp), hl
		ex	(sp), hl
		in	a, (V8_VRAM)
		cp	0AAh
		jr	nz, .no
		ld	a, 2
		jr	.set
.no:		xor	a
.set:		ld	(HasExtVdp), a
		ei
		ret

; V9968 のレジスタ C に B を書く
V8Reg:		ld	a, b
		out	(V8_CTRL), a
		ld	a, c
		or	80h
		out	(V8_CTRL), a
		ret

; V9968 に CG HL (バンク, 画面モード, 文字色, 背景色) を出す。バンク 0 なら表示を消す
V8ShowCG:	ld	a, (hl)
		ld	b, a
		ld	a, (V9Cur)
		cp	b
		ret	z		; もう出している
		ld	de, V9Cur
		ld	bc, 4
		ldir
		ld	a, (V9Cur+1)	; bit7 = インターレース (512x424)
		ld	b, a
		and	7Fh
		ld	(V9Cur+1), a
		ld	a, b
		rlca
		and	1
		ld	(V9IL), a
		di
		ld	bc, 0*256+1	; 転送の間は表示しない
		call	V8Reg
		ei
		ld	a, (V9Cur)
		or	a
		ret	z		; CG なし: 消したまま
		; 画面モード: SCREEN 5 = G4 (R#0 = 06h)、7 = G6 (0Ah)、8 = G7 (0Eh)
		ld	a, (V9Cur+1)
		ld	b, 06h
		cp	5
		jr	z, .mode
		ld	b, 0Ah
		cp	7
		jr	z, .mode
		ld	b, 0Eh
.mode:		di
		ld	c, 0
		call	V8Reg
		ld	hl, V8Regs	; スプライトなし、212 ライン、ページ 0、周辺の色 0、スクロールなし
		ld	b, (V8RegsEnd-V8Regs)/2
.regs:		push	bc
		ld	c, (hl)
		inc	hl
		ld	b, (hl)
		inc	hl
		call	V8Reg
		pop	bc
		djnz	.regs
		ld	a, (V9IL)
		or	a
		jr	z, .pal
		ld	bc, 8Ch*256+9	; 212 ライン + インターレース (IL) + ページ 0 / 1 を交互に (EO)
		call	V8Reg
		ld	bc, 3Fh*256+2	; R#2: ページ 1 (EO でページ 0 と 1 を交互に)
		call	V8Reg
.pal:		ei
		; パレット (SCREEN 5 / 7。CG の先頭 32 バイトは内蔵 VDP と同じ形)
		ld	a, (V9Cur+1)
		cp	8
		jr	z, .data
		ld	a, (V9Cur)
		call	CgPalette
		di
		ld	bc, 0*256+16	; パレットの書き込み位置 0
		call	V8Reg
		ld	hl, TextBuf
		ld	bc, 32*256+V8_PAL
		otir
		ei
.data:		; VRAM 0 から送る (256 バイトずつ。間に割込みを通す)
		ld	a, (V9Cur+1)
		cp	5
		ld	hl, 27136/256
		jr	z, .n
		ld	hl, 54272/256
		ld	a, (V9IL)
		or	a
		jr	z, .n
		ld	hl, 212*2	; インターレース: 偶数ライン 212 (ページ 0) + 奇数ライン 212 (ページ 1)
.n:		ld	(CgLeft), hl
		ld	b, 0		; VRAM 0
		call	V8Addr
		ld	hl, V9Cur
		call	CgDecStart
.chunk:		ld	a, (V9IL)
		or	a
		jr	z, .out
		ld	hl, (CgLeft)
		ld	de, 212
		or	a
		sbc	hl, de
		jr	nz, .out
		ld	b, 4		; 偶数ラインを送り終えた: 奇数ラインを VRAM 10000h (ページ 1) へ
		call	V8Addr
.out:		ld	c, V8_VRAM
		ld	b, 0
		di
		call	CgDec
		ei
		ld	hl, (CgLeft)
		dec	hl
		ld	(CgLeft), hl
		ld	a, h
		or	l
		jp	nz, .chunk
		di
		ld	bc, 40h*256+1	; 表示する (割込みなし)
		call	V8Reg
		ei
		ret

; V9968 の VRAM の書き込み位置を B * 4000h にする (R#14 = B、下位 14 ビット = 0)
V8Addr:		di
		ld	c, 14
		call	V8Reg
		xor	a
		out	(V8_CTRL), a
		ld	a, 40h
		out	(V8_CTRL), a
		ei
		ret

V8Regs:		db	8, 0Ah		; スプライトなし (VRAM 64K x 4 ビット)
		db	9, 80h		; 212 ライン、ノンインターレース、NTSC
		db	2, 1Fh		; ページ 0
		db	7, 00h		; 周辺の色 0
		db	23, 00h		; 縦スクロール 0
		db	18, 00h		; 表示位置の調整なし
		db	25, 00h		; V9958: YJK なし、横スクロールなし
		db	26, 00h
		db	27, 00h
V8RegsEnd:

;=============================================================================
; CG の表示 (MSX2 以降。SCREEN 5 / SCREEN 8、212 ライン)

; V: リスト <-> 再生中のゲームの CG (まだ何も鳴らしていなければ選んでいるゲームの CG)
ToggleView:	ld	a, (ViewMode)
		or	a
		jp	nz, ReturnToList
		ld	a, (HasExtVdp)
		or	a
		ret	nz		; V9990 があれば CG は常に V9990 に出している
		ld	a, (MsxVer)
		or	a
		ret	z		; MSX1
		call	CgGame		; HL = ゲームの情報, A = 1 なら選択中の曲を出す
		ret	z
		ld	(CgShowSel), a
		ld	a, (hl)		; G_CGBANK
		or	a
		ret	z		; このゲームの CG はない
		ld	a, VIEW_CG
		ld	(ViewMode), a
		call	ShowCG
		jp	DrawCgLine

; CG を出すゲーム -> HL = ゲームの情報 (Z = なし)。A = 0: 再生中の曲のゲーム / 1: まだ何も鳴らしていないので選んでいる曲のゲーム
CgGame:		ld	a, (CurEntry+E_SBANK)
		or	a
		jr	z, .sel
		call	PlayCgRec
		ld	a, 0
		jr	.chk
.sel:		ld	hl, (SelIdx)
		call	GetEntry
		ld	de, E_GAME
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	h, (hl)
		ld	l, a
		ld	a, 1
.chk:		ld	b, a
		ld	a, h
		or	l
		ld	a, b
		ret

; CG 表示中に曲が変わった・止まった: ゲームが変わったら CG を替える (CG がなければリストへ)
CgSongChanged:	xor	a
		ld	(CgShowSel), a
		ld	a, (Playing)
		or	a
		jr	z, .line
		call	PlayCgRec
		ld	a, h
		or	l
		jp	z, ReturnToList
		ld	a, (hl)
		or	a
		jp	z, ReturnToList
		ld	b, a
		ld	a, (CgCur)
		cp	b
		jr	z, .line
		call	ShowCG
.line:		jp	DrawCgLine

; CG HL (バンク, 画面モード, 文字色, 背景色) を表示する
ShowCG:		ld	de, CgCur
		ld	bc, 4
		ldir
		ld	a, (CgCur+1)	; bit7 = インターレース (SCREEN 7 の 512x424。ページ 0 = 偶数ライン、1 = 奇数ライン)
		ld	b, a
		and	7Fh
		ld	(CgCur+1), a
		ld	a, b
		rlca
		and	1
		ld	(CgIL), a
		; 最下行の文字の色の表
		ld	a, (CgCur+2)
		ld	b, a		; 文字色
		ld	a, (CgCur+3)
		ld	c, a		; 背景色
		ld	(CgTbl2), a
		ld	a, b
		ld	(CgTbl2+1), a
		ld	a, (CgCur+1)	; SCREEN 7: 1 ドットを横 2 ドット (1 バイト) にする
		cp	7
		jr	nz, .not7
		ld	a, c
		call	Nibble2
		ld	(CgTbl2), a
		ld	a, b
		call	Nibble2
		ld	(CgTbl2+1), a
.not7:
		ld	a, c		; SCREEN 5: 2 ドット = 1 バイト (上位 4 ビットが左)
		add	a, a
		add	a, a
		add	a, a
		add	a, a
		ld	d, a		; 背景色 << 4
		or	c
		ld	(CgTbl4), a
		ld	a, d
		or	b
		ld	(CgTbl4+1), a
		ld	a, b
		add	a, a
		add	a, a
		add	a, a
		add	a, a
		ld	d, a		; 文字色 << 4
		or	c
		ld	(CgTbl4+2), a
		ld	a, d
		or	b
		ld	(CgTbl4+3), a
		; 画面モード (切り替えで消した画面や前の CG を見せないよう、黒いパレット・背景色 0 で)
		call	BlackPalette
		xor	a
		ld	(BAKCLR), a
		ld	(BDRCLR), a
		ld	a, (CgCur+1)
		call	CHGMOD
		di
		ld	a, (RG1SAV)	; 転送の間は表示を止める
		and	0BFh
		ld	b, a
		ld	c, 1
		call	WrVdp
		ld	a, (RG8SAV)	; スプライトを止める
		or	2
		ld	(RG8SAV), a
		ld	b, a
		ld	c, 8
		call	WrVdp
		ld	a, (RG9SAV)	; 212 ライン (インターレースなら IL・EO も)
		and	73h
		or	80h
		ld	b, a
		ld	a, (CgIL)
		or	a
		ld	a, b
		jr	z, .r9
		or	0Ch
.r9:		ld	(RG9SAV), a
		ld	b, a
		ld	c, 9
		call	WrVdp
		ld	b, 0		; 周辺の色は黒
		ld	c, 7
		call	WrVdp
		ld	a, (CgIL)
		or	a
		jr	z, .r2
		ld	b, 3Fh		; R#2: ページ 1 (EO でページ 0 と 1 を交互に)
		ld	c, 2
		call	WrVdp
.r2:		ei
		; VRAM 0 から CG を送る (256 バイトずつ。間に割込みを通す)
		di
		ld	b, 0
		ld	c, 14
		call	WrVdp
		ld	a, (0007h)
		inc	a
		ld	c, a
		xor	a
		out	(c), a
		ld	a, 40h
		out	(c), a
		ei
		ld	a, (CgCur+1)
		cp	5
		ld	hl, 27136/256
		jr	z, .n
		ld	hl, 54272/256
		ld	a, (CgIL)
		or	a
		jr	z, .n
		ld	hl, 212*2	; インターレース: 偶数ライン 212 + 奇数ライン 212
.n:		ld	(CgLeft), hl
		ld	hl, CgCur
		call	CgDecStart
.chunk:		ld	a, (CgIL)
		or	a
		jr	z, .out
		ld	hl, (CgLeft)
		ld	de, 212
		or	a
		sbc	hl, de
		jr	nz, .out
		; 偶数ラインを送り終えた: 奇数ラインを VRAM 10000h (ページ 1) へ
		di
		ld	b, 4
		ld	c, 14
		call	WrVdp
		ld	a, (0007h)
		inc	a
		ld	c, a
		xor	a
		out	(c), a
		ld	a, 40h
		out	(c), a
		ei
.out:		ld	a, (0007h)
		ld	c, a
		ld	b, 0
		di
		call	CgDec
		ei
		ld	hl, (CgLeft)
		dec	hl
		ld	(CgLeft), hl
		ld	a, h
		or	l
		jp	nz, .chunk
		; SCREEN 5 / 7 のパレット (CG の先頭 32 バイト)
		ld	a, (CgCur+1)
		cp	8
		jr	z, .show
		ld	a, (CgCur)
		call	CgPalette
		ld	hl, TextBuf
		call	SetPalette
.show:		di
		ld	a, (RG1SAV)	; 表示を戻す
		or	40h
		ld	b, a
		ld	c, 1
		call	WrVdp
		ei
		ret

; A の下位 4 ビットを上位にも並べる (SCREEN 7 で 2 ドットを同じ色にする)
Nibble2:	and	0Fh
		ld	d, a
		add	a, a
		add	a, a
		add	a, a
		add	a, a
		or	d
		ret

; VDP レジスタ C に B を書く (DI で呼ぶ。C, D を壊す)
WrVdp:		ld	a, (0007h)
		inc	a
		ld	d, c
		ld	c, a
		out	(c), b
		ld	a, d
		or	80h
		out	(c), a
		ret

; パレット 16 色 (HL から 32 バイト) を書く
SetPalette:	di
		ld	b, 0
		ld	c, 16
		call	WrVdp
		ld	a, (0007h)
		add	a, 2
		ld	c, a
		ld	b, 32
.p:		outi
		jr	nz, .p
		ei
		ret

; MSX2 の既定のパレット
DefaultPalette:	db	00h,0, 00h,0, 11h,6, 33h,7, 17h,1, 27h,3, 51h,1, 27h,6
		db	71h,1, 73h,3, 61h,6, 64h,6, 11h,4, 65h,2, 55h,5, 77h,7

; CG 表示をやめてリストの画面 (SCREEN 2) に戻し、全部描き直す
ReturnToList:	xor	a
		ld	(ViewMode), a
		ld	a, (MsxVer)
		or	a
		jr	z, .scr
		call	BlackPalette	; 描き終わるまで見せない
		di
		ld	a, (RG9SAV)	; 192 ライン、ノンインターレース
		and	73h
		ld	(RG9SAV), a
		ld	b, a
		ld	c, 9
		call	WrVdp
		ei
.scr:		call	InitScreen
		call	DrawStatic
		call	SetupMeters
		ld	hl, MtDisp	; メーターは 0 から描き直す
		ld	de, MtDisp+1
		ld	bc, 11
		ld	(hl), 0
		ldir
		call	DrawGameSel
		call	DrawPlaying
		call	DrawList
		call	DrawTime
		call	DrawLoop
		; そのまま ListPalette へ

; 曲選択の画面のパレット (MSX2 の既定) にする。MSX1 では何もしない
ListPalette:	ld	a, (MsxVer)
		or	a
		ret	z
		ld	hl, DefaultPalette
		jp	SetPalette

; パレットを全部黒にする (MSX2 以降。MSX1 では何もしない)
BlackPalette:	ld	a, (MsxVer)
		or	a
		ret	z
		di
		ld	b, 0
		ld	c, 16
		call	WrVdp
		ld	a, (0007h)
		add	a, 2
		ld	c, a
		ld	b, 32
		xor	a
.p:		out	(c), a
		djnz	.p
		ei
		ret

; CG の最下行: 「ゲーム名 / 曲名」(再生中。カーソルで選択を動かしたら選択中の曲)
DrawCgLine:	ld	a, (ViewMode)
		cp	VIEW_CG
		ret	nz
		call	TxStart
		ld	a, (CgShowSel)
		or	a
		jr	nz, .sel
		ld	a, (Playing)
		or	a
		jr	nz, .play
		ld	hl, MsgStop
		call	TxStr
		jr	.draw
.play:		ld	hl, CurEntry
		call	TxGameTitle
		jr	.draw
.sel:		ld	hl, (SelIdx)
		call	GetEntry
		call	TxGameTitle
.draw:		ld	hl, TextBuf
		xor	a
		ld	c, a
		ld	e, RF_BMP
		jp	RenderLine

; 行バッファを CG の最下行 (y = 200-211) に描く (インターレースならページ 0 と 1 の両方)
BmpWriteLine:	xor	a
		ld	(BmpPage), a
		call	BmpWrite1
		ld	a, (CgIL)
		or	a
		ret	z
		ld	a, 4		; ページ 1 = VRAM 10000h
		ld	(BmpPage), a
BmpWrite1:	di
		ld	a, (CgCur+1)
		cp	5
		jr	nz, .a8
		ld	b, 1		; SCREEN 5: 200*128 = 06400h
		ld	c, 14
		call	WrVdp
		ld	e, 24h
		jr	.adr
.a8:		ld	a, (BmpPage)	; SCREEN 7 / 8: 200*256 = 0C800h (+ ページ)
		or	3
		ld	b, a
		ld	c, 14
		call	WrVdp
		ld	e, 08h
.adr:		ld	a, (0007h)
		inc	a
		ld	c, a
		xor	a
		out	(c), a
		ld	a, e
		or	40h
		out	(c), a
		ei
		dec	c		; データのポート
		ld	e, 0		; ドット行
.row:		ld	hl, LineBuf
		ld	a, l
		add	a, e
		ld	l, a
		jr	nc, .r1
		inc	h
.r1:		ld	b, 32
.cell:		ld	d, (hl)
		ld	a, (CgCur+1)
		cp	5
		jr	nz, .c8
		dup	4
		ld	a, d
		rlca
		rlca
		and	3
		sla	d
		sla	d
		call	LookOut4
		edup
		jr	.nx
.c8:		dup	8
		ld	a, d
		rlca
		and	1
		sla	d
		call	LookOut2
		edup
.nx:		push	de
		ld	de, 16
		add	hl, de
		pop	de
		dec	b
		jp	nz, .cell
		inc	e
		ld	a, e
		cp	12
		jp	c, .row
		ret

LookOut4:	push	hl
		ld	hl, CgTbl4
		jr	LookOut
LookOut2:	push	hl
		ld	hl, CgTbl2
LookOut:	add	a, l
		ld	l, a
		ld	a, h
		adc	a, 0
		ld	h, a
		ld	a, (hl)
		out	(c), a
		pop	hl
		ret

;-----------------------------------------------------------------------------
MsgTitle:	db	"MICRO CABIN MUSIC PLAYER",0
MsgSound:	db	"SOUND:",0
MsgFMNone:	db	"PSG ONLY",0
MsgFMInt:	db	"MSX-MUSIC",0
MsgFMPac:	db	"FM-PAC",0
MsgTrack:	db	"TRACK ",0
MsgTime:	db	"TIME ",0
MsgLoop:	db	"LOOP ",0
MsgInf:		db	"--",0
MsgStop:	db	"STOP",0
MsgSep:		db	" / ",0
MsgNoTrack:	db	"---",0
MsgModes:	db	"ALL",0,0,0,0,0, "GAME",0,0,0,0, "ONE",0,0,0,0,0
MsgRpt:		db	"REPEAT",0
MsgOnce:	db	"ONCE",0
MsgLArrow:	db	"<- ",0
MsgRArrow:	db	" ->",0
; 【 と 】 (全角。build_rom.py が全角フォントの番号を書き込む)
UiBrkL:		db	0, 0, 0
UiBrkR:		db	0, 0, 0
HelpText:	ds	460, 0
; 曲ごとの CG (build_rom.py が書く): 曲番号 (2), CG (バンク, 画面モード, 文字色, 背景色) x SONG_CG_MAX、0FFFFh で終わり
SONG_CG_MAX	equ	24
SongCgTbl:	ds	6*SONG_CG_MAX+2, 0FFh		; ヘルプの文字列 (build_rom.py が書く)
MsgNoSongs:	db	"NO TRACKS IN PLAYLIST",0
MsgNoRam:	db	"NEED RAM IN PAGE 2 (32KB+)",0
Empty:		db	0

; 半角フォント 20h-7Eh (1字 12 バイト、上位4ビットに字形)。build_rom.py が作る
HalfFont:	incbin	"halffont.bin"

		assert	$-HalfFont = 95*12

;=============================================================================
; レベルメーター (12ch: PSG 3 + FM 9) 右上
;
;  バーは幅 6 ドットで 8 ドットおき。マス列 18-20 (PSG) と 22-30 (FM) を基準に右へ 6 ドットずらした位置
;  (マス X の 7 ドット目と、マス X+1 の 0-4 ドット目) にあり、1 つのマスに隣り合う 2 本の端が入る。
;  チャンネル名はマス X+1 の 0-4 ドット目 (1 字が 1 マスに収まるので、チャンネルごとに色を変えられる)。
;  使うマスは 18-31。チャンネル名は各バーの中央の真下。y = 0-35 (行0-2) の範囲で、
;  1段 2 ドット (1 ドット点灯 + 1 ドットすき間) x 15 段。段 k の点灯行は y = 34-2k。
;  色は上から赤 (13-15段)・黄 (10-12段)・緑で固定し、毎フレームは高さが変わったマスの
;  模様だけを書き換える。マス行 4 (y 32-39) は上半分 (y 32-35) だけがメーターで、
;  下半分は行3 (チャンネル番号) のもの。
;  表示: 新しい音が鳴ると (ドライバの OP_play から MtNoteOn が呼ばれる) その音量まで
;  跳ね上がり、あとは MT_DECAY フレームに 1 段ずつ下がる。音が続いている間は音量の半分で止まる。
;  音量: PSG はチップのレジスタ (R7, R8-R10)、FM はドライバのチャンネル表から。
;  キーオン中 (リズムはリズムのキー) の音量 (ix+9 = 減衰量) で、フェード中はその段数だけ下げる。

MT_BOTTOM	equ	34		; 段 k の点灯行 = MT_BOTTOM - 2k
MT_CELL0	equ	18		; メーターの最初のマス
MT_CELLN	equ	32		; メーターの最後のマス + 1
MT_DECAY	equ	3		; 何フレームに 1 段下げるか

; メーターの準備 (色表)。起動時に1回。チャンネル番号は UpdateMeters が描く
SetupMeters:	ld	c, MT_CELL0	; マス 18-31
.bar:		ld	b, 0		; マス行 0-4
.crow:		push	bc
		ld	a, b		; 色の列 MtColTab + マス行*8
		add	a, a
		add	a, a
		add	a, a
		ld	e, a
		ld	d, 0
		ld	hl, MtColTab
		add	hl, de
		push	hl
		ld	a, c		; DE = マス行*256 + マス*8
		add	a, a
		add	a, a
		add	a, a
		ld	e, a
		ld	d, b
		ld	hl, (GRPCOL)
		add	hl, de
		ex	de, hl
		pop	hl
		di
		push	bc
		call	VdpSetW
		pop	af		; A = マス行 (B)
		push	af
		cp	4
		ld	b, 8
		jr	c, .w
		ld	b, 4		; マス行 4 は上半分だけ
.w:		xor	a
		ld	(WlConst), a
		call	WlOut
		pop	bc
		ei
		pop	bc
		inc	b
		ld	a, b
		cp	5
		jr	c, .crow
		inc	c
		ld	a, c
		cp	MT_CELLN
		jr	c, .bar
		ld	a, 0FFh		; チャンネル番号を必ず描くように
		ld	(MtLabelMode), a
		ret

; バー A (0-11) の基準のマス -> A (18+ch (PSG), 19+ch (FM: 1 マス空ける))
MtCol:		cp	3
		jr	c, .p
		inc	a
.p:		add	a, MT_CELL0
		ret

; 基準のマスが A のバー -> A (なければ 0FFh)
MtBarOf:	sub	MT_CELL0
		jr	c, .none
		cp	3
		ret	c
		jr	z, .none
		cp	13
		jr	nc, .none
		dec	a
		ret
.none:		ld	a, 0FFh
		ret

; バー A の点灯のしきい値 -> A (y >= これなら点灯。バーなし (0FFh) は点灯しない)
MtThres:	cp	0FFh
		ret	z
		ld	e, a
		ld	d, 0
		ld	hl, MtDisp
		add	hl, de
		ld	a, (hl)
		add	a, a
		ld	b, a
		ld	a, MT_BOTTOM
		sub	b
		ret

; チャンネル名の行 (行3 の右側。PSG は A B C、FM は 1-9。リズムモードでは最後の 3 つが B S H)
DrawMeterLabels:
		ld	(MtLabelMode), a
		push	af
		call	TxStart
		ld	hl, MtLblHead
		call	TxStr
		pop	af
		or	a
		ld	hl, MtLblFM
		jr	z, .fm
		ld	hl, MtLblRhy
.fm:		call	TxStr
		ld	hl, TextBuf
		ld	a, LN_TIME
		ld	c, COL_LABEL
		ld	e, 0
		ld	b, TOP_CELLS
		ld	d, 32
		call	RenderLineAt
		; そのまま MtLabelColors へ

; チャンネル名の色: 曲で使うチャンネル (ChUsed) は白、使わないチャンネルは灰
;  名前はバーの基準のマスの次のマス (0-4 ドット目) に 1 字ずつ入っている。y = 36-47 の色を書く
MtLabelColors:	ld	c, 0		; バー 0-11
.bar:		push	bc
		ld	hl, (ChUsed)	; bit c を見る
		ld	b, c
		inc	b
.sh:		srl	h
		rr	l
		djnz	.sh
		ld	a, COL_LABEL
		jr	nc, .col
		ld	a, COL_INFO
.col:		ld	(MtLblCol), a
		ld	a, c
		call	MtCol
		inc	a
		add	a, a
		add	a, a
		add	a, a
		ld	(MtLblX), a	; 名前のマス * 8
		ld	e, a		; 行4 (y = 32-39) の 4-7 ライン目
		ld	d, 4
		ld	hl, (GRPCOL)
		add	hl, de
		ld	de, 4
		add	hl, de
		ex	de, hl
		ld	b, 4
		call	.out
		ld	a, (MtLblX)	; 行5 (y = 40-47) の 8 ライン
		ld	e, a
		ld	d, 5
		ld	hl, (GRPCOL)
		add	hl, de
		ex	de, hl
		ld	b, 8
		call	.out
		pop	bc
		inc	c
		ld	a, c
		cp	12
		jr	c, .bar
		ret
.out:		di
		push	bc
		call	VdpSetW
		pop	af		; A = 数 (B)
		ld	b, a
		ld	a, (MtLblCol)
.o:		out	(c), a
		djnz	.o
		ei
		ret

; 曲 (SONG_RAM) の各チャンネルに音符があるか -> ChUsed (bit 0-2 = PSG A-C、bit 3-11 = FM 1-9)
CalcChUsed:	ld	hl, 0
		ld	(ChUsed), hl
		ld	de, 2		; ブロックの位置 (曲の先頭から)
		ld	b, 0		; チャンネル
.blk:		ld	hl, SONG_RAM
		add	hl, de
		ld	e, (hl)
		inc	hl
		ld	d, (hl)		; DE = 次のブロックの位置 (= このチャンネルの終わり)
		inc	hl		; HL = チャンネルのデータ
		ld	a, d
		or	e
		ret	z
		push	de
		push	bc
		call	ChHasNote
		pop	bc
		jr	z, .no
		push	bc
		ld	hl, 1		; ChUsed の bit b を立てる
		inc	b
		jr	.s2
.s1:		add	hl, hl
.s2:		djnz	.s1
		ld	de, (ChUsed)
		ld	a, l
		or	e
		ld	l, a
		ld	a, h
		or	d
		ld	h, a
		ld	(ChUsed), hl
		pop	bc
.no:		pop	de
		inc	b
		ld	a, b
		cp	12
		ret	nc
		ld	hl, SONG_RAM	; 次のブロックが 0000 なら終わり
		add	hl, de
		ld	a, (hl)
		inc	hl
		or	(hl)
		ret	z
		jr	.blk

; HL からのコマンド列 (DE = 終わりの位置、曲の先頭から) に音符 (01h-24h) があるか -> NZ = ある
;  B = チャンネル。PSG (0-2) では音色の命令 (42h-61h、FCh xx) もノイズを鳴らすので音符と同じに数える
ChHasNote:	ld	a, b
		cp	3
		sbc	a, a
		ld	c, a		; C = 0FFh なら PSG
		push	hl
		ld	hl, SONG_RAM
		add	hl, de
		ld	(ChEnd), hl
		pop	hl
.op:		push	hl
		ld	de, (ChEnd)
		or	a
		sbc	hl, de
		pop	hl
		jr	nc, .none
		ld	a, (hl)
		inc	hl
		or	a
		jr	z, .none	; チャンネルの終わり
		cp	25h
		jr	c, .yes		; 音符
		cp	0FAh
		jr	c, .p0		; パラメータなし
		cp	0FCh		; FCh: PSG ではノイズを鳴らす
		jr	nz, .notFC
		bit	0, c
		jr	nz, .yes
		jr	.one
.notFC:		cp	0FDh
		jr	z, .two
		cp	0FFh
		jr	nz, .one
		ld	a, (hl)		; FFh: 第1パラメータが 8, 9, 0Ch, 0Eh ならもう 1 バイト
		inc	hl
		cp	8
		jr	z, .one
		cp	9
		jr	z, .one
		cp	0Ch
		jr	z, .one
		cp	0Eh
		jr	z, .one
		jr	.op
.two:		inc	hl
.one:		inc	hl
		jr	.op
.p0:		bit	0, c		; PSG の 42h-61h はノイズを鳴らす
		jr	z, .op
		cp	42h
		jr	c, .op
		cp	62h
		jr	c, .yes
		jr	.op
.yes:		or	a		; NZ
		ret
.none:		xor	a		; Z
		ret

;-----------------------------------------------------------------------------
; 毎フレーム呼ぶ
UpdateMeters:	call	MtTargets
		; リズムモードが変わったらチャンネル番号を描き直す
		ld	a, (MtShdE)
		and	20h
		ld	hl, MtLabelMode
		cp	(hl)
		call	nz, DrawMeterLabels
		; 下げるのは MT_DECAY フレームに 1 回
		ld	hl, MtDecayCnt
		ld	a, (hl)
		or	a
		jr	z, .reload	; 0 になったフレームで下げる
		dec	(hl)
		xor	a
		jr	.dset
.reload:	ld	(hl), MT_DECAY-1
		ld	a, 1
.dset:		ld	(MtDecayNow), a
		; 表示レベルを更新して、変わったバーを描く
		ld	c, 0
.ch:		ld	b, 0
		ld	hl, MtTarget
		add	hl, bc
		ld	e, (hl)		; E = 今の音量 (鳴っていなければ 0)
		ld	hl, MtNoteOnF
		add	hl, bc
		ld	a, (hl)
		ld	(hl), 0
		ld	hl, MtDisp
		add	hl, bc
		ld	d, (hl)		; D = 今の表示
		or	a
		ld	a, e
		jr	nz, .set	; 発音したフレーム: 音量まで跳ね上がる
		ld	a, (MtDecayNow)	; それ以外: 下げるフレームなら 1 段下げる
		or	a
		ld	a, d
		jr	z, .floor
		or	a		; (0 未満にはしない)
		jr	z, .floor
		dec	a
.floor:		srl	e		; 鳴っている間は 音量/2 より下げない
		cp	e
		jr	nc, .set
		ld	a, e
.set:		cp	d
		jr	z, .next
		ld	(hl), a
		ld	e, a
		ld	b, d
		ld	a, c
		push	bc
		ld	c, e
		call	DrawBar
		pop	bc
.next:		inc	c
		ld	a, c
		cp	12
		jr	c, .ch
		ret

; チャンネルごとの今の音量 (0-15) を MtTarget に求める
MtTargets:	; PSG: R7 (0=有効) と R8-R10 (bit4=エンベロープ)
		di			; BIOS の割込みも PSG のレジスタを選ぶので止める
		ld	b, 7
		call	ReadPSG
		ld	(MtR7), a
		ld	hl, MtTarget
		ld	e, 09h		; ch0: トーン bit0 + ノイズ bit3
		ld	b, 8
.psg:		call	ReadPSG
		bit	4, a
		jr	z, .pv
		ld	a, 0Fh		; エンベロープ使用中は最大とみなす
.pv:		and	0Fh
		ld	d, a
		ld	a, (MtR7)
		and	e
		cp	e
		ld	a, d
		jr	nz, .pon	; トーンかノイズのどちらかが有効
		xor	a
.pon:		ld	(hl), a
		inc	hl
		sla	e
		inc	b
		ld	a, b
		cp	11
		jr	c, .psg
		ei
		; FM: ドライバのチャンネルのワーク (PSG 3 つの後ろ)
		ld	a, (LoadedDrv)
		inc	a
		jr	nz, .haveDrv
		ld	b, 9		; ドライバがまだない
.zero:		ld	(hl), a
		inc	hl
		djnz	.zero
		ret
.haveDrv:	push	hl
		ld	de, (DrvDesc+D_STRIDE)
		ld	hl, (DrvDesc+D_CHN)
		add	hl, de
		add	hl, de
		add	hl, de
		push	hl
		pop	ix
		ld	hl, (DrvDesc+D_SHDFME)
		ld	a, (hl)
		ld	(MtShdE), a
		ld	hl, (DrvDesc+D_FADECTL)
		ld	b, (hl)
		ld	hl, (DrvDesc+D_FADEPASS)
		ld	a, (hl)
		bit	7, b		; フェードアウト中か
		jr	nz, .f
		xor	a
.f:		ld	(MtFade), a
		pop	hl
		ld	c, 0		; FM ch0-8
.fm:		ld	a, (ix+0)	; 停止中のチャンネル
		or	a
		jr	z, .off
		call	MtIsRhy		; リズムモードの ch6-8 か
		jr	nz, .rhy
		bit	4, (ix+11)	; キーオン
		jr	z, .off
		jr	.on
.rhy:		push	hl
		ld	a, c
		sub	6
		ld	hl, MtRhyMask
		add	a, l
		ld	l, a
		jr	nc, .rm
		inc	h
.rm:		ld	a, (MtShdE)
		and	(hl)
		pop	hl
		jr	z, .off
.on:		ld	a, (ix+9)	; 減衰量 (0=最大)
		and	0Fh
		ld	b, a
		ld	a, (MtFade)
		add	a, b
		cp	10h
		jr	c, .lv
		ld	a, 0Fh
.lv:		ld	b, a
		ld	a, 0Fh
		sub	b
		jr	.st
.off:		xor	a
.st:		ld	(hl), a
		inc	hl
		add	ix, de
		inc	c
		ld	a, c
		cp	9
		jr	c, .fm
		ret

; バー A (0-11) を 表示レベル B から C に描き直す (変わったマスだけ)
DrawBar:	ld	(MtCh), a
		ld	a, c
		ld	(MtNewLv), a
		ld	a, b		; D = 低い方, E = 高い方
		cp	c
		ld	d, a
		ld	e, c
		jr	c, .ord
		ld	d, c
		ld	e, a
.ord:		; 変わる点灯行: y = MT_BOTTOM-2*高い方 から MT_BOTTOM-2-2*低い方
		ld	a, e
		add	a, a
		ld	e, a
		ld	a, MT_BOTTOM
		sub	e
		srl	a
		srl	a
		srl	a
		ld	(MtK), a	; 最初のマス行
		ld	a, d
		add	a, a
		ld	d, a
		ld	a, MT_BOTTOM-2
		sub	d
		srl	a
		srl	a
		srl	a
		ld	hl, MtK
		sub	(hl)
		inc	a
		ld	b, a		; マス行の数
.cell:		push	bc
		ld	a, (MtCh)
		call	MtCol
		ld	(MtX), a
		call	MtCell		; バーの左半分が入るマス
		ld	hl, MtX
		inc	(hl)
		call	MtCell		; 右半分が入るマス
		ld	hl, MtK
		inc	(hl)
		pop	bc
		djnz	.cell
		ret

; マス MtX のマス行 MtK の模様を作って VRAM へ (マス行 4 は上 4 バイトだけ)
; 左 3 ドット (E0h) = 基準のマスが 1 つ左のバーの右端、右 3 ドット (07h) = 基準のマスがここのバーの左端
MtCell:		ld	a, (MtX)
		dec	a
		call	MtBarOf
		call	MtThres
		ld	(MtThL), a
		ld	a, (MtX)
		call	MtBarOf
		call	MtThres
		ld	(MtThR), a
		ld	a, (MtK)
		add	a, a
		add	a, a
		add	a, a
		ld	(MtY), a	; このマスの先頭の y
		ld	e, a
		ld	d, 0
		ld	hl, MtTemplate
		add	hl, de
		ld	de, CellBuf
		ld	b, 8
.r:		ld	c, 0
		ld	a, (hl)		; 点灯する行か (1 ドットおき)
		or	a
		jr	z, .st
		push	hl
		ld	a, (MtY)
		ld	hl, MtThL
		cp	(hl)
		jr	c, .nl
		ld	c, 0F8h		; 左 5 ドット = 基準のマスが 1 つ左のバーの右側
.nl:		inc	hl		; MtThR
		cp	(hl)
		jr	c, .nr
		ld	a, c
		or	01h		; 右 1 ドット = 基準のマスがここのバーの左端
		ld	c, a
.nr:		pop	hl
.st:		ld	a, c
		ld	(de), a
		inc	hl
		inc	de
		ld	a, (MtY)
		inc	a
		ld	(MtY), a
		djnz	.r
		; 書く位置 = パターン表 + マス行*256 + マス*8
		ld	a, (MtX)
		add	a, a
		add	a, a
		add	a, a
		ld	e, a
		ld	a, (MtK)
		ld	d, a
		ld	hl, (GRPCGP)
		add	hl, de
		ex	de, hl
		ld	hl, CellBuf
		di
		call	VdpSetW
		ld	a, (MtK)
		cp	4
		ld	b, 8
		jr	c, .w
		ld	b, 4
.w:		xor	a
		ld	(WlConst), a
		call	WlOut
		ei
		ret

; 点灯する行 (y = 0-39。0 以外の行 y = 4, 6, ..., 32 が点灯できる)
MtTemplate:	db	0, 0, 0, 0
		dup	15
		db	07Eh, 0
		edup
		db	0, 0, 0, 0, 0, 0
; 1本分の色 (y = 0-39。上から赤 y<10、黄 y<16、緑)
MtColTab:	ds	10, 091h
		ds	6, 0B1h
		ds	24, 031h
MtRhyMask:	db	10h, 0Ch, 03h	; ch6=BD  ch7=SD/TOM  ch8=HH/CYM
; チャンネル名 (02h = 2 ドット進む。文字 6 ドット + 2 ドットで 8 ドットおき、最初は 6 ドット空ける)
MtLblHead:	db	2,2,2,2,"A",2,"B",2,"C",2," ",2,"1",2,"2",2,"3",2,"4",2,"5",2,"6",2,0
MtLblFM:	db	"7",2,"8",2,"9",0
MtLblRhy:	db	"B",2,"S",2,"H",0

;=============================================================================
; 音源の読み書き
; FM 音源 (OPLL): B=レジスタ, A=値。turboR も Z80 モードで動かすので、書いた後に 84 クロック以上待つ
WriteFM:	push	af
		ld	a, b
		out	(7Ch), a
		pop	af
		out	(7Dh), a
		push	af
		ex	(sp), hl
		ex	(sp), hl
		ex	(sp), hl
		ex	(sp), hl
		pop	af
		ret
; PSG: B=レジスタ, A=値
WritePSG:	push	af
		ld	a, b
		out	(0A0h), a
		pop	af
		out	(0A1h), a
		ret
; PSG: B=レジスタ -> A
ReadPSG:	ld	a, b
		out	(0A0h), a
		in	a, (0A2h)
		ret

; FM 音源を探す (RDSLT/WRSLT で全スロットを見る)
;  FMType: 0=なし 1=内蔵 MSX-MUSIC 2=FM-PAC など (7FF6h の bit0 で I/O を有効にした)
FMSearch:	xor	a
		ld	(FMType), a
.loop:		ld	(FMSIdx), a	; サブスロット*4 + 基本スロット
		ld	b, a
		and	3
		ld	c, a
		ld	e, a
		ld	d, 0
		ld	hl, EXPTBL
		add	hl, de
		ld	a, (hl)
		and	80h
		jr	nz, .exp
		ld	a, b
		and	0Ch
		jr	nz, .next	; 拡張されていない基本スロットはサブ 0 だけ
		ld	a, c
		jr	.chk
.exp:		ld	a, b
		and	0Ch
		or	80h
		or	c
.chk:		ld	(FMSlot), a
		ld	hl, 401Ch
		ld	de, FMStrOPLL
		call	.cmp4
		jr	nz, .next
		ld	hl, 4018h
		ld	de, FMStrAPRL
		call	.cmp4
		ld	a, 1
		jr	z, .found	; "APRL" = 内蔵 MSX-MUSIC
		ld	a, (FMSlot)	; FM-PAC: 7FF6h の bit0 で I/O ポートを有効にする
		ld	hl, 7FF6h
		call	RDSLT
		or	1
		ld	e, a
		ld	a, (FMSlot)
		ld	hl, 7FF6h
		call	WRSLT
		ld	a, 2
.found:		ld	(FMType), a
		ei
		ret
.next:		ld	a, (FMSIdx)
		inc	a
		cp	16
		jr	c, .loop
		ei
		ret
; スロット FMSlot の HL から 4 バイトを DE の文字列と比べる (一致で Z)
.cmp4:		ld	b, 4
.cl:		push	bc
		push	de
		push	hl
		ld	a, (FMSlot)
		call	RDSLT
		pop	hl
		pop	de
		pop	bc
		ex	de, hl
		cp	(hl)
		ex	de, hl
		ret	nz
		inc	hl
		inc	de
		djnz	.cl
		ret
FMStrOPLL:	db	"OPLL"
FMStrAPRL:	db	"APRL"

;=============================================================================
; ゲームのドライバ (build_rom.py が書き込む): DRV_DESC バイト x DRV_MAX (D_* を参照)
DrvDir:		ds	DRV_DESC*DRV_MAX, 0
; ドライバと表の組 (build_rom.py が書き込む): ドライバの番号, 表のバンク, 表のバンク内アドレス (2) x SET_MAX
SetDir:		ds	4*SET_MAX, 0

;=============================================================================
; プレイリスト表 (build_rom.py が書き込む)
;   +0 曲数 (2バイト) / +2 から ENTRY_SIZE バイト x 曲数
		align	2
PlaylistTable:	ds	PL_ENTRIES, 0
CodeEnd:

		outend

;=============================================================================
; RAM (ページ3)
		org	0C000h
RAM_START:

; ---- 音源・ドライバ ----
FMType:		ds	1
FMSlot:		ds	1
FMSIdx:		ds	1
LoopCnt:	ds	12		; チャンネルごとの無限ループ折り返し回数
DrvDesc:	ds	DRV_DESC	; 今のドライバ (DrvDir から写す)
DrvJpCmd:	ds	3		; jp ドライバのコマンド (ドライバがなければ ret)
DrvJpInt:	ds	3		; jp ドライバの割込み処理 (ドライバがなければ ret)
LoadedDrv:	ds	1		; RAM にあるドライバの番号 (0FFh = なし)

; ---- プレーヤー ----
FPS:		ds	1
PalCnt:		ds	1
SkipSilence:	ds	1		; 1 = 次の PlayEntry で Silence を呼ばない (前の曲が終わって次へ進む)		; PAL: ドライバをもう一度動かすまでの割込みの数
CurIdx:		ds	2
CurEntry:	ds	ENTRY_SIZE
RhyMode:	ds	1		; Silence で 0Eh に書くリズムモード
Silenced:	ds	1		; 1 = 演奏開始後に Silence 済み
ChnStride:	ds	2
RamCopy:	ds	16		; RamCopyImg をここに写す
RamHooks:	ds	180		; RamHooksImg をここに写す
RamSlotId:	ds	1		; ページ3の RAM のスロット (ENASLT の形)
P1RomA8:	ds	1		; ページ1がこの ROM のときの A8h
P1RamA8:	ds	1		; ページ1が RAM のときの A8h
P1Exp:		ds	1		; 0 以外 = RAM の基本スロットは拡張されている
P1SubRom:	ds	1		; そのときの FFFFh (ページ1が ROM のとき)
P1SubRam:	ds	1		; 〃 (ページ1が RAM のとき)
P1Ok:		ds	1		; 1 = ページ1に RAM がある
P1CmdJp:	ds	3		; jp ページ1のドライバのコマンド
P1IntJp:	ds	3		; jp ページ1のドライバの割込み処理
CgDec:		ds	96		; CgDecImg をここに写す
MapChk:		ds	40		; MapChkImg をここに写す (起動の最初だけ)
Fading:		ds	1
FrameCnt:	ds	1
Seconds:	ds	2
LastMinLoop:	ds	1
KeyPrev:	ds	1
ListRow:	ds	1
ListColor:	ds	1
ListMax:	ds	2		; リストの先頭にできる最大の曲番号
ListTop:	ds	2		; リストの先頭の曲
OldSel:		ds	2
SelIdx:		ds	2		; 選択中の曲
ViewStart:	ds	2		; 選んでいるゲームの最初と最後の曲
ViewEnd:	ds	2
GkCur:		ds	2
Playing:	ds	1		; 1 = 再生中
StopAfter:	ds	1		; 1 = フェードが終わったら止める (SPACE)
KeyShift:	ds	1
KeyRep:		ds	1
KeyHit:		ds	1		; 割込みで見つけた、新しく押されたキー (K_*)
KeyBlock:	ds	1		; 離すまで無視するキー (起動時に押していたもの)
KeyHPrev:	ds	1		; H キー: 前回押されていたか (20h)
KeyHHit:	ds	1		; H キー: 新しく押された
HelpPage:	ds	1		; ヘルプ: 0 = 表示していない、1 / 2 = ページ
HelpAny:	ds	1		; ヘルプ: 前回押されていたキー (AnyKey)
HelpRow:	ds	1
HelpIdx:	ds	1
IntOn:		ds	1		; 1 = 割込みでドライバを動かす
FadeDone:	ds	1		; 1 = フェードが最小音量まで進んだ (割込みが立てる)
Ticks:		ds	1		; 割込みで数えた、まだ時間に足していないフレーム数
OldTimi:	ds	5		; 元の H.TIMI
TitleBuf:	ds	TITLE_BUF+1
LangEn:		ds	1		; 1 = 英語で表示
MsxVer:		ds	1		; 0=MSX1 1=MSX2 2=MSX2+ 3=turboR
IsStartup:	ds	1		; 1 = 起動時の曲を鳴らしている
AutoWait:	ds	1		; 自動再生: 起動時の曲がないとき CG を見せたフレーム数
ViewMode:	ds	1		; VIEW_LIST / VIEW_CG / VIEW_TITLE
PlayMode:	ds	1		; 0=ALL 1=GAME 2=ONE
RepeatOff:	ds	1		; 0=REPEAT 1=ONCE
CgShowSel:	ds	1		; 1 = CG の最下行に選択中の曲を出す
CgCur:		ds	4		; 表示中の CG (バンク, 画面モード, 文字色, 背景色)
AnyPrev:	ds	1
GsCell0:	ds	1		; DrawGameSel: 中央の範囲 (マス)
GsCellN:	ds	1
GsPrev:		ds	2		; 前後のゲームの情報 (0=なし)
GsNext:		ds	2
CgPtr:		ds	2
CgBank:		ds	1
CgLeft:		ds	2
HasExtVdp:	ds	1		; CG を出す外の VDP: 0 = なし、1 = V9990、2 = V9968 (I/O 88h)
V9Cur:		ds	4		; V9990 / V9968 に出している CG (バンク 0 = なし)
V9IL:		ds	1		; 1 = V9990 / V9968 の CG はインターレース
V9Y:		ds	2		; V9990 にインターレースの CG を送るときの次のライン
CgIL:		ds	1		; 1 = 内蔵 VDP の CG はインターレース
BmpPage:	ds	1		; BmpWrite1 で書くページ (R#14 の上位: 0 / 4)
CgTbl4:		ds	4		; 最下行: SCREEN 5 の 2 ドット分の値
CgTbl2:		ds	2		; SCREEN 8 の背景色・文字色

; ---- 文字描画 ----
RlLine:		ds	1
RlColor:	ds	1
RlFlags:	ds	1
RlX:		ds	1		; 次の文字の x (4 ドット単位)
RlXMax:		ds	1		; 描ける範囲の右端 (4 ドット単位)
RlCell0:	ds	1		; 描くマスの範囲
RlCellN:	ds	1
WlOff:		ds	1		; 行の y の 8 の余り (0 / 4)
WlRow:		ds	1		; 行の先頭のマス行
WlConst:	ds	1
WlBase:		ds	2
WlSrc:		ds	1
WlCRow:		ds	1
WlBOff:		ds	1
BlitShift:	ds	1
TxPtr:		ds	2
GlyphBuf:	ds	12
TextBuf:	ds	160
LineBuf:	ds	512		; 1行分の字形 (マスごとに 16 バイト x 32 マス)

; ---- レベルメーター ----
MtTarget:	ds	12		; 今の音量 (0-15。鳴っていなければ 0)
MtNoteOnF:	ds	12		; 1 = このフレームで発音した
MtDisp:		ds	12		; 表示中のレベル
MtR7:		ds	1
MtShdE:		ds	1		; FM 0Eh の写し (リズムモードとキー)
MtFade:		ds	1		; フェードの段数 (フェード中でなければ 0)
MtLabelMode:	ds	1		; チャンネル名を描いたときのリズムモード
ChUsed:		ds	2		; 曲で使うチャンネル (bit 0-11)
ChEnd:		ds	2		; ChHasNote: チャンネルの終わり
MtLblCol:	ds	1		; MtLabelColors: 色
MtLblX:		ds	1		; MtLabelColors: 名前のマス * 8
MtCh:		ds	1
MtNewLv:	ds	1
MtK:		ds	1
MtY:		ds	1
MtX:		ds	1		; 描くマス
MtThL:		ds	1		; MtCell: 左のバーのしきい値
MtThR:		ds	1		;         右のバーのしきい値 (MtThL の次に置く)
MtDecayCnt:	ds	1
MtDecayNow:	ds	1
CellBuf:	ds	8

RAM_END:
		assert	RAM_END < STACK_TOP-200h	; その上 CCC0h まではスタック
		assert	RAMCOPY_SIZE <= 16
		assert	MAPCHK_SIZE <= 40
		assert	RAMHOOKS_SIZE <= 180
		assert	CGDEC_SIZE <= 96
