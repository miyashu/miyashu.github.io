"""標準の CG (default_cg.png) を描く: 起動時の CG を指定しないときなどに表示する (SCREEN 5、256x212、16 色)
ゲームの画面は使わず、k6x8 フォントの英数字を拡大した文字とレベルメーター風の模様だけで描く

使い方 (player フォルダで): python make_default_cg.py
"""
import os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = os.path.join(HERE, '..', 'font', 'k6x8', 'k6x8_gothic_jisx0208.png')
OUT = os.path.join(HERE, 'default_cg.png')
W, H = 256, 212


def c3(r, g, b):
    """MSX2 の 3 ビットの色 -> RGB"""
    return (r * 255 // 7, g * 255 // 7, b * 255 // 7)


BG1, BG2, BG3 = c3(0, 0, 1), c3(0, 0, 2), c3(1, 0, 3)
YELLOW, ORANGE, WHITE, GRAY = c3(7, 6, 1), c3(6, 2, 0), c3(7, 7, 7), c3(4, 4, 5)
GREEN, LGREEN, RED, CYAN = c3(1, 6, 1), c3(4, 7, 2), c3(7, 1, 1), c3(3, 6, 7)
DARK = c3(0, 0, 0)


class Font:
    def __init__(self):
        self.img = Image.open(FONT).convert('L')

    def glyph(self, ch):
        """1 文字 (英数字・記号) -> 8 行 x 6 ドットの 0/1"""
        if ch == ' ':
            return [[0] * 6 for _ in range(8)]
        e = chr(ord(ch) + 0xFEE0).encode('euc_jp') if ch != '©' else '©'.encode('euc_jp', 'replace')
        ku, ten = e[0] - 0xA0, e[1] - 0xA0
        return [[1 if self.img.getpixel(((ten - 1) * 6 + i, (ku - 1) * 8 + j)) < 128 else 0
                 for i in range(6)] for j in range(8)]

    def text(self, im, x, y, s, color, sx=1, sy=1, shadow=None):
        px = im.load()
        for k, ch in enumerate(s):
            g = self.glyph(ch)
            for j in range(8):
                for i in range(6):
                    if not g[j][i]:
                        continue
                    for dy in range(sy):
                        for dx in range(sx):
                            X, Y = x + (k * 6 + i) * sx + dx, y + j * sy + dy
                            if shadow and 0 <= X + sx < W and 0 <= Y + sy < H:
                                px[X + sx, Y + sy] = shadow
                            if 0 <= X < W and 0 <= Y < H:
                                px[X, Y] = color
        return len(s) * 6 * sx

    def center(self, im, y, s, color, sx=1, sy=1, shadow=None):
        self.text(im, (W - len(s) * 6 * sx) // 2, y, s, color, sx, sy, shadow)


def main():
    im = Image.new('RGB', (W, H), BG1)
    px = im.load()
    # 背景: 下へ行くほど明るい紺から紫 (1 行おきに混ぜる)
    for y in range(H):
        band = y * 3 // H
        for x in range(W):
            if band == 0:
                c = BG1
            elif band == 1:
                c = BG2 if (x + y) % 2 == 0 else BG1
            else:
                c = BG3 if (x + y) % 2 == 0 else BG2
            px[x, y] = c
    f = Font()
    # 題名 (影付き)。shadow の上に本体を描くため 2 回に分ける
    f.center(im, 18, 'MICRO CABIN', ORANGE, 3, 3)
    f.text(im, (W - 11 * 18) // 2 - 2, 16, 'MICRO CABIN', YELLOW, 3, 3)
    f.center(im, 52, 'MUSIC PLAYER', WHITE, 2, 2)
    # レベルメーター風の模様
    heights = [7, 11, 9, 5, 12, 14, 10, 13, 8, 11, 6, 9]
    x0 = (W - 12 * 16) // 2 + 3
    base = 150
    for k, h in enumerate(heights):
        for j in range(h):
            y = base - j * 5
            col = RED if j >= 11 else (YELLOW if j >= 8 else (LGREEN if j >= 4 else GREEN))
            for yy in range(y - 3, y):
                for xx in range(x0 + k * 16, x0 + k * 16 + 10):
                    px[xx, yy] = col
    for xx in range(x0 - 4, x0 + 12 * 16 - 2):         # 床の線
        px[xx, base + 2] = CYAN
    f.center(im, 166, 'PRESS ANY KEY', WHITE)
    f.center(im, 188, 'MUSIC (C) MICRO CABIN CORP.', GRAY)
    im.save(OUT)
    colors = {px[x, y] for y in range(H) for x in range(W)}
    print(f'{OUT}: {W}x{H}, {len(colors)} 色')


if __name__ == '__main__':
    main()
