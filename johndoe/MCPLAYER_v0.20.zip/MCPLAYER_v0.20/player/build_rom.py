#!/usr/bin/env python3
"""MICRO CABIN MUSIC PLAYER - メガロム(ASCII16) ビルダー

使い方:
  python build_rom.py                     # playlist.txt から MCPLAYER.ROM を作る
  python build_rom.py my_list.txt -o x.rom
  python build_rom.py --make-playlist ../data > playlist.txt   # 全曲リストを作る

プレイリストの書式 (1行1曲、# 以降はコメント):
  曲ファイルのパス | 曲名 | ループ回数 | ドライバ | 英語の曲名
  - パスはプレイリストファイルからの相対パス
  - 曲名を省略すると "ゲーム名 Track 番号" (ゲーム内の順番) になる
  - 英語の曲名は、本体の文字セットが日本以外のときに表示する (省略すると日本語の曲名)
  - "@game ゲーム名 | 英語のゲーム名" の行で、それ以降の曲のゲーム名を指定する
  - "@cg 画像" の行で、そのゲームの CG (V キーで表示。MSX2 以降) を指定する
  - "@startup 曲ファイル | 曲名 | 英語の曲名" で起動時に鳴らす曲 (曲のリストには出ない)
  - "@startup_cg 画像" で起動時に表示する CG (MSX2 以降)
  - 画像: PNG など (256x212。16色以下なら SCREEN 5、それ以上なら SCREEN 8 に変換) か、
          BSAVE 形式の .SC5 / .SC8 (openMSX の save_msx_screen などで保存したもの)
  - 曲名・ゲーム名には英数字・記号・かな・漢字 (JIS 第一・第二水準) が使える
    表示は漢字・かなが k8x12 (8x12)、英数字が k6x8 (6x12 の行に 6x8)。1行は 256 ドット (半角約42文字・全角32文字)
  - ループ回数を省略すると --loops の値 (既定 2)
    0 にすると、曲が自然に終わるか最大演奏時間までループさせ続ける
  - ドライバの欄は使わない (昔の書式との互換のため読み飛ばす)

ドライバと表:
  曲は、その曲を取ったゲームのドライバ (サウンドドライバ) と表 (音色など) で鳴らす。
  どちらも --disks のフォルダ (既定 ../disk_image) の、曲のフォルダと同じ名前のフォルダにある
  ディスクイメージから取り出す。ドライバは drivers.json に載っている版だけを使う
  (番地などの情報と、版を見分ける md5。ドライバのコードそのものはディスクイメージから取る)
"""
import argparse
import hashlib
import json
import struct
import os
import re
import shutil
import subprocess
import unicodedata
import cgrle
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BANK_SIZE = 0x4000
PAGE2 = 0x8000
MAX_CHANNELS = 12
TITLE_BYTES = 70                  # 曲名の最大バイト数 (player.asm の TITLE_BYTES と合わせる)
LINE_UNITS = 128                  # 1行の幅 (2 ドット単位。半角 = 3、全角 = 4)
GLYPH_SIZE = 16                   # 全角フォント 1字のバイト数 (12 + 余白)
GLYPHS_PER_BANK = BANK_SIZE // GLYPH_SIZE
FONT_DIR = os.path.join(HERE, '..', 'font', 'misaki_12x8')
FONT_FULL = 'k8x12_jisx0208.png'     # 漢字・かな (8x12)
FONT6_DIR = os.path.join(HERE, '..', 'font', 'k6x8')
FONT_HALF6 = 'k6x8_gothic_jisx0208.png'  # 英数字 (k6x8 の全角の英数字 6x8 を半角として使う)
HALF_DY = 2                            # 英数字を 12 ドットの行の何ドット目から置くか
# 全角の字がない ASCII は似た字で代用する
HALF_SUBST = {'"': '”', "'": '’', '-': '−', '~': '〜'}
ENTRY_SIZE = 12
TABLE_HEADER = 24                 # 曲数, 設定, (使っていない 4), 全角フォント, 起動時の曲 (12), 起動時の CG (4)
SC5_BYTES = 128 * 212
SC8_BYTES = 256 * 212
SC7_BYTES = 256 * 212             # 512x212 ドット、1 バイト 2 ドット
SONG_MAX = 0x2000                 # 曲データを置く RAM (A000h-BFFFh)

# ゲームのドライバ (drivers.json: ディスク上のドライバの先頭 600h バイトの md5 -> 番地などの情報)
DRIVERS_JSON = os.path.join(HERE, 'drivers.json')
DRV_SIG = re.compile(rb'\xc3..\xf3\xdd\xe5\xe5\xd5\xc5\xfe', re.S)   # jp 割込み処理 / コマンドの入口
DRV_MAX = 12                      # player.asm の DRV_MAX と合わせる
DRV_DESC = 40                     # player.asm の DRV_DESC と合わせる
SET_MAX = 32                      # player.asm の SET_MAX と合わせる
DRV_RAM_END = 0xDE00              # player.asm の DRV_END と合わせる
STACK_TOP = 0xCCC0                # player.asm の STACK_TOP と合わせる
TBL_LEN = 0x1E0                   # 表の長さ (エンベロープ 30h + ビブラート 30h + エフェクト 80h + 音色 100h)
# 曲のフォルダのディスクにドライバがないとき、代わりにドライバを探すフォルダ
DRV_FALLBACK = {'FFANTASY': ['XAK', 'XAKII', 'GAZZEL', 'FRAY_M2', 'ILLUSION']}
# ヘルプ (H キー) の文: 1 行は半角 39 字まで (全角は半角 4/3 字分)。各ページ 5 行
HELP_PAGES = (
    [' MICRO CABIN MUSIC PLAYER    Ver 0.20',
     ' Driver disassembly: Roberto Vargas',
     ' Thanks: Manuel Pazos, Patriek Lesparre',
     ' All music (C) MICRO CABIN Corp.',
     ' Thank you for the wonderful music!'],
    [' ↑↓: Select track (SHIFT: +10)',
     ' ←→: Select game',
     ' SPACE: Play / Stop    V: CG view',
     ' E: Range (ALL / GAME / ONE)',
     ' R: Repeat (REPEAT / ONCE)'],
)
DEFAULT_CG = os.path.join(HERE, 'default_cg.png')   # 起動時の CG を指定しないときの CG (make_default_cg.py で描く)
SONG_CG_MAX = 24                  # player.asm の SONG_CG_MAX と合わせる
HELP_TEXT_SIZE = 460              # player.asm の HelpText の大きさ
# ゲームの表 (エンベロープ 30h + ビブラート 30h + エフェクト 80h + FM 音色 100h)。FM 音色の表の先頭 (1 番目の音色) で探す
INST_SIG = re.compile(re.escape(bytes.fromhex('5161')) + rb'[\x10-\x1f]' + re.escape(bytes.fromhex('0750f15cdc')))


# ---------------------------------------------------------------------------
# 曲データ
def load_song(path):
    """MCM ファイルを読み、ROM に置くバイト列を返す (BSAVE ヘッダは除く)"""
    raw = open(path, 'rb').read()
    if len(raw) >= 7 and raw[0] == 0xFE:
        start = raw[1] | raw[2] << 8
        end = raw[3] | raw[4] << 8
        body = raw[7:7 + (end - start + 1)]
    else:
        body = raw
    return body


def check_song(body):
    """チャンネル表をたどって (チャンネル数, 空の曲か) を返す。壊れていれば ValueError"""
    if len(body) < 6:
        raise ValueError('ファイルが短すぎます')
    p = 2
    chans = []
    while True:
        chans.append(p + 2)
        off = body[p] | body[p + 1] << 8
        if off + 2 > len(body):
            raise ValueError('チャンネル表がファイルの外を指しています (MCM ではない?)')
        if (body[off] | body[off + 1] << 8) == 0:
            break
        p = off
        if len(chans) > 64:
            raise ValueError('チャンネル表が長すぎます')
    used = chans[:MAX_CHANNELS]
    empty = all(c >= len(body) or body[c] == 0 for c in used)
    return len(chans), empty


def channel_starts(body):
    """各チャンネルのデータ開始位置 (先頭12チャンネル分)"""
    p = 2
    starts = []
    while len(starts) < MAX_CHANNELS:
        starts.append(p + 2)
        off = body[p] | body[p + 1] << 8
        if off + 2 > len(body) or (body[off] | body[off + 1] << 8) == 0:
            break
        p = off
    return starts


# パラメータ付きオペコードのバイト数
# FFh は第1パラメータが 8,9 (共通) / 0Ch,0Eh (ドライバBの追加分) ならさらに1バイト
OP_PAR_EXTRA = (0x08, 0x09, 0x0C, 0x0E)
OP_PARAMS = {0xFA: 1, 0xFB: 1, 0xFC: 1, 0xFD: 2, 0xFE: 1, 0xFF: 1}


def strip_silent_loops(body):
    """音を出さない無限ループ (休符だけを繰り返すなど) をチャンネルの終わり (00h) に置き換える
    ゲームでは効果音的な曲 (Xak の GET アイテムなど) が鳴り終わった後に無音で待つのに使われているが、
    プレーヤーではループする曲と見分けられなくなるので、その場所で終わらせる。戻り: (曲, 置き換えた数)"""
    out = bytearray(body)
    count = 0
    for ch, s in enumerate(channel_starts(body)):
        p = s
        stack = []                       # [(ループの最初の位置, 無限か, 音を出したか)]
        while p < len(out) and out[p] != 0:
            op = out[p]
            n = OP_PARAMS.get(op, 0)
            if op == 0xFF and p + 1 < len(out) and out[p + 1] in OP_PAR_EXTRA:
                n = 2
            sound = 1 <= op <= 0x24 or (ch < 3 and (0x42 <= op <= 0x61 or op == 0xFC))
            if sound:
                for e in stack:
                    e[2] = True
            if 0x62 <= op <= 0x71 or op == 0xFB:
                inf = op == 0x62 or (op == 0xFB and out[p + 1] == 0)
                stack.append([p, inf, False])
            elif op == 0x72 and stack:
                start, inf, snd = stack.pop()
                if inf and not snd:
                    out[start] = 0               # ここでチャンネルを終わらせる
                    count += 1
                    break
            p += 1 + n
    return bytes(out), count


def song_loops(body):
    """曲がループするか (どれかのチャンネルに無限ループ = 回数 0 のループ (62h / FBh 00) がある)"""
    for s in channel_starts(body):
        p = s
        while p < len(body) and body[p] != 0:
            op = body[p]
            if op == 0x62 or (op == 0xFB and p + 1 < len(body) and body[p + 1] == 0):
                return True
            n = OP_PARAMS.get(op, 0)
            if op == 0xFF and p + 1 < len(body) and body[p + 1] in OP_PAR_EXTRA:
                n = 2
            p += 1 + n
    return False


def uses_fm(body):
    """FMチャンネル (4ch目以降) に音符 (01h-24h) があれば True"""
    for start in channel_starts(body)[3:]:
        p = start
        while p < len(body):
            op = body[p]
            if op == 0:
                break
            if op <= 0x24:
                return True
            n = OP_PARAMS.get(op, 0)
            if op == 0xFF and p + 1 < len(body) and body[p + 1] in OP_PAR_EXTRA:
                n = 2
            p += 1 + n
    return False


class Font:
    """フォント (PNG) から字形を取り出し、文字列を ROM 用の形式にする
    漢字・かなは k8x12 (8x12)、英数字は k6x8 の全角の英数字 (6x8) を 12 ドットの行の 2 ドット目から置く

    文字列の形式 (player.asm の RenderLine が読む):
      20h-7Eh     半角文字
      80h以上 x2  全角文字。番号 = (1バイト目 & 7Fh) * 128 + (2バイト目 & 7Fh)
      00h         終わり
    """

    def __init__(self, font_dir, font6_dir=FONT6_DIR):
        from PIL import Image
        full = os.path.join(font_dir, FONT_FULL)
        half = os.path.join(font6_dir, FONT_HALF6)
        for f in (full, half):
            if not os.path.isfile(f):
                sys.exit(f'フォントがありません: {f}  (--font-dir で指定してください)')
        self.full = Image.open(full).convert('L')
        self.half = Image.open(half).convert('L')
        self.glyph_index = {}      # 文字 -> 番号
        self.glyphs = []           # 番号 -> 12 バイト

    def _rows(self, img, x, y, w):
        rows = []
        for j in range(12):
            v = 0
            for i in range(w):
                if img.getpixel((x + i, y + j)) < 128:   # 黒が字
                    v |= 0x80 >> i
            rows.append(v)
        return bytes(rows)

    def half_font(self):
        """半角 20h-7Eh の字形 (1字 12 バイト、上位 6 ビット)。k6x8 の全角の英数字 (6x8) を使う"""
        out = bytearray()
        for c in range(0x20, 0x7F):
            rows = bytearray(12)
            if c != 0x20:
                ch = HALF_SUBST.get(chr(c), chr(c + 0xFEE0))
                e = ch.encode('euc_jp')
                ku, ten = e[0] - 0xA0, e[1] - 0xA0
                for j in range(8):
                    v = 0
                    for i in range(6):
                        if self.half.getpixel(((ten - 1) * 6 + i, (ku - 1) * 8 + j)) < 128:
                            v |= 0x80 >> i
                    rows[HALF_DY + j] = v
            out += rows
        return bytes(out)

    def _full_glyph(self, ch):
        try:
            e = ch.encode('euc_jp')
        except UnicodeEncodeError:
            return None
        if len(e) != 2 or not (0xA1 <= e[0] <= 0xFE and 0xA1 <= e[1] <= 0xFE):
            return None            # JIS X0208 にない文字
        ku, ten = e[0] - 0xA0, e[1] - 0xA0
        return self._rows(self.full, (ten - 1) * 8, (ku - 1) * 12, 8)

    def encode(self, text, warn=None):
        """表示用の文字列にする。表せない文字は '?' にして warn に記録"""
        text = unicodedata.normalize('NFKC', text)   # 全角英数 -> 半角、半角カナ -> 全角
        out = bytearray()
        units = 0
        for ch in text:
            o = ord(ch)
            if 0x20 <= o < 0x7F:
                code, w = bytes([o]), 3
            else:
                if ch not in self.glyph_index:
                    g = self._full_glyph(ch)
                    if g is None:
                        if warn is not None:
                            warn.append(ch)
                        code, w = b'?', 3
                        if units + w > LINE_UNITS:
                            break
                        out += code
                        units += w
                        continue
                    self.glyph_index[ch] = len(self.glyphs)
                    self.glyphs.append(g)
                n = self.glyph_index[ch]
                code, w = bytes([0x80 | (n >> 7), 0x80 | (n & 0x7F)]), 4
            if units + w > LINE_UNITS or len(out) + len(code) > TITLE_BYTES:
                break
            out += code
            units += w
        return bytes(out)


# ---------------------------------------------------------------------------
# プレイリスト
def parse_playlist(path, default_loops):
    """プレイリストを読む。戻り: (曲のリスト, ゲームの情報, 起動時の設定)
    曲: dict(song, title, title_en, loops, drv, game, where)
    ゲーム: {ゲーム名: dict(en, cg)}   起動時: dict(song, title, title_en, cg) (なければ値が None)"""
    base = os.path.dirname(os.path.abspath(path))
    entries = []
    games = {}
    startup = dict(song=None, title='', title_en='', cg=None)
    game = ''
    track = 0

    def fpath(rel, lineno):
        f = os.path.normpath(os.path.join(base, rel))
        if not os.path.isfile(f):
            sys.exit(f'{path}:{lineno}: ファイルがありません: {f}')
        return f

    with open(path, encoding='utf-8-sig') as f:
        for lineno, line in enumerate(f, 1):
            line = line.split('#', 1)[0].strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split('|')]
            low = parts[0].lower()
            if low.startswith('@game'):
                game = parts[0][5:].strip()
                games.setdefault(game, dict(en='', cg=None))
                if len(parts) > 1 and parts[1]:
                    games[game]['en'] = parts[1]
                track = 0
                continue
            if low.startswith('@startup_cg'):
                startup['cg'] = fpath(parts[0][11:].strip(), lineno)
                continue
            if low.startswith('@startup'):
                startup['song'] = fpath(parts[0][8:].strip(), lineno)
                startup['title'] = parts[1] if len(parts) > 1 else ''
                startup['title_en'] = parts[2] if len(parts) > 2 else ''
                continue
            if low.startswith('@song_cg'):
                if not entries:
                    sys.exit(f'{path}:{lineno}: @song_cg は曲の行の後に書いてください')
                entries[-1]['song_cg'] = fpath(parts[0][8:].strip(), lineno)
                continue
            if low.startswith('@cg'):
                if not game:
                    sys.exit(f'{path}:{lineno}: @cg は @game の後に書いてください')
                games[game]['cg'] = fpath(parts[0][3:].strip(), lineno)
                continue
            if low.startswith('@'):
                sys.exit(f'{path}:{lineno}: 知らない指定です: {parts[0]}')
            track += 1
            song = fpath(parts[0], lineno)
            title = parts[1] if len(parts) > 1 and parts[1] else None
            loops = None
            if len(parts) > 2 and parts[2]:
                loops = int(parts[2])
                if not 0 <= loops <= 255:
                    sys.exit(f'{path}:{lineno}: ループ回数は 0-255 です')
            drv = None
            if len(parts) > 3 and parts[3]:
                if parts[3].upper() not in ('A', 'B'):
                    sys.exit(f'{path}:{lineno}: ドライバは A か B です')
                drv = 1 if parts[3].upper() == 'B' else 0
            title_en = parts[4] if len(parts) > 4 and parts[4] else None
            entries.append(dict(song=song, title=title, title_en=title_en, loops=loops, drv=drv,
                                game=game, track=track, where=f'{path}:{lineno}'))
    return entries, games, startup


def fill_from_db(entries, games, startup, db_path, default_loops):
    """プレイリストに書いていない曲名・英語の曲名・ループ回数・ドライバ・英語のゲーム名を
    データベース (tools/mcm_db.csv) から補う。曲は中身 (MD5) で探し、@game と同じゲームの行を優先する"""
    rows = []
    if db_path and os.path.isfile(db_path):
        sys.path.insert(0, os.path.join(HERE, '..', 'tools'))
        import mcm_db
        rows = mcm_db.load_db(db_path)
    by_md5 = {}
    for r in rows:
        by_md5.setdefault(r['md5'], []).append(r)
    game_en = {}
    for r in rows:
        if r['game_en']:
            game_en.setdefault(r['game'], r['game_en'])

    def find(song, game):
        import mcm
        s = mcm.load(song)
        cands = by_md5.get(s.md5, []) if s else []
        return next((r for r in cands if r['game'] == game), cands[0] if cands else None)

    unknown = []
    for e in entries:
        r = find(e['song'], e['game'])
        if r is None and e['title'] is None:
            unknown.append(e)
        if e['title'] is None:
            e['title'] = (r['title'] if r and r['title'] else
                          (f"{e['game']} Track {e['track']:02d}" if e['game'] else f"Track {e['track']:02d}"))
        if e['title_en'] is None:
            e['title_en'] = r['title_en'] if r else ''
        if e['loops'] is None:
            e['loops'] = int(r['loops']) if r and r['loops'] else default_loops
        if e['drv'] is None:
            e['drv'] = 1 if r and r['drv'].upper() == 'B' else 0
    for g, gi in games.items():
        if not gi['en']:
            gi['en'] = game_en.get(g, '')
    if startup['song'] and not startup['title']:
        r = find(startup['song'], None)
        if r:
            startup['title'], startup['title_en'] = r['title'], r['title_en']
    return unknown


# ---------------------------------------------------------------------------
# CG (MSX2 の SCREEN 5 / SCREEN 8 の画像)
def load_cg(path):
    """画像 -> (画面モード, VRAM に送るデータ, 文字色, 背景色)
    SCREEN 5 のデータは 27136 バイト + パレット 32 バイト、SCREEN 8 は 54272 バイト"""
    ext = os.path.splitext(path)[1].upper()
    raw = open(path, 'rb').read()
    if ext in ('.SC5', '.SC8') and raw[:1] == b'\xfe':
        body = raw[7:]
        if ext == '.SC5':
            data = (body[:SC5_BYTES] + bytes(SC5_BYTES))[:SC5_BYTES]
            pal = body[0x7680:0x76A0] if len(body) >= 0x76A0 else MSX2_PALETTE
            rgb = [(pal[i * 2] >> 4 & 7, pal[i * 2 + 1] & 7, pal[i * 2] & 7) for i in range(16)]
            fg, bg = _fg_bg(rgb)
            return 5, data + bytes(pal), fg, bg
        data = (body[:SC8_BYTES] + bytes(SC8_BYTES))[:SC8_BYTES]
        return 8, data, 0xFF, 0x00
    from PIL import Image
    im = Image.open(path)
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA')
        bgimg = Image.new('RGBA', im.size, (0, 0, 0, 255))
        im = Image.alpha_composite(bgimg, im)
    im = im.convert('RGB')
    if _is_interlace(im):
        return _load_sc7_il(im, path)
    im = _crop_border(im, path)
    if im.size in ((256, 192), (512, 192)):
        pad = Image.new('RGB', (im.size[0], 212))
        pad.paste(im, (0, 0))
        im = pad
    if im.size == (512, 212):
        return _load_sc7(im, path)
    if im.size != (256, 212):
        print(f'警告: {path}: 大きさ {im.size} を 256x212 に変えます')
        im = im.resize((256, 212))
    # 3 ビットの RGB にしたときの色数が 16 以下なら SCREEN 5
    q = [(r * 7 + 127) // 255 for r in range(256)]
    raw = im.tobytes()
    px = [tuple(raw[i:i + 3]) for i in range(0, len(raw), 3)]
    c3 = [(q[r], q[g], q[b]) for r, g, b in px]
    colors = sorted(set(c3), key=lambda c: (c[0] * 3 + c[1] * 6 + c[2]))
    if len(colors) <= 16:
        idx = {c: i for i, c in enumerate(colors)}
        rgb, fg, bg = _palette(colors)
        data = bytearray(SC5_BYTES)
        for i in range(0, len(c3), 2):
            data[i // 2] = idx[c3[i]] << 4 | idx[c3[i + 1]]
        pal = bytearray()
        for r, g, b in rgb:
            pal += bytes([r << 4 | b, g])
        return 5, bytes(data) + bytes(pal), fg, bg
    # SCREEN 8 (GGGRRRBB) に誤差拡散で減色
    palimg = Image.new('P', (1, 1))
    flat = []
    for v in range(256):
        g, r, b = v >> 5 & 7, v >> 2 & 7, v & 3
        flat += [r * 255 // 7, g * 255 // 7, b * 255 // 3]
    palimg.putpalette(flat)
    dither = getattr(Image, 'Dither', Image).FLOYDSTEINBERG
    qim = im.quantize(palette=palimg, dither=dither)
    return 8, qim.tobytes(), 0xFF, 0x00


def _load_sc7(im, path):
    """横 512 ドットの画像 -> SCREEN 7 (16 色。17 色以上なら 16 色に減色)"""
    from PIL import Image
    q = [(r * 7 + 127) // 255 for r in range(256)]
    raw = im.tobytes()
    c3 = [(q[raw[i]], q[raw[i + 1]], q[raw[i + 2]]) for i in range(0, len(raw), 3)]
    colors = sorted(set(c3), key=lambda c: (c[0] * 3 + c[1] * 6 + c[2]))
    if len(colors) > 16:
        print(f'警告: {path}: {len(colors)} 色あるので 16 色に減らします')
        im = im.quantize(16, dither=getattr(Image, 'Dither', Image).FLOYDSTEINBERG).convert('RGB')
        raw = im.tobytes()
        c3 = [(q[raw[i]], q[raw[i + 1]], q[raw[i + 2]]) for i in range(0, len(raw), 3)]
        colors = sorted(set(c3), key=lambda c: (c[0] * 3 + c[1] * 6 + c[2]))[:16]
    idx = {c: i for i, c in enumerate(colors)}
    rgb, fg, bg = _palette(colors)
    data = bytearray(SC7_BYTES)
    for i in range(0, len(c3), 2):
        data[i // 2] = idx.get(c3[i], 0) << 4 | idx.get(c3[i + 1], 0)
    pal = bytearray()
    for r, g, b in rgb:
        pal += bytes([r << 4 | b, g])
    return 7, bytes(data) + bytes(pal), fg, bg


def cg_parts(mode, data):
    """load_cg のデータ -> (VRAM に送る画面のデータ, パレット 32 バイト)
    インターレースは偶数ライン・奇数ラインを続けたもの (間のパレットとすき間は除く)"""
    m = mode & 0x7F
    if mode & 0x80:
        return data[:SC7_BYTES] + data[SC7_BYTES + 256:SC7_BYTES * 2 + 256], data[SC7_BYTES:SC7_BYTES + 32]
    if m == 5:
        return data[:SC5_BYTES], data[SC5_BYTES:SC5_BYTES + 32]
    if m == 7:
        return data[:SC7_BYTES], data[SC7_BYTES:SC7_BYTES + 32]
    return data[:SC8_BYTES], bytes(32)


def _is_interlace(im):
    """横 512 ドット・インターレースの画面 (640x480 で、横は 2 倍でなく、偶数ラインと奇数ラインが違う) か"""
    if im.size != (640, 480):
        return False
    px = im.load()
    if all(px[x, y] == px[x + 1, y] for y in range(0, 480, 2) for x in range(0, 640, 2)):
        return False
    diff = sum(px[x, y] != px[x, y + 1] for y in range(0, 480, 2) for x in range(0, 640, 4))
    return diff > 240 * 160 // 100          # 1% 以上違う


def _load_sc7_il(im, path):
    """横 512 ドット・インターレース (512x424) -> SCREEN 7 の 2 ページ分 (偶数ライン・奇数ライン)
    データ: 偶数ライン 54272 バイト + パレット 32 バイト (256 バイトにそろえる) + 奇数ライン 54272 バイト
    画面モードのバイトは 87h (bit7 = インターレース)"""
    from PIL import Image
    fields = []
    for f in (0, 1):                      # 偶数ライン・奇数ラインを 1 行ずつ取り出す
        fl = Image.new('RGB', (640, 240))
        for y in range(240):
            fl.paste(im.crop((0, y * 2 + f, 640, y * 2 + f + 1)), (0, y))
        fields.append(fl)
    fields = [_crop_border(fl, path) for fl in fields]
    for i, fl in enumerate(fields):
        if fl.size == (512, 192):
            pad = Image.new('RGB', (512, 212))
            pad.paste(fl, (0, 0))
            fields[i] = pad
    if any(fl.size != (512, 212) for fl in fields):
        sys.exit(f'{path}: インターレースの画面の大きさが想定と違います')
    print(f'{path}: インターレース (512x424) です')
    both = Image.new('RGB', (512, 424))
    both.paste(fields[0], (0, 0))
    both.paste(fields[1], (0, 212))
    q = [(r * 7 + 127) // 255 for r in range(256)]
    raw = both.tobytes()
    c3 = [(q[raw[i]], q[raw[i + 1]], q[raw[i + 2]]) for i in range(0, len(raw), 3)]
    colors = sorted(set(c3), key=lambda c: (c[0] * 3 + c[1] * 6 + c[2]))
    if len(colors) > 16:
        print(f'警告: {path}: {len(colors)} 色あるので 16 色に減らします')
        both = both.quantize(16, dither=getattr(Image, 'Dither', Image).FLOYDSTEINBERG).convert('RGB')
        raw = both.tobytes()
        c3 = [(q[raw[i]], q[raw[i + 1]], q[raw[i + 2]]) for i in range(0, len(raw), 3)]
        colors = sorted(set(c3), key=lambda c: (c[0] * 3 + c[1] * 6 + c[2]))[:16]
    idx = {c: i for i, c in enumerate(colors)}
    rgb, fg, bg = _palette(colors)
    data = bytearray(SC7_BYTES * 2)
    for i in range(0, len(c3), 2):
        data[i // 2] = idx.get(c3[i], 0) << 4 | idx.get(c3[i + 1], 0)
    pal = bytearray()
    for r, g, b in rgb:
        pal += bytes([r << 4 | b, g])
    pal += bytes(256 - len(pal))
    return 0x87, bytes(data[:SC7_BYTES]) + bytes(pal) + bytes(data[SC7_BYTES:]), fg, bg


def _crop_border(im, path):
    """エミュレータのスクリーンショット (周りの枠付き) から MSX の画面の部分を切り出す
    320x240 (openMSX の screenshot -raw など) と 640x480 に対応する。
    640x480 は、縦が 2 倍なら 1 行おきに、横が 2 倍なら 1 ドットおきに取り出す。
    横が 2 倍でなければ横 512 ドットの画面 (SCREEN 6/7)。縦が 2 倍でなければインターレースで、1 行おきに取る。
    212 ライン表示なら上下 14 ドット、192 ライン表示なら上下 24 ドットが枠 (枠の色で見分ける)"""
    from PIL import Image
    if im.size == (640, 480):
        px = im.load()
        hdbl = all(px[x, y] == px[x + 1, y] for y in range(0, 480, 2) for x in range(0, 640, 2))
        im = im.resize((640 if not hdbl else 320, 240), Image.NEAREST)   # 縦は 1 行おき
        if not hdbl:
            print(f'{path}: 横 512 ドットの画面です')
    if im.size not in ((320, 240), (640, 240)):
        return im
    k = im.size[0] // 320                    # 横の倍率 (512 ドットの画面なら 2)
    border = im.getpixel((0, 0))

    def is_border(y0, y1):
        return all(im.getpixel((x, y)) == border for y in range(y0, y1) for x in range(32 * k, 288 * k, 4))
    if is_border(14, 24) and is_border(216, 226):
        print(f'{path}: 枠を切り取りました (192 ライン)')
        return im.crop((32 * k, 24, 288 * k, 216))
    print(f'{path}: 枠を切り取りました (212 ライン)')
    return im.crop((32 * k, 14, 288 * k, 226))


def _palette(colors):
    """絵の色 (3 ビットの r, g, b。16 色以下) -> (16 色のパレット, 文字色, 背景色)
    最下行の文字は白・背景は黒にしたいので、パレットに空きがあれば白と黒を足す。
    空きがなければ、絵の中で最も明るい色と最も暗い色を使う"""
    rgb = list(colors)
    for c in ((7, 7, 7), (0, 0, 0)):
        if c not in rgb and len(rgb) < 16:
            rgb.append(c)
    fg, bg = _fg_bg(rgb)
    rgb += [(0, 0, 0)] * (16 - len(rgb))
    return rgb, fg, bg


def _fg_bg(rgb):
    """パレット (3 ビットの r, g, b) から、最も明るい色と最も暗い色の番号"""
    lum = [r * 3 + g * 6 + b for r, g, b in rgb]
    return lum.index(max(lum)), lum.index(min(lum))


MSX2_PALETTE = bytes([0x00, 0, 0x00, 0, 0x11, 6, 0x33, 7, 0x17, 1, 0x27, 3, 0x51, 1, 0x27, 6,
                      0x71, 1, 0x73, 3, 0x61, 6, 0x64, 6, 0x11, 4, 0x65, 2, 0x55, 5, 0x77, 7])

# --make-playlist で使うゲーム名 (フォルダ名 -> (ゲーム名, 注記))
GAME_NAMES = {
    'C-TIMES': ('キャビンタイムズ', 'ゲームのおまけコーナー「キャビンタイムズ」の曲'),
    'XAK': ('Xak', ''),
    'XAKII': ('Xak II', ''),
    'ILLUSION': ('Illusion City', ''),
    'FFANTASY': ('Final Fantasy', ''),
    'FRAY': ('Fray', ''),
    'PMAKER': ('プリンセスメーカー', ''),
    'GAZZEL': ('ガゼルの塔', ''),
    'RISK2': ('キャンペーン版大戦略II', ''),
}


def make_playlist(data_dir, list_dir):
    """data_dir 以下の全 MCM を列挙したプレイリストを標準出力に書く"""
    seen = {}
    print('# MICRO CABIN MUSIC PLAYER プレイリスト')
    print('# 書式: 曲ファイル | 曲名 | ループ回数 | ドライバ   (曲名以降は省略可)')
    print('# 行頭に # を付けるとその曲は収録されない')
    print('# "@game ゲーム名" でそれ以降の曲のゲーム名を指定する')
    print('# 曲名・ゲーム名には英数字・かな・漢字が使える (# は使えない)')
    for d in sorted(os.listdir(data_dir)):
        dp = os.path.join(data_dir, d)
        if not os.path.isdir(dp):
            continue
        print(f'\n# ---- {d} ----')
        name, note = GAME_NAMES.get(d.upper(), (d, '正式名称を確認してください'))
        print(f'@game {name}' + (f'    # {note}' if note else ''))
        for fn in sorted(os.listdir(dp)):
            if not fn.upper().endswith('.MCM'):
                continue
            fp = os.path.join(dp, fn)
            rel = os.path.relpath(fp, list_dir).replace('\\', '/')
            body = load_song(fp)
            try:
                nch, empty = check_song(body)
            except ValueError as e:
                print(f'# {rel}    # 読めない: {e}')
                continue
            h = hashlib.md5(body).hexdigest()
            if h in seen:
                print(f'# {rel}    # {seen[h]} と同じ内容')
                continue
            seen[h] = rel
            if empty:
                print(f'# {rel}    # 空の曲 (音が出ない)')
                continue
            if not uses_fm(body):
                print(f'# {rel}    # PSGのみ')
                continue
            note = f'    # {nch}ch (13ch以降は無視される)' if nch > MAX_CHANNELS else ''
            drv = ' | | | B' if d.upper() == 'PMAKER' else ''
            print(f'{rel}{drv}{note}')


# ---------------------------------------------------------------------------
# ROM 組み立て
def find_sjasmplus():
    """環境変数 SJASMPLUS か PATH から探す"""
    exe = os.environ.get('SJASMPLUS')
    if exe and os.path.isfile(exe):
        return exe
    return shutil.which('sjasmplus')


def assemble():
    exe = find_sjasmplus()
    if not exe:
        sys.exit('sjasmplus が見つかりません (PATH に追加するか --no-asm で既存の player.bin を使ってください)')
    r = subprocess.run([exe, '--sym=player.sym', '--lst=player.lst', 'player.asm'],
                       cwd=HERE, capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stdout + r.stderr)
        sys.exit('アセンブルに失敗しました')


def read_symbols():
    syms = {}
    for line in open(os.path.join(HERE, 'player.sym')):
        m = re.match(r'\s*(\S+):\s*EQU\s+0x([0-9A-Fa-f]+)', line)
        if m:
            syms[m.group(1)] = int(m.group(2), 16)
    return syms


class BankPacker:
    """バンク1以降に順番に詰める。データはバンク境界をまたがない"""

    def __init__(self):
        self.banks = []          # bytearray のリスト (index 0 = バンク1)
        self.new_bank()
        self.banks[0].extend(b'MC16')   # バンク1の目印 (プレーヤーが起動時にマッパーが ASCII16 か確かめる)

    def new_bank(self):
        self.banks.append(bytearray())

    def put(self, data):
        if len(data) > BANK_SIZE:
            raise ValueError('16KB を超えるデータは置けません')
        if len(self.banks[-1]) + len(data) > BANK_SIZE:
            self.new_bank()
        cur = self.banks[-1]
        addr = PAGE2 + len(cur)
        cur.extend(data)
        return len(self.banks), addr      # (バンク番号, アドレス)

    def put_big(self, data):
        """バンクの先頭から続けて置く (16KB を超えてよい)。戻り: 先頭のバンク番号"""
        if self.banks[-1]:
            self.new_bank()
        first = len(self.banks)
        for i in range(0, len(data), BANK_SIZE):
            if i:
                self.new_bank()
            self.banks[-1].extend(data[i:i + BANK_SIZE])
        return first


def disk_files(root, folder):
    """フォルダの中のディスクイメージ -> [(ファイル名, 中身)]"""
    out = []
    d = os.path.join(root, folder)
    if os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            f = os.path.join(d, fn)
            if os.path.isfile(f) and fn.lower().endswith(('.dsk', '.di1', '.di2')):
                out.append((fn, open(f, 'rb').read()))
    return out


class Drivers:
    """ディスクイメージからゲームのドライバを取り出し、プレーヤーで動くように改造する

    曲のドライバは、曲が見つかったディスクにあるドライバ (drivers.json に載っている版)。
    そのディスクになければ同じフォルダのほかのディスク、それでもなければ DRV_FALLBACK のフォルダ。
    改造: ループの終わり -> call HookLoop、音を出す所 -> call HookNote (レベルメーター)、
          表のポインタ -> ページ2 の RAM、曲の番地が決まっているもの -> A000h、
          turboR のタイマー (E6h) で待つ FM の書き込み -> 待たずに書く (turboR は Z80 モードで動かす)"""

    def __init__(self, disk_root, syms):
        self.root = disk_root
        self.syms = syms
        self.known = json.load(open(DRIVERS_JSON, encoding='utf-8'))
        self.found = {}          # フォルダ -> [(ファイル名, 中身, [(位置, md5 キー)])]
        self.images = []         # (キー, 改造したイメージ, 情報)。番号は 0 から
        self.index = {}          # キー -> 番号
        self.log = {}            # フォルダ -> {ドライバの名前: 曲数}

    def _folder(self, folder):
        if folder not in self.found:
            out = []
            sigs = [DRV_SIG] + [re.compile(re.escape(bytes.fromhex(x)))
                                for x in sorted({d['sig'] for d in self.known.values() if 'sig' in d})]
            for fn, data in disk_files(self.root, folder):
                drvs = []
                for m in (m for sig in sigs for m in sig.finditer(data)):
                    k = hashlib.md5(data[m.start():m.start() + 0x600]).hexdigest()
                    if k in self.known:
                        d = self.known[k]
                        if hashlib.md5(data[m.start():m.start() + d['copylen']]).hexdigest() == d['md5']:
                            drvs.append((m.start(), k))
                out.append((fn, data, drvs))
            self.found[folder] = out
        return self.found[folder]

    def for_song(self, song_path, body):
        """曲に使うドライバの番号と、ドライバの見つかった所"""
        folder = os.path.basename(os.path.dirname(os.path.abspath(song_path)))
        disks = self._folder(folder)
        key = where = None
        for fn, data, drvs in disks:
            if drvs and data.find(body) >= 0:
                key, where = drvs[0][1], f'{folder}/{fn}'
                break
        for f in [folder] + DRV_FALLBACK.get(folder, []):
            if key:
                break
            for fn, data, drvs in self._folder(f):
                if drvs:
                    key, where = drvs[0][1], f'{f}/{fn}'
                    break
        if key is None:
            sys.exit(f'{song_path}: ゲームのドライバが見つかりません。{os.path.join(self.root, folder)} に'
                     'そのゲームのディスクイメージを入れてください')
        name = self.known[key]['name']
        log = self.log.setdefault(folder, {})
        log[(name, where)] = log.get((name, where), 0) + 1
        return self.number(key, where)

    def number(self, key, where):
        if key not in self.index:
            if len(self.images) >= DRV_MAX:
                sys.exit(f'ドライバが多すぎます ({DRV_MAX} 種類まで)')
            folder, fn = where.split('/', 1)
            data = next(d for f, d, x in self._folder(folder) if f == fn)
            pos = next(p for p, k in next(x for f, d, x in self._folder(folder) if f == fn) if k == key)
            d = self.known[key]
            self.index[key] = len(self.images)
            self.images.append((key, self.patch(data[pos:pos + d['copylen']], d), d))
        return self.index[key]

    def song_max(self, i):
        """このドライバで鳴らせる曲の大きさ (A000h から)"""
        d = self.images[i][2]
        return min(SONG_MAX, d['work'] - 0xA000) if 0xA000 < d['work'] < 0xC000 else SONG_MAX

    def tbl_ram(self, d):
        """表を置く RAM の番地: 9000h + 元の番地の下位 12 ビット (入らなければ 8000h +)。
        下位の並びをゲームと同じにしておくと、表の外を読む音 (37 番目の音など) もゲームと同じになる"""
        for top in (0x9000, 0x8000):
            a = top | (d['tblorig'][0] & 0xFFF)
            lo = d['base'] if d['base'] >= 0x8000 else d['work']
            if a + TBL_LEN <= 0xA000 and not (lo < a + TBL_LEN and a < d['end']):
                return a
        sys.exit(f"{d['name']}: 表を置く RAM がありません")

    def patch(self, img, d):
        img = bytearray(img)
        b = d['base']
        name = d['name']

        def put(addr, bs, want=None):
            o = addr - b
            if want is not None and img[o:o + len(want)] != want:
                sys.exit(f'{name}: {addr:04X}h の内容が想定と違います')
            img[o:o + len(bs)] = bs

        def call(a):
            return bytes([0xCD, a & 0xFF, a >> 8])

        put(d['endl'], call(self.syms['HookLoop']), bytes([0xDD, 0x7E, d['cnt'] + 1]))
        put(d['note'], call(self.syms['HookNote']), bytes.fromhex('dd4e04dd7704'))
        for a in d['fixed']:                       # ld hl,曲の番地 -> A000h
            if not 0xC000 <= struct.unpack_from('<H', img, a - b)[0] < 0xE000:
                sys.exit(f'{name}: {a:04X}h の曲の番地が想定と違います')
            put(a, struct.pack('<H', 0xA000))
        t = self.tbl_ram(d)
        for k, orig in enumerate(d['tblorig']):
            put(d['tblptr'] + 2 * k, struct.pack('<H', t + orig - d['tblorig'][0]), struct.pack('<H', orig))
        for a in d['wfm']:                         # push af / ld a,b / out (7Ch),a / pop af / out (7Dh),a / ret
            put(a, bytes.fromhex('f578d37cf1d37dc9'), bytes.fromhex('c5f5'))
        for a in d['wait']:                        # ret
            put(a, b'\xc9', b'\xc5')
        for a in d['eis']:                         # ei -> nop (ページ1のドライバ: RAM に切り替えている間は割込みを止める)
            put(a, b'\x00', b'\xfb')
        if b < STACK_TOP and b >= 0xC000 or d['end'] > DRV_RAM_END or d['work'] < 0x8000:
            sys.exit(f'{name}: ドライバの番地 ({b:04X}h-{d["end"]:04X}h) がプレーヤーのワークと重なります')
        return bytes(img)

    def desc(self, i, bank, addr):
        """DrvDir の 1 件 (player.asm の D_*)"""
        key, img, d = self.images[i]
        w = lambda x: struct.pack('<H', x)
        out = (bytes([bank]) + w(addr) + w(d['base']) + w(d['copylen']) +
               w(d['end'] - d['work']) + w(d['int']) + w(d['cmd']) + bytes(d['cmds']) +
               w(d['stride']) + bytes([d['cnt']]) + w(self.tbl_ram(d)) + w(d['chn']) + w(d['chact']) +
               w(d['fadepass']) + w(d['fadectl']) + w(d['shdfme']) +
               w(d['work']) + bytes([d['rhy'], 1 if d['base'] < 0x8000 else 0]) + bytes(4))
        assert len(out) == DRV_DESC
        return out


class InstTables:
    """ディスクイメージにあるゲームの表 (音色など) を集め、曲ごとに使う表を決める

    ゲームのディスクでは、表は曲と同じ並びに置かれていて、その後ろに続く曲で使われる
    (Cabin Times のディスクでは Xak II の表の後ろに Xak II の曲、FRAY の表の後ろに FRAY の曲が並ぶ)。
    そこで、曲をそのゲームのディスクイメージ (disk_image/曲のフォルダ名/) の中から探し、
    同じディスクで曲より前にある一番近い表を使う。前になければ後ろの一番近い表、
    そのディスクになければ同じフォルダのほかのディスクの最初の表。見つからなければ 0"""

    def __init__(self, disk_root):
        self.root = disk_root
        self.disks = {}          # フォルダ名 -> [(ファイル名, 中身, [(位置, 表)])]
        self.tables = []         # 表 (bytes)。番号は 1 から
        self.used = {}           # 表 -> 番号

    def _folder(self, name):
        if name not in self.disks:
            out = []
            for fn, data in disk_files(self.root, name):
                tbls = []
                for m in INST_SIG.finditer(data):
                    s = m.start() - 0xE0
                    if s >= 0 and m.start() + 0x100 <= len(data):
                        tbls.append((s, data[s:s + TBL_LEN]))
                out.append((fn, data, tbls))
            self.disks[name] = out
        return self.disks[name]

    def for_song(self, song_path, body):
        """曲に使う表の番号 (1-) と説明。表がなければ (0, 理由)"""
        folder = os.path.basename(os.path.dirname(os.path.abspath(song_path)))
        disks = self._folder(folder)
        tbl = where = None
        for fn, data, tbls in disks:
            pos = data.find(body)
            if pos < 0 or not tbls:
                continue
            before = [t for t in tbls if t[0] < pos]
            s, tbl = max(before) if before else min(tbls)
            where = f'{fn} {s:06X}h'
            break
        if tbl is None:
            for fn, data, tbls in disks:
                if tbls:
                    s, tbl = tbls[0]
                    where = f'{fn} {s:06X}h (曲はディスクに見つからず)'
                    break
        if tbl is None:
            return 0, 'ディスクイメージに表なし'
        return self.number(tbl), where

    def default(self):
        """ゲームの表が見つからない曲に使う表: 幻影都市のディスクの表、なければ見つかった最初の表"""
        for folder in ['ILLUSION'] + sorted(os.listdir(self.root)) if os.path.isdir(self.root) else []:
            for fn, data, tbls in self._folder(folder):
                if tbls:
                    return tbls[0][1]
        sys.exit(f'ディスクイメージに音色などの表が見つかりません: {self.root}')

    def number(self, tbl):
        """表の番号 (1-)。初めての表なら加える"""
        if tbl not in self.used:
            if len(self.tables) >= SET_MAX:
                sys.exit(f'ゲームの表が多すぎます ({SET_MAX} 種類まで)')
            self.tables.append(tbl)
            self.used[tbl] = len(self.tables)
        return self.used[tbl]


def build(args):
    font = Font(args.font_dir)
    open(os.path.join(HERE, 'halffont.bin'), 'wb').write(font.half_font())
    if not args.no_asm:
        if find_sjasmplus():
            assemble()
        elif os.path.isfile(os.path.join(HERE, 'player.bin')) and os.path.isfile(os.path.join(HERE, 'player.sym')):
            print('sjasmplus がないので、組み立て済みの player.bin を使います')
        else:
            sys.exit('sjasmplus も組み立て済みの player.bin もありません')
    syms = read_symbols()
    code = bytearray(open(os.path.join(HERE, 'player.bin'), 'rb').read())
    table_addr = syms['PlaylistTable']
    table_off = table_addr - 0x4000

    entries, games, startup = parse_playlist(args.playlist, args.loops)
    unknown = fill_from_db(entries, games, startup, args.db, args.loops)
    if not entries:
        sys.exit('プレイリストに曲がありません')
    if len(entries) > 999:
        sys.exit('曲数は 999 曲までです')

    packer = BankPacker()
    placed = {}            # md5 -> (bank, addr)
    table = bytearray(len(entries).to_bytes(2, 'little')) + bytes(TABLE_HEADER - 2)
    warnings = []

    # 【 】 (ゲームの行で使う全角文字)
    o = syms['LangCfg'] - 0x4000
    code[o] = {'auto': 0, 'en': 1, 'ja': 2}[args.lang]
    for sym, ch in (('UiBrkL', '【'), ('UiBrkR', '】')):
        o = syms[sym] - 0x4000
        code[o:o + 3] = font.encode(ch) + b'\0'
    # ヘルプ (H キー) の文字列: 上の枠, 下の枠, 左右の枠, 1 ページ目 5 行, 2 ページ目 5 行
    help_lines = ['┌' + '─' * 30 + '┐', '└' + '─' * 30 + '┘', '│'] + HELP_PAGES[0] + HELP_PAGES[1]
    blob = b''.join(font.encode(t) + b'\0' for t in help_lines)
    if len(blob) > HELP_TEXT_SIZE:
        sys.exit(f'ヘルプの文字列が長すぎます ({len(blob)} > {HELP_TEXT_SIZE} バイト)')
    o = syms['HelpText'] - 0x4000
    code[o:o + len(blob)] = blob

    # CG (同じ画像は 1 つだけ置く)
    cg_placed = {}
    cg_sizes = []          # (元の大きさ, 圧縮した大きさ)

    def put_cg(path):
        """CG を置く: パレット 32 バイト + 画面のデータをランレングス圧縮したもの (プレーヤーの CgDec で展開)"""
        if path not in cg_placed:
            mode, data, fg, bg = load_cg(path)
            raw, pal = cg_parts(mode, data)
            blob = pal + cgrle.rle(raw)
            cg_placed[path] = bytes([packer.put_big(blob), mode, fg, bg])
            cg_sizes.append((len(raw), len(blob)))
        return cg_placed[path]

    def text2(ja, en, where):
        """曲名・ゲーム名: 日本語\0英語\0"""
        bad = []
        b = font.encode(ja, bad) + b'\0' + font.encode(en or '', bad) + b'\0'
        if bad:
            warnings.append(f'{where}: 表示できない文字を ? にしました: {"".join(bad)}')
        return b

    # ゲームの情報: CG (4 バイト) + ゲーム名 (日本語\0英語\0)。バンク0 の表の直後に置く
    game_addr = {}
    game_blob = bytearray()
    for e in entries:
        g = e['game']
        if g and g not in game_addr:
            gi = games.get(g, dict(en='', cg=None))
            game_addr[g] = len(game_blob)
            game_blob += (put_cg(gi['cg']) if gi['cg'] else bytes(4)) + text2(g, gi['en'], f'ゲーム名 "{g}"')
    games_off = table_off + TABLE_HEADER + ENTRY_SIZE * len(entries)

    one_shot = []          # ループしない曲
    silent_loop = []       # 音を出さない無限ループを終わりにした曲

    def song_entry(song, title, title_en, loops, drv, ga, where):
        body = load_song(song)
        try:
            nch, empty = check_song(body)
        except ValueError as ex:
            sys.exit(f'{where}: {song}: {ex}')
        if len(body) > SONG_MAX:
            sys.exit(f'{where}: 曲データが大きすぎます ({len(body)} > {SONG_MAX} バイト)')
        if nch > MAX_CHANNELS:
            warnings.append(f'{where}: {nch}ch あります。13ch目以降は演奏されません')
        if empty:
            warnings.append(f'{where}: 空の曲です (すぐ次の曲に進みます)')
        body, nsil = strip_silent_loops(body)
        if nsil:
            silent_loop.append(song)
        if not song_loops(body):
            loops = 1                     # ループしない曲は 1 回 (LOOP の表示も 01/01)
            one_shot.append(song)
        tb, ta = packer.put(text2(title, title_en, where))
        h = hashlib.md5(body).hexdigest()
        if h not in placed:
            placed[h] = packer.put(body)
        sb, sa = placed[h]
        n = len(body)
        return bytes([sb, sa & 0xFF, sa >> 8, n & 0xFF, n >> 8,
                      tb, ta & 0xFF, ta >> 8, loops, drv, ga & 0xFF, ga >> 8])

    # 曲ごとのドライバとゲームの表 (E_DRV に組の番号)
    inst = InstTables(args.disks)
    drivers = Drivers(args.disks, syms)
    inst_log = {}          # フォルダ -> {表の番号: 曲数}
    inst_src = {}          # 表の番号 -> 最初に見つけた場所
    sets = []              # (ドライバの番号, 表の番号)。組の番号は 1 から

    def drv_byte(song, drv):
        body = load_song(song)
        di = drivers.for_song(song, body)
        if len(body) > drivers.song_max(di):
            sys.exit(f'{song}: 曲データが大きすぎます ({len(body)} > {drivers.song_max(di)} バイト。'
                     f'{drivers.images[di][2]["name"]} のドライバ)')
        n, where = inst.for_song(song, body)
        if n == 0:
            n = inst.number(inst.default())   # ゲームの表が見つからなければ幻影都市などの表
            where = 'ゲームの表が見つからないので代わりの表'
        folder = os.path.basename(os.path.dirname(os.path.abspath(song)))
        log = inst_log.setdefault(folder, {})
        log[n] = log.get(n, 0) + 1
        if n not in inst_src:
            inst_src[n] = f'{folder}/{where}'
        if (di, n) not in sets:
            if len(sets) >= SET_MAX:
                sys.exit(f'ドライバと表の組が多すぎます ({SET_MAX} 組まで)')
            sets.append((di, n))
        return sets.index((di, n)) + 1

    for e in entries:
        ga = 0x4000 + games_off + game_addr[e['game']] if e['game'] else 0
        table += song_entry(e['song'], e['title'], e['title_en'], e['loops'], drv_byte(e['song'], e['drv']),
                            ga, e['where'])

    # 起動時の曲と CG (曲は 1 周で止める。CG がある MSX2 ではループし続ける)
    if startup['song']:
        table[8:20] = song_entry(startup['song'], startup['title'], startup['title_en'], 1,
                                 drv_byte(startup['song'], 0), 0, '@startup')
    # 曲ごとの CG (@song_cg)
    scg = bytearray()
    for k, e in enumerate(entries):
        if e.get('song_cg'):
            scg += k.to_bytes(2, 'little') + put_cg(e['song_cg'])
    if len(scg) // 6 > SONG_CG_MAX:
        sys.exit(f'@song_cg が多すぎます ({len(scg) // 6} > {SONG_CG_MAX} 曲)')
    o = syms['SongCgTbl'] - 0x4000
    code[o:o + len(scg) + 2] = scg + bytes([0xFF, 0xFF])
    # ドライバを置き、DrvDir に書く
    o = syms['DrvDir'] - 0x4000
    for i, (key, img, d) in enumerate(drivers.images):
        b, a = packer.put(img)
        code[o + i * DRV_DESC:o + (i + 1) * DRV_DESC] = drivers.desc(i, b, a)
    # ゲームの表を置き、ドライバと表の組を SetDir に書く
    tpos = [packer.put(t) for t in inst.tables]
    o = syms['SetDir'] - 0x4000
    for i, (di, n) in enumerate(sets):
        tb, ta = tpos[n - 1]
        code[o + i * 4:o + i * 4 + 4] = bytes([di, tb, ta & 0xFF, ta >> 8])
    table[2] = 1 if args.autoplay else 0        # 設定 (bit0 = 自動再生)
    # 起動時の CG (指定がなければ標準の CG)
    table[20:24] = put_cg(startup['cg'] or DEFAULT_CG)

    # 全角フォント: 新しいバンクから 1字 16 バイト、1バンク 1024 字
    if font.glyphs:
        packer.new_bank()
        table[7] = len(packer.banks)
        for i in range(0, len(font.glyphs), GLYPHS_PER_BANK):
            if i:
                packer.new_bank()
            chunk = b''.join(g + bytes(GLYPH_SIZE - len(g)) for g in font.glyphs[i:i + GLYPHS_PER_BANK])
            packer.banks[-1].extend(chunk)

    table += game_blob
    end = table_off + len(table)
    if end > BANK_SIZE:
        sys.exit(f'プレイリスト表がバンク0に収まりません ({len(entries)}曲)')
    code.extend(b'\xFF' * (BANK_SIZE - len(code)))
    code[table_off:end] = table

    rom = bytearray(code)
    for b in packer.banks:
        rom += b + b'\xFF' * (BANK_SIZE - len(b))
    used = len(rom)

    if args.size == 'auto':
        size = 128 * 1024
        while size < used:
            size *= 2
    else:
        size = int(args.size) * 1024
    if used > size:
        sys.exit(f'ROM 容量が足りません: 必要 {used // 1024}KB > {size // 1024}KB')
    if size // BANK_SIZE > 256:
        sys.exit('ASCII16 は最大 4MB (256バンク) までです')
    rom += b'\xFF' * (size - used)

    open(args.output, 'wb').write(rom)
    for e in unknown:
        warnings.append(f"{e['where']}: データベースにない曲です (曲名は「{e['title']}」): {e['song']}")
    for w in warnings:
        print('警告:', w)
    data_bytes = sum(len(b) for b in packer.banks)
    print(f'{args.output}: {size // 1024}KB  曲数 {len(entries)}  '
          f'曲データ {len(placed)}種類  使用バンク {len(packer.banks) + 1}/{size // BANK_SIZE}  '
          f'(データ {data_bytes // 1024}KB)  全角文字 {len(font.glyphs)}種類  CG {len(cg_placed)}枚 '
          f'({sum(a for a, b in cg_sizes) // 1024}KB を {sum(b for a, b in cg_sizes) // 1024}KB に圧縮)')
    print(f'ループしない曲 {len(set(one_shot))}曲 (1 回で次へ。LOOP は 01/01)')
    if silent_loop:
        names = ', '.join(sorted({os.path.basename(x) for x in silent_loop}))
        print(f'  うち音を出さない無限ループで待つ曲 {len(set(silent_loop))}曲 (ループの所で終わらせた): {names}')
    print(f'ドライバ {len(drivers.images)}種類:')
    for folder in sorted(drivers.log):
        for (name, where), c in sorted(drivers.log[folder].items()):
            print(f'  {folder}: {name} ({where}) {c}曲')
    print(f'ゲームの表 (音色など) {len(inst.tables)}種類:')
    for n in sorted(inst_src):
        print(f'  表{n}: {inst_src[n]}')
    for folder in sorted(inst_log):
        items = ', '.join(f'表{n} {c}曲' for n, c in sorted(inst_log[folder].items()))
        print(f'  {folder}: {items}')
    print('マッパー: ASCII16  (エミュレータでは ROM タイプに ASCII16 を指定してください)')


def main():
    ap = argparse.ArgumentParser(description='MICRO CABIN MUSIC PLAYER メガロムビルダー')
    ap.add_argument('playlist', nargs='?', default=os.path.join(HERE, 'playlist.txt'))
    ap.add_argument('-o', '--output', default=os.path.join(HERE, 'MCPLAYER.ROM'))
    ap.add_argument('--size', default='1024', help='ROM サイズ (KB) または auto (既定 1024)')
    ap.add_argument('--loops', type=int, default=2, help='ループ回数の既定値 (既定 2)')
    ap.add_argument('--db', default=os.path.join(HERE, '..', 'tools', 'mcm_db.csv'),
                    help='曲名などを引くデータベース (既定 ../tools/mcm_db.csv)。プレイリストに曲名を書いた曲はそちらを使う')
    ap.add_argument('--disks', default=os.path.join(HERE, '..', 'disk_image'),
                    help='ゲームのドライバと表 (音色など) を取り出すディスクイメージの場所 (既定 ../disk_image。'
                         '曲のフォルダ名と同じ名前のフォルダを見る)')
    ap.add_argument('--lang', choices=('auto', 'en', 'ja'), default='auto',
                    help='表示する言語: auto = 本体の文字セットで決める (既定)、en = 常に英語、ja = 常に日本語。'
                         'ROM の 001Eh 番地 (目印 "MCPLAYER LANG:" の直後) の 1 バイトでも変えられる (0/1/2)')
    ap.add_argument('--font-dir', default=FONT_DIR,
                    help=f"k8x12 フォントの PNG がある所 (既定 ../font/misaki_12x8)")
    ap.add_argument('--autoplay', action='store_true',
                    help='自動再生: 起動時の曲が終わったら (なければ起動してすぐ) リストの先頭の曲から順に鳴らし続ける。'
                         'キーボードのない環境 (1chipMSX など) 向け')
    ap.add_argument('--no-asm', action='store_true', help='アセンブルせず既存の player.bin を使う')
    ap.add_argument('--make-playlist', metavar='DATA_DIR',
                    help='DATA_DIR 以下の全曲のプレイリストを標準出力に書く')
    args = ap.parse_args()
    if args.make_playlist:
        sys.stdout.reconfigure(encoding='utf-8')
        make_playlist(args.make_playlist, os.getcwd())
        return
    build(args)


if __name__ == '__main__':
    main()
