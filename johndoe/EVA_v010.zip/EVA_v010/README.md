# EVASD / EV9SD / EV6SD - SD カードの動画プレーヤー (v0.10)

MSX turboR で、SD カードの動画を約 12 コマ / 秒・PCM 音声付きで再生するプレーヤーと、Windows 用の変換プログラムです。
本体の V9958、V9990 (GFX9000 など)、HRA! 氏の V9968 カートリッジの 3 種類の VDP に対応しています。

元になったのは d4.princess.ne.jp の EVASD (ESE Video Authorizer) です。この版は Lefty Serve が手を加えたもので、
V9990 版と V9968 版の追加、音のタイミングの作り直し、古い MegaFlashROM SCC+ SD への対応などを行っています。

## 必要なもの

| | |
|---|---|
| MSX | MSX turboR (Z80 モードで動かします)、Nextor |
| SD カード | ESE-SDisk、または MegaFlashROM SCC+ SD (FW v3 より前の古い FW にも対応) |
| VDP | 本体の V9958 (EVASD)、V9990 カートリッジ (EV9SD)、V9968 カートリッジ I/O 88h (EV6SD) |
| PC | Windows 10 / 11、ffmpeg と ffprobe (コマンドプロンプトから実行できるように PATH を通す)。Python は不要 |

## パッケージの中身

| ファイル | 内容 |
|---|---|
| `MSX\EVASD.COM` | 本体の V9958 で .EVA を再生 (SCREEN12 / SCREEN8) |
| `MSX\EV9SD.COM` | V9990 で .EV9 を再生 (64 色) |
| `MSX\EV6SD.COM` | V9968 (I/O 88h) で .EV6 を再生 (SCREEN8 + 拡張パレット 256 色) |
| `WIN\EVACONV.BAT` | 動画 → .EVA (V9958 SCREEN12)。動画ファイルをドラッグ＆ドロップ |
| `WIN\EVA8CONV.BAT` | 動画 → .EVA (V9958 SCREEN8) |
| `WIN\EV9CONV.BAT` | 動画 → .EV9 (V9990) |
| `WIN\EV6CONV.BAT` | 動画 → .EV6 (V9968) |
| `WIN\EVACONV\` | 変換プログラム本体 (EVACONV.exe と DLL。フォルダごとこの位置に置いておく) |
| `WIN\EVACONV\LICENSES\` | 変換プログラムに含まれるほかのソフトのライセンス |

## 1. 変換 (Windows)

動画ファイルを、作りたい形式のバッチファイル (`EV6CONV.BAT` など) にドラッグ＆ドロップします。
複数のファイルをまとめて落とせます。動画と同じ場所に、同じ名前で変換したファイルができます。

- 縦横比を自動で判定して、4:3 なら 124x108、16:9 なら 144x93 ドットにします
- 変換の時間の目安は、動画 1 分で 2〜3 分 (V9968 / V9990。V9958 はもっと速い)
- MSX-DOS で扱えるように、ファイル名は半角英数 8 文字以内にしてください (長い名前のときは変換後に付け直すか、下の `-o` を使う)

オプションを付けるときは、コマンドプロンプトで EVACONV.exe を直接使います。

```
WIN\EVACONV\EVACONV.exe ev6 MOVIE.mp4 -o MOVIE          出力名を MOVIE.EV6 にする
WIN\EVACONV\EVACONV.exe ev6 MOVIE.mp4 --ss 60 -t 30     60 秒目から 30 秒だけ
WIN\EVACONV\EVACONV.exe ev6 MOVIE.mp4 --autocrop        焼き込まれた黒帯を除く
WIN\EVACONV\EVACONV.exe ev6 -h                          オプションの一覧
```

形式の指定は `eva` = V9958 SCREEN12、`eva8` = V9958 SCREEN8、`ev9` = V9990、`ev6` = V9968 です。

## 2. 再生 (MSX turboR)

プレーヤーと変換したファイルを SD カードにコピーし、MSX-DOS で実行します。

```
EVASD MOVIE.EVA      V9958
EV9SD MOVIE.EV9      V9990
EV6SD MOVIE.EV6      V9968 (映像は V9968 の HDMI 出力に出ます)
```

ESC で中断、STOP を押している間は一時停止です。

| オプション | 内容 |
|---|---|
| `/Sx` | x フレーム目から再生 (1 秒 = 約 12 フレーム) |
| `/Ex` | x フレーム目で終わる |
| `/Nx` | x フレーム分だけ再生 |
| `/Px` | x 回繰り返す (`/P0` で止めるまで繰り返す) |
| `/Ox` | パレットを書く時刻の調整 (EV9SD / EV6SD。0〜44、既定 22。普通は使わない) |
| `/O` `/H` `/W` | 古い形式の .EVA の大きさの指定 (EVASD。128x106 / 156x86 / 144x94。普通は自動で判定) |
| `/M` | 古い MegaFlashROM SCC+ SD 用の読み方を強制する (普通は自動で判定。下の「MegaFlashROM SCC+ SD について」)。EVASD には FW v3 より前の専用の `/M2` もある |

- **動画ファイルは、SD カード上で連続した場所 (連続したクラスタ) に置く必要があります。** フォーマット直後の SD カードにコピーするのが確実です
- 終了時に `timing violation count` が表示されたときは、SD カードの応答が間に合わなかった所があります (そこで音が乱れています)
- 元の EVASD 用の .EVA (128x106 / 156x86 など) も EVASD で再生できます

## MegaFlashROM SCC+ SD について

FW v3 より前の古い MegaFlashROM SCC+ SD は、SD カードの読み出しの間隔が短いと待ちを入れるので、そのままでは
1 フレームが長くなって、画面の途中で絵が切り替わる (ティアリング) ことがあります。プレーヤーは起動時に読み出しの速さを測り、
古い FW なら、待ちが入っても間に合う読み方に切り替えます。音も絵も、新しい FW と同じように再生できます。
このとき、終了時に次のように表示します (最後の数字は測った値)。

```
MegaSD (before FW v3) mode 2, SD timing:0254
```

Nextor 3 の MegaFlashROM SCC+ SD ドライバは、版によって SD スロットのデバイス番号が違います (v1.6 以前と v1.7 以降)。
プレーヤーはドライバの名前と版を見て、正しいスロットを選びます。

## V9968 について

- V9968 カートリッジは I/O 88h (スイッチ左) で使います。本体の画面には起動時のメッセージだけが出ます
- SCREEN8 + 拡張パレット (32768 色中 256 色)。1 フレームで書き換える色は 80 色までで、場面が切り替わると、色が 3〜4 フレームに分けて入れ替わります
- V9968 は本体と別の発振器で動くので、プレーヤーが垂直帰線を見て、音のサンプルを時々 1 つ足し引きしてずれを合わせます
- 音は turboR 本体の PCM から出ます (V9968 の HDMI 出力には音が乗りません)

## ライセンスとクレジット

- 元の EVASD: d4.princess.ne.jp。この版: Lefty Serve
- 変換プログラム (`WIN\EVACONV\EVACONV.exe`) は Nuitka で作った EXE で、Python、numpy、Pillow を含んでいます。
  それぞれのライセンス文は `WIN\EVACONV\LICENSES` にあります (一覧は `LICENSES\README.txt`)。ffmpeg は含んでいません
- MegaFlashROM SCC+ SD の読み出しのタイミングは、Manuel Pazos 氏の資料と実機での確認によります
- V9968 は HRA! 氏の作品です
- 使用は自己責任でお願いします

## 履歴

| 版 | 日付 | 内容 |
|---|---|---|
| v0.10 | 2026-10-20 | 最初の公開版。V9958 / V9990 / V9968 の 3 種類のプレーヤーと変換プログラム (EXE)。古い MegaFlashROM SCC+ SD (FW v3 より前) への対応、Nextor 3 の MegaFlashROM SCC+ SD ドライバ (v1.6 以前 / v1.7 以降) への対応、EVASD の起動時に一瞬出ていた緑の線の修正 |
