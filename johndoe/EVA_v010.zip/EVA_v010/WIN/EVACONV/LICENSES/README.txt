﻿EVACONV.exe に含まれるほかの人のソフトと、そのライセンス

EVACONV.exe は Nuitka で作った EXE で、次のソフトを含んでいます。各ライセンス文はこのフォルダにあります。

  Python 3.14.5     Python_LICENSE.txt
                    PSF License。Windows 版に含まれる OpenSSL, libffi, bzip2, xz, zlib, expat などの
                    ライセンスも同じファイルの "Additional Conditions for this Windows binary build" にあります
  numpy 2.5.3       numpy\LICENSE.txt (BSD)。同梱の OpenBLAS, LAPACK などの分もこの中と numpy\ 以下にあります
  Pillow 12.3.0     Pillow\LICENSE (MIT-CMU)。同梱の libjpeg, libpng, libwebp, libavif などの分も同じファイルにあります
  Nuitka 4.2.2     Nuitka\ (AGPLv3 と、作った EXE に AGPL がかからないとする
                    Nuitka Runtime Library Exception (LICENSE-RUNTIME.txt))
  Microsoft Visual C++ の実行部分 (vcruntime140.dll など): Microsoft の再配布の許可による

ffmpeg / ffprobe は含んでいません (使う人が用意します)。

----------------------------------------------------------------------
Third-party software in EVACONV.exe and their licenses

EVACONV.exe is an EXE made with Nuitka and contains the following software. Their licenses are in this folder.

  Python 3.14.5     Python_LICENSE.txt
                    PSF License. The licenses of OpenSSL, libffi, bzip2, xz, zlib, expat etc. included in the
                    Windows build are in the same file, under "Additional Conditions for this Windows binary build"
  numpy 2.5.3       numpy\LICENSE.txt (BSD). Bundled OpenBLAS, LAPACK etc. are covered in it and under numpy\
  Pillow 12.3.0     Pillow\LICENSE (MIT-CMU). Bundled libjpeg, libpng, libwebp, libavif etc. are in the same file
  Nuitka 4.2.2     Nuitka\ (AGPLv3 with the Nuitka Runtime Library Exception (LICENSE-RUNTIME.txt),
                    which keeps the AGPL from applying to the generated EXE)
  Microsoft Visual C++ runtime (vcruntime140.dll etc.): redistributed under Microsoft's terms

ffmpeg / ffprobe are not included (the user installs them).
