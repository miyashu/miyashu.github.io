# EVASD / EV9SD / EV6SD - video players for SD cards (v0.10)

Players that stream video from an SD card on an MSX turboR at about 12 frames per second with PCM sound, and a video
converter for Windows. Three VDPs are supported: the built-in V9958, the V9990 (GFX9000 etc.) and HRA!'s V9968 cartridge.

Based on EVASD (ESE Video Authorizer) from d4.princess.ne.jp. This edition was modified by Lefty Serve: V9990 and V9968
players, rebuilt sound timing, support for older MegaFlashROM SCC+ SD cartridges, and more.

## Requirements

| | |
|---|---|
| MSX | MSX turboR (runs in Z80 mode), Nextor |
| SD card | ESE-SDisk, or MegaFlashROM SCC+ SD (also with a FW older than v3) |
| VDP | built-in V9958 (EVASD), V9990 cartridge (EV9SD), V9968 cartridge at I/O 88h (EV6SD) |
| PC | Windows 10 / 11, ffmpeg and ffprobe on the PATH (they must run from the command prompt). No Python needed |

## Package contents

| File | Contents |
|---|---|
| `MSX\EVASD.COM` | plays .EVA on the built-in V9958 (SCREEN12 / SCREEN8) |
| `MSX\EV9SD.COM` | plays .EV9 on a V9990 (64 colours) |
| `MSX\EV6SD.COM` | plays .EV6 on a V9968 at I/O 88h (SCREEN8 + extended palette, 256 colours) |
| `WIN\EVACONV.BAT` | video -> .EVA (V9958 SCREEN12). Drag and drop video files onto it |
| `WIN\EVA8CONV.BAT` | video -> .EVA (V9958 SCREEN8) |
| `WIN\EV9CONV.BAT` | video -> .EV9 (V9990) |
| `WIN\EV6CONV.BAT` | video -> .EV6 (V9968) |
| `WIN\EVACONV\` | the converter (EVACONV.exe and its DLLs; keep the whole folder in this place) |
| `WIN\EVACONV\LICENSES\` | licenses of the third-party software in the converter |

## 1. Converting (Windows)

Drag and drop video files onto the batch file for the format you want (`EV6CONV.BAT` etc.). Several files can be dropped
at once. The output is written next to each video, with the same name.

- The aspect ratio is detected automatically: 4:3 becomes 124x108 dots, 16:9 becomes 144x93
- Converting takes about 2-3 minutes per minute of video for V9968 / V9990 (V9958 is faster)
- MSX-DOS needs 8.3 file names (up to 8 letters and digits). Rename long names afterwards, or use `-o` below
- The converter's progress messages are in Japanese (sorry). The last line shows the output file name

To use options, run EVACONV.exe from the command prompt:

```
WIN\EVACONV\EVACONV.exe ev6 MOVIE.mp4 -o MOVIE          output name MOVIE.EV6
WIN\EVACONV\EVACONV.exe ev6 MOVIE.mp4 --ss 60 -t 30     30 seconds from 60 s
WIN\EVACONV\EVACONV.exe ev6 MOVIE.mp4 --autocrop        remove burnt-in black bars
WIN\EVACONV\EVACONV.exe ev6 -h                          list of options
```

Formats: `eva` = V9958 SCREEN12, `eva8` = V9958 SCREEN8, `ev9` = V9990, `ev6` = V9968.

## 2. Playing (MSX turboR)

Copy a player and the converted files to the SD card and run from MSX-DOS:

```
EVASD MOVIE.EVA      V9958
EV9SD MOVIE.EV9      V9990
EV6SD MOVIE.EV6      V9968 (the picture appears on the V9968's HDMI output)
```

ESC stops, holding STOP pauses.

| Option | Meaning |
|---|---|
| `/Sx` | start at frame x (1 second = about 12 frames) |
| `/Ex` | end at frame x |
| `/Nx` | play x frames |
| `/Px` | repeat x times (`/P0` repeats until stopped) |
| `/Ox` | palette write timing (EV9SD / EV6SD, 0-44, default 22; normally not needed) |
| `/O` `/H` `/W` | size of an old-format .EVA (EVASD: 128x106 / 156x86 / 144x94; normally detected automatically) |
| `/M` | force the reading mode for older MegaFlashROM SCC+ SD cartridges (normally detected automatically; see below). EVASD also has `/M2`, for pre-v3 FW only |

- **The video file must be stored in consecutive clusters on the SD card.** Copying it to a freshly formatted card is the safest way
- If `timing violation count` is shown at the end, the SD card answered too late somewhere (the sound is disturbed there)
- EVASD also plays .EVA files made for the original EVASD (128x106, 156x86 etc.)

## MegaFlashROM SCC+ SD

On a MegaFlashROM SCC+ SD with a FW older than v3, the SD interface inserts waits when reads are close together, so frames
became longer and the picture could change in the middle of the screen (tearing). The players measure the read speed at
startup and, on an older FW, switch to a way of reading that keeps the timing even with the waits. Sound and picture play
the same as on the new FW. In this mode the player shows at the end (the last number is the measured value):

```
MegaSD (before FW v3) mode 2, SD timing:0254
```

The Nextor 3 drivers for the MegaFlashROM SCC+ SD number the SD slots differently by version (v1.6 and older, v1.7 and
newer). The players read the driver name and version and choose the right slot.

## About the V9968

- Use the V9968 cartridge at I/O 88h (switch to the left). The MSX screen only shows the startup messages
- SCREEN8 with the extended palette (256 of 32768 colours). Up to 80 colours are changed per frame, so on a scene change the colours are replaced over 3-4 frames
- The V9968 runs on its own oscillator, so the player watches its vertical blanking and occasionally adds or drops one sound sample to stay in step
- Sound comes from the turboR's built-in PCM (the V9968's HDMI output has no sound)

## Licenses and credits

- Original EVASD: d4.princess.ne.jp. This edition: Lefty Serve
- The converter (`WIN\EVACONV\EVACONV.exe`) is an EXE made with Nuitka and contains Python, numpy and Pillow. Their licenses
  are in `WIN\EVACONV\LICENSES` (see `LICENSES\README.txt` for the list). ffmpeg is not included
- The MegaFlashROM SCC+ SD read timing is based on notes and real-hardware tests by Manuel Pazos
- The V9968 is HRA!'s work
- Use at your own risk

## History

| Version | Date | Changes |
|---|---|---|
| v0.10 | 2026-10-20 | First public release. Players for V9958 / V9990 / V9968 and the converter (EXE). Support for older MegaFlashROM SCC+ SD (FW before v3) and for the Nextor 3 MegaFlashROM SCC+ SD drivers (v1.6 and older / v1.7 and newer). Fixed a green line that flashed when EVASD started |
