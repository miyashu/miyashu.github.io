NM (Next Maintenance)
A two-screen file maintenance tool for MSX-DOS2 and Nextor

Evaluation version. Parts of it are not fully tested: back up important
disks before you try anything that writes to them.


Files
-----
NM\             copy everything in this folder into one directory of the
                MSX disk, then type NM
  NM.COM        the program
  NM.OVL        the rest of the program (must come from the same package)
  NMFONT.DAT    8-dot kanji font   (not needed without kanji, see below)
  NMUNI.DAT     Unicode table      (not needed without kanji, see below)
  NMCFG.DAT     sample settings (every line is a comment)

MANUAL_en.md / .pdf        the manual (English)
MM-COMPARE_en.md / .pdf    comparison with MultiMente (English)
MANUAL.md / .pdf           the manual (Japanese)
MM-COMPARE.md / .pdf       comparison with MultiMente (Japanese)
VERSION.TXT                version, build number and file sizes


Needs
-----
MSX2 or later with 128 KB of VRAM and 128 KB or more of mapper RAM,
MSX-DOS2 or Nextor. It does not run on MSX-DOS1.


Without kanji (ANK mode)
------------------------
NM can show Japanese full-width characters, but it does not have to.
On a machine that is not a Japanese model it starts in ANK mode by itself.
On a Japanese machine, put this line into NMCFG.DAT:

    KANJI = OFF

In ANK mode NMFONT.DAT and NMUNI.DAT are not used: NM.COM and NM.OVL are
enough. The title at the top left shows which mode is running: it ends
in "_A" in ANK mode and in "_K" in kanji mode.

If a key does not do what the manual says on your keyboard, see KEYMAP in
chapter 9 of the manual. NM's own messages are in English.


Settings of MultiMente
----------------------
NM's keys follow MultiMente (MM, by MOGU), and MM's settings work as they
are: NM reads MM's MMRET.DAT (commands per extension) and MMMCR.DAT (key
macros), and lines of MM.CFG can be copied into NMCFG.DAT. They are not in
this package. MultiMente can be downloaded from the GIGAMIX site:

    https://www.gigamix.jp/

No program or file of MultiMente is used in NM or included here.


Credits
-------
NMFONT.DAT is converted from the Misaki font by Num Kadoma.
    https://littlelimit.net/misaki.htm
Reading the View font follows "Let's use View font" by A to C.
    http://www.yo.rim.or.jp/~anaka/AtoC/index32.htm

Unofficial software. Use it at your own risk.
