#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sform16_007.py  -  MEGA-SCSI 用 FAT16 マルチパーティション・フォーマッタ
                   (SFORM-2 0.07互換方式 / spec2 ベース + 拡張機能)

使い方の例:
  python sform16_007.py --list                              # ディスク一覧(Windows, 管理者)
  python sform16_007.py --disk 2 --size 512M                # 物理ディスク2をフォーマット
  python sform16_007.py --disk 2 --size 1G --dry-run        # 計画表示のみ(書き込みなし)
  python sform16_007.py --disk 2 --inspect                  # 既存の構造を解析して表示
  python sform16_007.py --image t.img --image-size 1GB --size 512M   # イメージファイルで試験
  python sform16_007.py --image t.img --inspect

仕様書(0.07互換版)からの追加・変更点:
  * 対象容量の制限: 32MiB 以下 / 32GiB 超 は中止
  * --size で 512MiB / 1GiB / 2GiB を選択。合計は 2GiB まで。
    残りが 32MiB 以下ならパーティションを追加しない。
  * sectors/cluster はパーティション容量から自動選択(FAT16 のクラスタ数
    上限 65524 に収まる最小値: 16 → 32 → 64)。2GiB 指定時は FAT16 の上限に
    合わせて 223 セクタ短くなる。
  * 既定で MEGASCSI.TBL のクラスタ2を FAT 上で使用中(EOC)にする
    (--no-protect-tbl で仕様書どおり未使用のままにできる)。
  * パーティションが1個だけの場合は MEGASCSI.TBL を作成しない
    (ルートディレクトリは空、FAT は F0 FF FF FF のみ、クラスタ2先頭はゼロ消去)。
"""
from __future__ import annotations

import argparse
import os
import struct
import sys
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple

# 直接実行時(__main__)に write_physical_007 から "import sform16_007" されても
# 同じモジュール(=同じ SformError クラス)を参照させる
if __name__ == "__main__":
    sys.modules.setdefault("sform16_007", sys.modules[__name__])

# ---------------------------------------------------------------------------
# 定数
# ---------------------------------------------------------------------------
SECTOR_SIZE = 512
KiB = 1024
MiB = 1024 * KiB
GiB = 1024 * MiB

MIN_DEVICE_BYTES = 32 * MiB          # これ「以下」は対象外
MAX_DEVICE_BYTES = 32 * GiB          # これ「より大きい」は対象外 (32GiB = 34,359,738,368 byte)
MAX_TOTAL_BYTES = 2 * GiB            # パーティション合計の上限
MIN_EXTRA_PART_BYTES = 32 * MiB      # 残りがこれ以下なら追加しない

PART_SIZE_CHOICES = {"512M": 512 * MiB, "1G": 1 * GiB, "2G": 2 * GiB}

RESERVED_SECTORS = 1
NUM_FATS = 2
ROOT_ENTRIES = 512
ROOT_DIR_SECTORS = ROOT_ENTRIES * 32 // SECTOR_SIZE   # 32
MEDIA_ID = 0xF0
FAT16_MIN_CLUSTERS = 4085
FAT16_MAX_CLUSTERS = 65524
SPC_AUTO = (16, 32, 64)
CAP_TOLERANCE_SECTORS = 2048         # FAT16上限による切り詰めは 1MiB までを許容

MAX_PARTITIONS = 16                  # ファームウェアのドライブ登録上限に合わせる
TBL_RECORDS = 32
TBL_MAX_24BIT = 0xFFFFFF

BOOT_PROGRAM = bytes.fromhex("""
d0 ed 53 70 c0 32 7a c0 36 6d 23 36 c0 31 1f f5 11 b4 c0 0e 0f cd 7d f3
b7 20 28 11 00 01 0e 1a cd 7d f3 21 01 00 22 c2 c0 21 00 3f 11 b4 c0 0e
27 cd 7d f3 c3 00 01 6f c0 cd 00 00 79 e6 fe fe 02 20 06 3e 00 b7 ca 22
40 11 8e c0 0e 09 cd 7d f3 0e 07 cd 7d f3 18 b5 42 6f 6f 74 20 65 72 72
6f 72 0d 0a 50 72 65 73 73 20 61 6e 79 20 6b 65 79 20 66 6f 72 20 72 65
74 72 79 0d 0a 24 00 4d 53 58 44 4f 53 20 20 53 59 53
""")
assert len(BOOT_PROGRAM) == 138


class SformError(Exception):
    """ユーザーに表示して中止すべきエラー"""


class WriteProtectError(SformError):
    """SD カードが書込禁止(ライトプロテクト)状態"""


WRITE_PROTECT_ADVICE = """\
----------------------------------------------------------------------
SD カードのライトプロテクト(書込禁止)スイッチを確認してください。

  1. カードをリーダーから抜く
  2. カード側面のスイッチを「LOCK」と反対側(書込可能側)へ動かす
  3. カードを差し直して、本プログラムを再度実行する

※ microSD 変換アダプタを使っている場合は、アダプタ側のスイッチを確認
   してください。スイッチが正しいのに解消しない場合は、カードや
   リーダーの故障も考えられるので、別のリーダーで試してください。
----------------------------------------------------------------------"""


class DiskAccessError(SformError):
    """ボリュームのロック失敗・書込拒否など。SD Card Formatter での初期化を案内する"""


SD_FORMATTER_ADVICE = """\
----------------------------------------------------------------------
Windows が SD カード上のボリュームを使用中のため、書き込みできませんでした。
(以前 SFORM16 で複数パーティションを作成したカードで起きやすい現象です)

次の手順でカードを初期化してから、再度実行してください。

  1. SD Association 公式の「SD Card Formatter」でカードをフォーマットする
       https://www.sdcard.org/downloads/formatter/
     (対象カードを選び「クイックフォーマット」で可。
      ドライブの選択を間違えないよう注意してください)
  2. カードを一度抜き差しする
  3. 本プログラムを再度実行する

※ 簡易な対処として、カード内を開いているエクスプローラ等を閉じ、
   カードを抜き差ししてから再実行すると成功する場合もあります。
----------------------------------------------------------------------"""


# ---------------------------------------------------------------------------
# 容量・計画
# ---------------------------------------------------------------------------
@dataclass
class Partition:
    index: int
    lba: int          # 絶対開始LBA
    sectors: int      # 総セクタ数
    spc: int          # sectors/cluster
    spf: int          # sectors/FAT
    clusters: int

    @property
    def fat1_lba(self) -> int:
        return self.lba + RESERVED_SECTORS

    @property
    def fat2_lba(self) -> int:
        return self.fat1_lba + self.spf

    @property
    def root_lba(self) -> int:
        return self.lba + RESERVED_SECTORS + NUM_FATS * self.spf

    @property
    def data_lba(self) -> int:          # = クラスタ2
        return self.root_lba + ROOT_DIR_SECTORS

    @property
    def end_lba(self) -> int:
        return self.lba + self.sectors


def fat16_geometry(total_sectors: int, spc: int) -> Tuple[int, int]:
    """(sectors/FAT, クラスタ数) を返す。"""
    spf = 1
    while True:
        data = total_sectors - RESERVED_SECTORS - NUM_FATS * spf - ROOT_DIR_SECTORS
        if data < spc:
            return spf, 0
        clusters = data // spc
        need = -(-((clusters + 2) * 2) // SECTOR_SIZE)
        if need <= spf:
            return spf, clusters
        spf = need


def max_fat16_sectors(spc: int) -> int:
    spf = -(-((FAT16_MAX_CLUSTERS + 2) * 2) // SECTOR_SIZE)
    return RESERVED_SECTORS + NUM_FATS * spf + ROOT_DIR_SECTORS + FAT16_MAX_CLUSTERS * spc


def fit_partition(sectors: int, forced_spc: Optional[int]) -> Tuple[int, int, int, int]:
    """指定セクタ数に FAT16 を割り当てる。(sectors, spc, spf, clusters)"""
    cands = (forced_spc,) if forced_spc else SPC_AUTO
    for spc in cands:
        spf, cl = fat16_geometry(sectors, spc)
        if cl > FAT16_MAX_CLUSTERS:
            continue
        if cl < FAT16_MIN_CLUSTERS:
            raise SformError(
                f"{sectors} セクタのパーティションでは sectors/cluster={spc} だと "
                f"クラスタ数が {cl} となり FAT16 の下限 {FAT16_MIN_CLUSTERS} を下回ります。"
                " --cluster auto を使ってください。")
        return sectors, spc, spf, cl
    # どのクラスタサイズでも上限超過 → 最大のクラスタサイズで上限まで切り詰める
    spc = cands[-1]
    cap = max_fat16_sectors(spc)
    if sectors - cap > CAP_TOLERANCE_SECTORS:
        raise SformError(
            f"sectors/cluster={spc} では FAT16 の上限({cap} セクタ)を大きく超えます。"
            " --cluster auto か、より大きなクラスタサイズを指定してください。")
    spf, cl = fat16_geometry(cap, spc)
    return cap, spc, spf, cl


def check_device_capacity(device_bytes: int) -> None:
    if device_bytes > MAX_DEVICE_BYTES:
        raise SformError(
            f"物理容量 {fmt_bytes(device_bytes)} は 32GiB を超えています。"
            " 本プログラムの対象は 32GiB 以下の SD カードです。中止します。")
    if device_bytes <= MIN_DEVICE_BYTES:
        raise SformError(
            f"物理容量 {fmt_bytes(device_bytes)} は 32MiB 以下のため対象外です。中止します。")


def plan_partitions(device_sectors: int, part_bytes: int,
                    forced_spc: Optional[int] = None,
                    max_partitions: int = MAX_PARTITIONS) -> List[Partition]:
    budget = min(device_sectors, MAX_TOTAL_BYTES // SECTOR_SIZE)
    target = part_bytes // SECTOR_SIZE
    min_extra = MIN_EXTRA_PART_BYTES // SECTOR_SIZE
    plan: List[Partition] = []
    lba = 0
    while budget - lba > min_extra and len(plan) < max_partitions:
        want = min(target, budget - lba)
        size, spc, spf, cl = fit_partition(want, forced_spc)
        plan.append(Partition(len(plan), lba, size, spc, spf, cl))
        lba += size
    if not plan:
        raise SformError("作成できるパーティションがありません。")
    if len(plan) + 1 > TBL_RECORDS:
        raise SformError("MEGASCSI.TBL のレコード数(32)を超えます。")
    return plan


# ---------------------------------------------------------------------------
# セクタ生成
# ---------------------------------------------------------------------------
@dataclass
class BuildOptions:
    oem: bytes = b"SFRM16  "
    serial_base: int = 0
    disk_signature: bytes = b"\0\0\0\0"
    protect_tbl: bool = True
    tbl_end: str = "device"      # "device" | "used"
    clear_tail: bool = True


def mbr_entry(ptype: int, start: int, size: int) -> bytes:
    e = bytearray(16)
    e[4] = ptype
    struct.pack_into("<II", e, 8, start, size)
    return bytes(e)


def build_boot_sector(plan: List[Partition], i: int, opt: BuildOptions) -> bytes:
    p = plan[i]
    b = bytearray(SECTOR_SIZE)
    b[0:3] = b"\xEB\xFE\x90"
    b[3:11] = opt.oem
    struct.pack_into("<HBHBHHBHHHH", b, 0x0B,
                     SECTOR_SIZE, p.spc, RESERVED_SECTORS, NUM_FATS, ROOT_ENTRIES,
                     0, MEDIA_ID, p.spf, 0, 0, 0)
    b[0x1E:0x20] = b"\x18\x1E"
    struct.pack_into("<IBBBI", b, 0x20, p.sectors, 0, 0, 0x29,
                     (opt.serial_base + i) & 0xFFFFFFFF)
    b[0x2B:0x36] = b"NO NAME    "
    b[0x36:0x3E] = b"FAT16   "
    b[0x3E:0x3E + len(BOOT_PROGRAM)] = BOOT_PROGRAM
    if i == 0:
        b[0x1B8:0x1BC] = opt.disk_signature
    # エントリ1: 自分自身(常に開始LBA=0)
    b[0x1BE:0x1CE] = mbr_entry(0x06, 0, p.sectors)
    # エントリ2: 次のパーティション(基準は常にパーティション1)
    if i < len(plan) - 1:
        chain_start = plan[1].lba
        nxt = plan[i + 1].lba
        start = chain_start if i == 0 else nxt - chain_start
        b[0x1CE:0x1DE] = mbr_entry(0x05, start, 0)
    b[0x1FE:0x200] = b"\x55\xAA"
    return bytes(b)


def tbl_terminator_start(plan: List[Partition], device_sectors: int,
                         opt: BuildOptions) -> Tuple[int, Optional[str]]:
    if opt.tbl_end == "used":
        return plan[-1].end_lba, None
    if device_sectors > TBL_MAX_24BIT:
        return TBL_MAX_24BIT, (
            f"デバイス総セクタ数 {device_sectors} は MEGASCSI.TBL の 3byte フィールドに"
            f"収まらないため、終端レコードの開始値を 0xFFFFFF にしました"
            "(--tbl-end used で最終パーティション末尾を使うこともできます)。")
    return device_sectors, None


def build_tbl(plan: List[Partition], term_start: int) -> bytes:
    t = bytearray(SECTOR_SIZE)
    n = len(plan)
    for i, p in enumerate(plan):
        r = 16 * i
        t[r + 0] = 0
        t[r + 1] = 0
        t[r + 2:r + 5] = p.lba.to_bytes(3, "big")
        t[r + 5:r + 8] = p.sectors.to_bytes(3, "big")
        t[r + 8:r + 10] = SECTOR_SIZE.to_bytes(2, "big")
    r = 16 * n
    t[r + 2:r + 5] = term_start.to_bytes(3, "big")
    t[r + 5:r + 8] = b"\xFF\xFF\xFF"
    t[r + 8:r + 10] = b"\x00\x00"
    t[r + 10:r + 16] = b"\x00\x00\xFF\xFF\xFF\xFF"
    for off in range(16 * (n + 1), SECTOR_SIZE, 8):
        t[off:off + 8] = b"\x00\x00\x00\x00\xFF\xFF\xFF\xFF"
    return bytes(t)


def build_dir_entry(n_parts: int) -> bytes:
    d = bytearray(32)
    d[0:11] = b"MEGASCSITBL"
    d[0x0B] = 0x27
    struct.pack_into("<H", d, 0x1A, 2)
    struct.pack_into("<I", d, 0x1C, n_parts * 16)
    return bytes(d)


def build_writes(plan: List[Partition], device_sectors: int,
                 opt: BuildOptions) -> Tuple[List[Tuple[int, bytes, str]], List[str]]:
    """(LBA, データ, 説明) のリストと警告メッセージを返す。"""
    warnings: List[str] = []
    make_tbl = len(plan) > 1          # パーティション1個なら MEGASCSI.TBL を作らない
    if make_tbl:
        term, w = tbl_terminator_start(plan, device_sectors, opt)
        if w:
            warnings.append(w)
        tbl = build_tbl(plan, term)
        root = build_dir_entry(len(plan)) + bytes(ROOT_DIR_SECTORS * SECTOR_SIZE - 32)
        fat_head = b"\xF0\xFF\xFF\xFF" + (b"\xFF\xFF" if opt.protect_tbl else b"\x00\x00")
    else:
        warnings.append("パーティションが1個のため MEGASCSI.TBL は作成しません。")
        tbl = bytes(SECTOR_SIZE)      # 旧フォーマットの TBL が残らないようゼロ消去
        root = bytes(ROOT_DIR_SECTORS * SECTOR_SIZE)
        fat_head = b"\xF0\xFF\xFF\xFF"

    writes: List[Tuple[int, bytes, str]] = []
    for i, p in enumerate(plan):
        fat = fat_head + bytes(p.spf * SECTOR_SIZE - len(fat_head))
        writes.append((p.lba, build_boot_sector(plan, i, opt), f"P{i} ブートセクタ"))
        writes.append((p.fat1_lba, fat, f"P{i} FAT#1"))
        writes.append((p.fat2_lba, fat, f"P{i} FAT#2"))
        writes.append((p.root_lba, root, f"P{i} ルートディレクトリ"))
        writes.append((p.data_lba, tbl,
                       f"P{i} MEGASCSI.TBL" if make_tbl else f"P{i} クラスタ2 消去"))

    if opt.clear_tail:
        used_end = plan[-1].end_lba
        start = max(used_end, device_sectors - 34)   # GPTのバックアップ領域(末尾33セクタ)
        if device_sectors > start:
            writes.append((start, bytes((device_sectors - start) * SECTOR_SIZE),
                           "デバイス末尾(旧GPTバックアップ)消去"))
    return writes, warnings


# ---------------------------------------------------------------------------
# デバイス(イメージファイル)
# ---------------------------------------------------------------------------
class ImageDevice:
    def __init__(self, path: str, size_bytes: Optional[int] = None, writable: bool = True):
        self.path = path
        if size_bytes is not None:
            with open(path, "wb") as f:
                f.truncate(size_bytes)          # スパースファイル
        if not os.path.exists(path):
            raise SformError(f"イメージファイル {path} がありません(--image-size で作成できます)。")
        self.f = open(path, "r+b" if writable else "rb")
        self.f.seek(0, 2)
        self.size_bytes = self.f.tell()
        self.description = f"イメージファイル {path}"

    def read(self, lba: int, count: int) -> bytes:
        self.f.seek(lba * SECTOR_SIZE)
        data = self.f.read(count * SECTOR_SIZE)
        return data + bytes(count * SECTOR_SIZE - len(data))

    def write(self, lba: int, data: bytes) -> None:
        self.f.seek(lba * SECTOR_SIZE)
        self.f.write(data)

    def flush(self) -> None:
        self.f.flush()
        os.fsync(self.f.fileno())

    def close(self) -> None:
        self.f.close()


# ---------------------------------------------------------------------------
# 表示
# ---------------------------------------------------------------------------
def fmt_bytes(n: int) -> str:
    if n >= GiB:
        s = f"{n / GiB:.2f} GiB"
    elif n >= MiB:
        s = f"{n / MiB:.2f} MiB"
    else:
        s = f"{n / KiB:.1f} KiB"
    return f"{n:,} byte ({s})"


def print_plan(plan: List[Partition], device_sectors: int, part_bytes: int) -> None:
    print(f"デバイス容量       : {fmt_bytes(device_sectors * SECTOR_SIZE)} / {device_sectors:,} セクタ")
    print(f"指定パーティション : {part_bytes // MiB} MiB   (合計上限 {MAX_TOTAL_BYTES // MiB} MiB)")
    print()
    print(" No  開始LBA      セクタ数     容量          クラスタ  sec/FAT  クラスタ数")
    print(" --  -----------  -----------  ------------  --------  -------  ----------")
    for p in plan:
        print(f" {p.index:2d}  {p.lba:11,d}  {p.sectors:11,d}  "
              f"{p.sectors * SECTOR_SIZE / MiB:9.2f} MiB  {p.spc * SECTOR_SIZE // KiB:5d} KB  "
              f"{p.spf:7d}  {p.clusters:10,d}")
    used = plan[-1].end_lba
    print(f"\n 合計 {len(plan)} 個 / {used * SECTOR_SIZE / MiB:.2f} MiB 使用、"
          f"未使用 {(device_sectors - used) * SECTOR_SIZE / MiB:.2f} MiB")


# ---------------------------------------------------------------------------
# 解析 (--inspect)
# ---------------------------------------------------------------------------
def inspect_device(dev) -> int:
    """既存の構造を解析して表示する。問題数を返す。"""
    problems = 0

    def bad(msg):
        nonlocal problems
        problems += 1
        print(f"   !! {msg}")

    total_sectors = dev.size_bytes // SECTOR_SIZE
    print(f"対象: {dev.description}  {fmt_bytes(dev.size_bytes)}")
    s0 = dev.read(0, 1)
    if s0[0x1FE:0x200] != b"\x55\xAA":
        print("Sector0 にブートシグネチャ 55 AA がありません。SFORM16 形式ではありません。")
        return 1

    parts = []   # (lba, sector bytes)
    parts.append((0, s0))
    t2 = s0[0x1CE + 4]
    chain_start = struct.unpack_from("<I", s0, 0x1CE + 8)[0] if t2 == 0x05 else None
    lba = chain_start
    guard = 0
    while lba is not None and guard < 64:
        guard += 1
        if lba >= total_sectors:
            bad(f"チェーン先 LBA {lba} がデバイス外です。")
            break
        s = dev.read(lba, 1)
        parts.append((lba, s))
        if s[0x1CE + 4] == 0x05:
            lba = chain_start + struct.unpack_from("<I", s, 0x1CE + 8)[0]
        else:
            lba = None

    tbls = []
    print(f"\nパーティション数: {len(parts)}  (チェーン基準 LBA = {chain_start})\n")
    for i, (plba, s) in enumerate(parts):
        bps, spc, res, nf, rootent, tot16, media, spf = struct.unpack_from("<HBHBHHBH", s, 0x0B)
        tot32 = struct.unpack_from("<I", s, 0x20)[0]
        e1type = s[0x1BE + 4]
        e1start, e1size = struct.unpack_from("<II", s, 0x1BE + 8)
        e2type = s[0x1CE + 4]
        e2start = struct.unpack_from("<I", s, 0x1CE + 8)[0]
        total = tot32 if tot16 == 0 else tot16
        root_sec = rootent * 32 // max(bps, 1)
        data = total - res - nf * spf - root_sec
        clusters = data // spc if spc else 0
        print(f"[P{i}] LBA {plba:,}  {total:,} セクタ ({total * 512 / MiB:.2f} MiB)  "
              f"spc={spc} spf={spf} clusters={clusters:,} media=0x{media:02X}  "
              f"OEM={s[3:11].decode('ascii', 'replace')!r}")
        print(f"      エントリ1 type=0x{e1type:02X} start={e1start} size={e1size:,}   "
              f"エントリ2 type=0x{e2type:02X} start={e2start:,}")
        if s[0:3] != b"\xEB\xFE\x90":
            bad("ジャンプ命令が EB FE 90 ではありません。")
        if s[0x3E:0x3E + 138] != BOOT_PROGRAM:
            bad("ブートプログラムが一致しません。")
        if s[0x36:0x3E] != b"FAT16   ":
            bad("FSタイプ文字列が 'FAT16   ' ではありません。")
        if e1type != 0x06 or e1start != 0 or e1size != total:
            bad("エントリ1が規則(type=06, start=0, size=自分自身)に合いません。")
        if media != MEDIA_ID:
            bad("メディアIDが 0xF0 ではありません。")
        if not (FAT16_MIN_CLUSTERS <= clusters <= FAT16_MAX_CLUSTERS):
            bad(f"クラスタ数 {clusters} が FAT16 の範囲外です。")
        if i > 0 and s[0x1B8:0x1BC] != b"\0\0\0\0":
            bad("Sector0 以外でディスクシグネチャが非ゼロです。")
        fat = dev.read(plba + res, 1)
        if fat[0:4] != b"\xF0\xFF\xFF\xFF":
            bad("FAT 先頭 4byte が F0 FF FF FF ではありません。")
        e2 = struct.unpack_from("<H", fat, 4)[0]
        print(f"      FAT entry2(クラスタ2) = 0x{e2:04X} "
              f"({'保護(EOC)' if e2 >= 0xFFF8 else '未使用' if e2 == 0 else '使用中/不明'})")
        rd = dev.read(plba + res + nf * spf, 1)
        if len(parts) == 1:
            if rd[0:11] == b"MEGASCSITBL":
                print("      (パーティション1個だが MEGASCSI.TBL が存在します)")
        elif rd[0:11] != b"MEGASCSITBL":
            bad("ルートディレクトリ先頭が MEGASCSITBL ではありません(上書きされた可能性)。")
        tbls.append(dev.read(plba + res + nf * spf + root_sec, 1))

    if len(parts) == 1:
        print("\nMEGASCSI.TBL: なし(パーティション1個のため)")
        print(f"\n解析結果: {'問題なし' if problems == 0 else f'{problems} 件の問題'}")
        return problems
    print("\nMEGASCSI.TBL (P0 のクラスタ2):")
    t = tbls[0]
    for r in range(TBL_RECORDS):
        rec = t[16 * r:16 * r + 16]
        st = int.from_bytes(rec[2:5], "big")
        sz = int.from_bytes(rec[5:8], "big")
        bl = int.from_bytes(rec[8:10], "big")
        if sz == 0xFFFFFF:
            print(f"   #{r:2d} 終端マーカー start={st:,}")
            break
        print(f"   #{r:2d} type={rec[0]} flag=0x{rec[1]:02X} start={st:,} size={sz:,} blk={bl}")
        if r < len(parts) and (st != parts[r][0]):
            bad(f"TBL レコード{r} の開始LBAが実パーティションと一致しません。")
    for i, tb in enumerate(tbls[1:], 1):
        if tb != t:
            bad(f"P{i} の MEGASCSI.TBL が P0 と一致しません。")
    print(f"\n解析結果: {'問題なし' if problems == 0 else f'{problems} 件の問題'}")
    return problems


# ---------------------------------------------------------------------------
# 実行
# ---------------------------------------------------------------------------
def execute_writes(dev, writes, verify: bool) -> None:
    for n, (lba, data, desc) in enumerate(writes, 1):
        print(f"  書込 [{n:2d}/{len(writes)}] LBA {lba:>10,}  {len(data) // 512:5d} セクタ  {desc}")
        try:
            dev.write(lba, data)
        except DiskAccessError as e:
            e.wrote_nothing = (n == 1)
            raise
        except WriteProtectError:
            raise
        except SformError as e:
            # 一部のカードリーダーはライトプロテクトを「I/O デバイスエラー」(1117) で返す
            if n == 1 and getattr(e, "winerror", None) in (19, 1117):
                raise WriteProtectError(
                    f"最初のセクタに書き込めませんでした。ライトプロテクトされている"
                    f"可能性があります。({e})")
            raise
    dev.flush()
    if verify:
        print("  ベリファイ中...")
        for lba, data, desc in writes:
            if dev.read(lba, len(data) // SECTOR_SIZE) != data:
                raise SformError(f"ベリファイ失敗: LBA {lba} ({desc})")
        print("  ベリファイ OK")


def parse_part_size(s: str) -> str:
    k = s.strip().upper().replace("IB", "").replace("B", "")
    k = {"512": "512M", "512M": "512M", "1024M": "1G", "1G": "1G",
         "2048M": "2G", "2G": "2G"}.get(k)
    if not k:
        raise argparse.ArgumentTypeError("512M / 1G / 2G のいずれかを指定してください")
    return k


def parse_bytes(s: str) -> int:
    u = s.strip().upper()
    units = [("GIB", GiB), ("MIB", MiB), ("KIB", KiB), ("GB", 1000 ** 3),
             ("MB", 1000 ** 2), ("KB", 1000), ("G", GiB), ("M", MiB), ("K", KiB)]
    for suf, mul in units:
        if u.endswith(suf):
            return int(float(u[:-len(suf)]) * mul)
    return int(u)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="MEGA-SCSI 用 FAT16 フォーマッタ (SFORM-2 0.07互換)")
    tg = ap.add_mutually_exclusive_group(required=True)
    tg.add_argument("--list", action="store_true", help="物理ディスク一覧を表示 (Windows)")
    tg.add_argument("--disk", type=int, metavar="N", help=r"対象物理ディスク番号 (\\.\PhysicalDriveN)")
    tg.add_argument("--image", metavar="PATH", help="イメージファイルを対象にする(試験用)")
    ap.add_argument("--image-size", type=parse_bytes, metavar="SIZE",
                    help="イメージを新規作成する容量 (例 1GB, 4GiB, 31914983424)")
    ap.add_argument("--size", type=parse_part_size, metavar="{512M,1G,2G}",
                    help="1パーティションの容量")
    ap.add_argument("--inspect", action="store_true", help="既存の構造を解析して表示")
    ap.add_argument("--cluster", default="auto", choices=["auto", "16", "32", "64"],
                    help="sectors/cluster (既定 auto: 容量に応じ 16/32/64)")
    ap.add_argument("--no-protect-tbl", action="store_true",
                    help="MEGASCSI.TBL のクラスタ2を FAT 上で未使用のままにする(仕様書どおり)")
    ap.add_argument("--tbl-end", choices=["device", "used"], default="device",
                    help="TBL 終端レコードの開始値: device=デバイス総容量(既定), used=使用領域末尾")
    ap.add_argument("--no-clear-tail", action="store_true", help="デバイス末尾(旧GPT)を消去しない")
    ap.add_argument("--no-verify", action="store_true", help="書込後のベリファイを省略")
    ap.add_argument("--oem", default="SFRM16", help="OEM名 (8文字まで)")
    ap.add_argument("--serial", type=lambda x: int(x, 16), help="ボリュームシリアル基準値(16進)")
    ap.add_argument("--max-partitions", type=int, default=MAX_PARTITIONS)
    ap.add_argument("--dry-run", action="store_true", help="計画表示のみで書き込まない")
    ap.add_argument("--yes", action="store_true", help="確認入力を省略")
    ap.add_argument("--force", action="store_true", help="リムーバブル以外のディスクも許可(危険)")
    a = ap.parse_args(argv)

    try:
        if a.list:
            import write_physical_007 as wp
            wp.print_disk_list()
            return 0

        if a.disk is not None:
            import write_physical_007 as wp
            dev = wp.open_target_disk(a.disk, writable=not (a.inspect or a.dry_run),
                                      force=a.force)
        else:
            if a.image_size is not None and a.inspect:
                raise SformError("--inspect と --image-size は同時に指定できません。")
            dev = ImageDevice(a.image, a.image_size,
                              writable=not (a.inspect or a.dry_run))

        try:
            if a.inspect:
                return 0 if inspect_device(dev) == 0 else 2

            if not a.size:
                raise SformError("--size (512M / 1G / 2G) を指定してください。")
            check_device_capacity(dev.size_bytes)
            device_sectors = dev.size_bytes // SECTOR_SIZE
            part_bytes = PART_SIZE_CHOICES[a.size]
            spc = None if a.cluster == "auto" else int(a.cluster)
            plan = plan_partitions(device_sectors, part_bytes, spc, a.max_partitions)

            opt = BuildOptions(
                oem=a.oem.encode("ascii")[:8].ljust(8, b" "),
                serial_base=a.serial if a.serial is not None else int(time.time()) & 0xFFFFFFFF,
                disk_signature=os.urandom(4),
                protect_tbl=not a.no_protect_tbl,
                tbl_end=a.tbl_end,
                clear_tail=not a.no_clear_tail,
            )
            writes, warns = build_writes(plan, device_sectors, opt)

            print(f"対象: {dev.description}\n")
            print_plan(plan, device_sectors, part_bytes)
            for w in warns:
                print(f"\n注意: {w}")
            if a.dry_run:
                print("\n--dry-run のため書き込みは行いません。")
                return 0

            if not a.yes:
                key = str(a.disk) if a.disk is not None else "YES"
                print(f"\n★ 対象の内容はすべて失われます。続行するには {key!r} と入力してください: ",
                      end="", flush=True)
                if input().strip() != key:
                    print("中止しました。")
                    return 1

            if hasattr(dev, "prepare_for_write"):
                dev.prepare_for_write()      # ボリュームのロック/アンマウント
            print()
            execute_writes(dev, writes, verify=not a.no_verify)
            print("\n完了しました。")
            return 0
        finally:
            dev.close()
    except WriteProtectError as e:
        print(f"エラー: {e}", file=sys.stderr)
        print("(カードには何も書き込んでいません)", file=sys.stderr)
        print(WRITE_PROTECT_ADVICE, file=sys.stderr)
        return 1
    except DiskAccessError as e:
        print(f"エラー: {e}", file=sys.stderr)
        if getattr(e, "wrote_nothing", True):
            print("(カードにはまだ何も書き込んでいません)", file=sys.stderr)
        else:
            print("(書き込み途中で失敗したため、カードの構造は不完全な状態です)", file=sys.stderr)
        print(SD_FORMATTER_ADVICE, file=sys.stderr)
        return 1
    except SformError as e:
        print(f"エラー: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n中断しました。", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
