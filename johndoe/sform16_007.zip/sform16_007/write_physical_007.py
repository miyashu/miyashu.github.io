# -*- coding: utf-8 -*-
"""
write_physical_007.py  -  Windows 物理ディスクアクセス (sform16_007.py から使用)

* 管理者権限が必要
* 標準ライブラリ(ctypes)のみ使用
* 安全策:
    - システムドライブ(%SystemDrive%)を含むディスクは常に拒否
    - リムーバブル / USB / SD / MMC 以外は --force が無いと拒否
    - 書込前に対象ディスク上の全ボリュームをロック + アンマウント
"""
from __future__ import annotations

import ctypes
import os
import struct
import time
from ctypes import wintypes as wt

from sform16_007 import SformError, DiskAccessError, WriteProtectError, SECTOR_SIZE, fmt_bytes

if os.name != "nt":
    raise ImportError("write_physical_007 は Windows 専用です")

k32 = ctypes.WinDLL("kernel32", use_last_error=True)

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
FILE_SHARE_READ = 1
FILE_SHARE_WRITE = 2
OPEN_EXISTING = 3
FILE_FLAG_WRITE_THROUGH = 0x80000000
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

ERROR_ACCESS_DENIED = 5
ERROR_WRITE_PROTECT = 19
LOCK_RETRIES = 10
LOCK_RETRY_WAIT = 0.5   # 秒

IOCTL_DISK_GET_LENGTH_INFO = 0x0007405C
IOCTL_DISK_UPDATE_PROPERTIES = 0x00070140
IOCTL_DISK_IS_WRITABLE = 0x00070024
IOCTL_STORAGE_QUERY_PROPERTY = 0x002D1400
IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS = 0x00560000
FSCTL_LOCK_VOLUME = 0x00090018
FSCTL_UNLOCK_VOLUME = 0x0009001C
FSCTL_DISMOUNT_VOLUME = 0x00090020

BUS_TYPES = {1: "SCSI", 2: "ATAPI", 3: "ATA", 7: "USB", 8: "RAID", 0xA: "SAS",
             0xB: "SATA", 0xC: "SD", 0xD: "MMC", 0x11: "NVMe"}
SAFE_BUS = {7, 0xC, 0xD}

k32.CreateFileW.argtypes = [wt.LPCWSTR, wt.DWORD, wt.DWORD, wt.LPVOID, wt.DWORD, wt.DWORD, wt.HANDLE]
k32.CreateFileW.restype = wt.HANDLE
k32.DeviceIoControl.argtypes = [wt.HANDLE, wt.DWORD, wt.LPVOID, wt.DWORD, wt.LPVOID, wt.DWORD,
                                ctypes.POINTER(wt.DWORD), wt.LPVOID]
k32.DeviceIoControl.restype = wt.BOOL
k32.ReadFile.argtypes = [wt.HANDLE, wt.LPVOID, wt.DWORD, ctypes.POINTER(wt.DWORD), wt.LPVOID]
k32.ReadFile.restype = wt.BOOL
k32.WriteFile.argtypes = [wt.HANDLE, wt.LPVOID, wt.DWORD, ctypes.POINTER(wt.DWORD), wt.LPVOID]
k32.WriteFile.restype = wt.BOOL
k32.SetFilePointerEx.argtypes = [wt.HANDLE, ctypes.c_longlong, ctypes.POINTER(ctypes.c_longlong), wt.DWORD]
k32.SetFilePointerEx.restype = wt.BOOL
k32.FlushFileBuffers.argtypes = [wt.HANDLE]
k32.FlushFileBuffers.restype = wt.BOOL
k32.CloseHandle.argtypes = [wt.HANDLE]
k32.CloseHandle.restype = wt.BOOL
k32.FindFirstVolumeW.argtypes = [wt.LPWSTR, wt.DWORD]
k32.FindFirstVolumeW.restype = wt.HANDLE
k32.FindNextVolumeW.argtypes = [wt.HANDLE, wt.LPWSTR, wt.DWORD]
k32.FindNextVolumeW.restype = wt.BOOL
k32.FindVolumeClose.argtypes = [wt.HANDLE]
k32.GetVolumePathNamesForVolumeNameW.argtypes = [wt.LPCWSTR, wt.LPWSTR, wt.DWORD, ctypes.POINTER(wt.DWORD)]
k32.GetVolumePathNamesForVolumeNameW.restype = wt.BOOL


def _winerr(msg: str) -> SformError:
    code = ctypes.get_last_error()
    e = SformError(f"{msg}: {ctypes.FormatError(code).strip()} (エラー {code})")
    e.winerror = code
    return e


def _open(path: str, access: int, flags: int = 0) -> int:
    h = k32.CreateFileW(path, access, FILE_SHARE_READ | FILE_SHARE_WRITE, None,
                        OPEN_EXISTING, flags, None)
    if h is None or h == INVALID_HANDLE_VALUE:
        raise _winerr(f"{path} を開けません")
    return h


def _ioctl(h: int, code: int, inbuf: bytes = b"", outsize: int = 0) -> bytes:
    ib = ctypes.create_string_buffer(inbuf, len(inbuf)) if inbuf else None
    ob = ctypes.create_string_buffer(outsize) if outsize else None
    ret = wt.DWORD(0)
    if not k32.DeviceIoControl(h, code, ib, len(inbuf), ob, outsize, ctypes.byref(ret), None):
        raise _winerr(f"DeviceIoControl(0x{code:08X}) 失敗")
    return ob.raw[:ret.value] if ob else b""


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


# ---------------------------------------------------------------------------
# ボリューム列挙
# ---------------------------------------------------------------------------
def iter_volumes():
    """(ボリュームGUIDパス(末尾\\なし), [マウントポイント], [ディスク番号]) を列挙"""
    buf = ctypes.create_unicode_buffer(1024)
    h = k32.FindFirstVolumeW(buf, 1024)
    if h is None or h == INVALID_HANDLE_VALUE:
        return
    try:
        while True:
            name = buf.value
            mounts = []
            pbuf = ctypes.create_unicode_buffer(4096)
            rl = wt.DWORD(0)
            if k32.GetVolumePathNamesForVolumeNameW(name, pbuf, 4096, ctypes.byref(rl)):
                mounts = [m for m in pbuf[:rl.value].split("\0") if m]
            disks = []
            try:
                vh = _open(name.rstrip("\\"), 0)
                try:
                    out = _ioctl(vh, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, outsize=1024)
                    n = struct.unpack_from("<I", out, 0)[0]
                    disks = [struct.unpack_from("<I", out, 8 + 24 * i)[0] for i in range(n)]
                finally:
                    k32.CloseHandle(vh)
            except SformError:
                pass
            yield name.rstrip("\\"), mounts, disks
            if not k32.FindNextVolumeW(h, buf, 1024):
                break
    finally:
        k32.FindVolumeClose(h)


def system_disk_numbers() -> set:
    sysdrive = os.environ.get("SystemDrive", "C:").upper().rstrip("\\") + "\\"
    result = set()
    for _, mounts, disks in iter_volumes():
        if any(m.upper() == sysdrive for m in mounts):
            result.update(disks)
    return result


# ---------------------------------------------------------------------------
# ディスク情報
# ---------------------------------------------------------------------------
def _cstr(buf: bytes, off: int) -> str:
    if off == 0 or off >= len(buf):
        return ""
    end = buf.find(b"\0", off)
    return buf[off:end if end >= 0 else None].decode("ascii", "replace").strip()


def get_disk_info(n: int) -> dict:
    h = _open(rf"\\.\PhysicalDrive{n}", GENERIC_READ)
    try:
        size = struct.unpack("<q", _ioctl(h, IOCTL_DISK_GET_LENGTH_INFO, outsize=8))[0]
        d = _ioctl(h, IOCTL_STORAGE_QUERY_PROPERTY, struct.pack("<III", 0, 0, 0), 1024)
        removable = bool(d[10])
        vendor = _cstr(d, struct.unpack_from("<I", d, 12)[0])
        product = _cstr(d, struct.unpack_from("<I", d, 16)[0])
        bus = struct.unpack_from("<I", d, 28)[0]
    finally:
        k32.CloseHandle(h)
    return {"number": n, "size": size, "removable": removable, "bus": bus,
            "model": " ".join(x for x in (vendor, product) if x)}


def list_disks():
    for n in range(32):
        try:
            yield get_disk_info(n)
        except SformError:
            continue


def print_disk_list() -> None:
    if not is_admin():
        raise SformError("管理者として実行してください(コマンドプロンプトを「管理者として実行」)。")
    sysd = system_disk_numbers()
    vols = list(iter_volumes())
    print(" No  容量                         バス   リムーバブル  モデル / ドライブ")
    for d in list_disks():
        letters = sorted({m for _, ms, ds in vols if d["number"] in ds for m in ms})
        mark = "  ★システム" if d["number"] in sysd else ""
        print(f" {d['number']:2d}  {fmt_bytes(d['size']):28s} {BUS_TYPES.get(d['bus'], hex(d['bus'])):5s}  "
              f"{'はい' if d['removable'] else 'いいえ':10s}  {d['model']} {' '.join(letters)}{mark}")


# ---------------------------------------------------------------------------
# 物理ディスク
# ---------------------------------------------------------------------------
class PhysicalDisk:
    def __init__(self, info: dict, writable: bool):
        self.number = info["number"]
        self.size_bytes = info["size"]
        self.description = (f"PhysicalDrive{self.number} [{info['model']}] "
                            f"{BUS_TYPES.get(info['bus'], hex(info['bus']))}")
        self.path = rf"\\.\PhysicalDrive{self.number}"
        self.writable = writable
        access = GENERIC_READ | (GENERIC_WRITE if writable else 0)
        self.h = _open(self.path, access, FILE_FLAG_WRITE_THROUGH if writable else 0)
        self.locked = []

    def _lock_with_retry(self, vh: int) -> bool:
        for _ in range(LOCK_RETRIES):
            try:
                _ioctl(vh, FSCTL_LOCK_VOLUME)
                return True
            except SformError:
                time.sleep(LOCK_RETRY_WAIT)
        return False

    def prepare_for_write(self) -> None:
        """対象ディスク上のボリュームをすべてロックしてアンマウントする。

        ロックできない場合は強制アンマウント(他プロセスのハンドルを無効化)
        してから再度ロックを試みる。それでも失敗したら DiskAccessError。
        """
        for name, mounts, disks in iter_volumes():
            if self.number not in disks:
                continue
            label = " ".join(mounts) or name
            try:
                vh = _open(name, GENERIC_READ | GENERIC_WRITE)
            except SformError as e:
                raise DiskAccessError(f"ボリューム {label} を開けません。({e})")
            ok = self._lock_with_retry(vh)
            if not ok:
                print(f"  ボリューム {label} が使用中のため強制アンマウントします...")
                try:
                    _ioctl(vh, FSCTL_DISMOUNT_VOLUME)
                except SformError:
                    pass
                ok = self._lock_with_retry(vh)
            if not ok:
                k32.CloseHandle(vh)
                raise DiskAccessError(
                    f"ボリューム {label} をロックできません(他のプログラムが使用中)。")
            try:
                _ioctl(vh, FSCTL_DISMOUNT_VOLUME)
            except SformError:
                pass
            self.locked.append(vh)
            print(f"  ボリューム {label} をロック・アンマウントしました")

    def _seek(self, lba: int) -> None:
        if not k32.SetFilePointerEx(self.h, lba * SECTOR_SIZE, None, 0):
            raise _winerr(f"シーク失敗 LBA {lba}")

    def read(self, lba: int, count: int) -> bytes:
        self._seek(lba)
        size = count * SECTOR_SIZE
        buf = ctypes.create_string_buffer(size)
        got = wt.DWORD(0)
        if not k32.ReadFile(self.h, buf, size, ctypes.byref(got), None) or got.value != size:
            raise _winerr(f"読込失敗 LBA {lba}")
        return buf.raw

    def write(self, lba: int, data: bytes) -> None:
        if len(data) % SECTOR_SIZE:
            raise SformError("書込データがセクタ境界ではありません")
        chunk = 1 * 1024 * 1024
        for off in range(0, len(data), chunk):
            part = data[off:off + chunk]
            self._seek(lba + off // SECTOR_SIZE)
            buf = ctypes.create_string_buffer(part, len(part))
            done = wt.DWORD(0)
            if not k32.WriteFile(self.h, buf, len(part), ctypes.byref(done), None) \
                    or done.value != len(part):
                if ctypes.get_last_error() == ERROR_WRITE_PROTECT:
                    raise WriteProtectError("SD カードが書込禁止(ライトプロテクト)状態です。")
                if ctypes.get_last_error() == ERROR_ACCESS_DENIED:
                    raise DiskAccessError(f"書込が拒否されました LBA {lba + off // SECTOR_SIZE}"
                                          "(ボリュームが再マウントされた可能性)")
                raise _winerr(f"書込失敗 LBA {lba + off // SECTOR_SIZE}")

    def flush(self) -> None:
        k32.FlushFileBuffers(self.h)

    def close(self) -> None:
        if self.h:
            if self.writable:
                k32.FlushFileBuffers(self.h)
                try:
                    _ioctl(self.h, IOCTL_DISK_UPDATE_PROPERTIES)   # パーティション再認識
                except SformError:
                    pass
            k32.CloseHandle(self.h)
            self.h = None
        for vh in self.locked:
            try:
                _ioctl(vh, FSCTL_UNLOCK_VOLUME)
            except SformError:
                pass
            k32.CloseHandle(vh)
        self.locked = []


def open_target_disk(n: int, writable: bool, force: bool = False) -> PhysicalDisk:
    if not is_admin():
        raise SformError("管理者として実行してください(コマンドプロンプトを「管理者として実行」)。")
    if n in system_disk_numbers():
        raise SformError(f"PhysicalDrive{n} はシステムドライブを含むため対象にできません。")
    info = get_disk_info(n)
    if not (info["removable"] or info["bus"] in SAFE_BUS):
        msg = (f"PhysicalDrive{n} はリムーバブル/USB/SD デバイスではありません"
               f"(バス={BUS_TYPES.get(info['bus'], hex(info['bus']))})。")
        if not force:
            raise SformError(msg + " 本当に対象にする場合は --force を付けてください。")
        print("警告: " + msg)
    if info["size"] == 0:
        raise SformError(f"PhysicalDrive{n} にメディアが挿入されていません。")
    disk = PhysicalDisk(info, writable)
    if writable:
        try:
            _ioctl(disk.h, IOCTL_DISK_IS_WRITABLE)
        except SformError as e:
            if getattr(e, "winerror", None) == ERROR_WRITE_PROTECT:
                disk.writable = False     # close 時に更新処理をしない
                disk.close()
                raise WriteProtectError("SD カードが書込禁止(ライトプロテクト)状態です。")
            # それ以外の失敗(未対応リーダー等)は無視し、書込時の判定に任せる
    return disk
