# MCPLAYER.COM（MICRO CABIN MUSIC PLAYER の DOS 版）Ver 0.38

MSX-DOS2 / Nextor の上で常駐し、DOS のプロンプトやファイラを使いながら、マイクロキャビンのゲームの曲をバックグラウンドで鳴らします。
MGSDRV のように `MCPLAYER /Z` で常駐させ、`MCPLAYER 曲.MCM` で鳴らします。曲は ROM 版と同じく、それぞれのゲーム自身のサウンドドライバと音色で鳴らします。

DOS 版のファイルは、ROM 版と同じ手順（README.md）で `player/build_rom.py` を動かすと、ROM と一緒に `dos/` フォルダにできます。
曲・ドライバはご自分で持っているゲームのディスクイメージから取り出したもので、配布物には入っていません。

## できるファイル（dos/）

| 場所 | 内容 |
|---|---|
| `MCPLAYER.COM` | プレーヤー（常駐・再生・停止。約 8KB） |
| `XAK/XAK.DRV` など | ゲームごとのドライバ（ディスクイメージから取り出し、MCPLAYER.COM で動くように直したもの。ゲームのフォルダごと） |
| `XAK/XAK101.MCM` など | プレイリストの曲（ゲームのフォルダごと、元のファイル名。ほかのゲームと中身が同じ曲も、それぞれのゲームのフォルダに入れます） |
| `XAK/XAK.LST` など | 曲の一覧（ファイル名・ドライバ・ループ回数・曲名。ゲームのフォルダごと、Shift-JIS） |

`dos/` の中身をフォルダごと MSX のディスクにコピーしてください。ドライバ（`*.DRV`）と曲の一覧（`*.LST`）は、曲と同じゲームのフォルダに入っています（曲のフォルダで最初に見つかるので、探すのが早く済みます）。曲だけを別の場所に移すときは、その曲の `*.DRV` も、曲と同じフォルダか `MCPLAYER.COM` のフォルダに置いてください。

| DRV | ゲーム | 曲のファイル名 |
|---|---|---|
| XAK | Xak | XAK… |
| XAKI | Xak II | XAKI… |
| GAZZ | ガゼルの塔 | GAZZ… |
| FRYM / FRYT / FRYD | FRAY（MSX2 版 / turboR 版 / デモ） | FRYM… / FRYT… / FRYD… |
| ILLU | 幻影都市 | ILLU… |
| FFAN | ファイナルファンタジー | FFAN… |
| RISK | キャンペーン版大戦略II | RISK… |
| PMAK | プリンセスメーカー | PMAK… |
| CABI / CABI3 | The Tower of Cabin（ディスク 1・2 / ディスク 3） | CABI… / CABI3… |

## 必要なもの

- MSX-DOS2 または Nextor（2 / 3）が動く MSX（マッパー RAM の空きセグメントが 1 つ = 16KB 必要）
- MSX-MUSIC か FM-PAC（無ければ PSG のパートだけ鳴ります）
- turboR は R800 のままで構いません（FM 音源の書き込みは R800 でも間に合うように待ちます）

## 使い方

```
MCPLAYER /Z                 常駐する（もう一度で解除）
MCPLAYER /I                 常駐していなければ常駐する（していれば何もせずに戻る）
MCPLAYER /Z /M              MGSDRV.COM も読み込んで常駐する（MGS も鳴らす。/I /M も同じ）
MCPLAYER XAK\XAK201.MCM     バックグラウンドで再生（すぐプロンプトに戻る）
MCPLAYER XAK201.MCM /L:2    2 回ループしたらフェードアウトして止める（既定はずっとループ）
MCPLAYER /S                 停止
MCPLAYER /F                 フェードアウトして止める（/F:8 のように速さも指定できる。既定 4）
MCPLAYER                    使い方と今の状態（演奏中・フェード中・停止と曲名）
MCPLAYER XAK201.MCM /J      曲名を日本語で出す（/E なら英語）
MCPLAYER MURA.MGS           MGS を鳴らす（MGSDRV で。下の「MGSDRV と一緒に使う」）
```

- 常駐と解除のときは DOS を立ち上げ直します（MGSDRV と同じ。REBOOT.BAT があれば動きます）。立ち上げ直すと環境変数とカレントディレクトリは元に戻るので、必要なら REBOOT.BAT で設定し直してください。
- REBOOT.BAT は立ち上げ直すたびに動くので、REBOOT.BAT から常駐させるときは `/Z`（もう一度で解除）ではなく `/I` を使います。たとえば AUTOEXEC.BAT に `MGSDRV /Z`、REBOOT.BAT に `MCPLAYER /I` と `NM` を書くと、電源を入れるだけで MGSDRV と MCPLAYER を常駐させて NM が起動します（MCPLAYER を常駐させて立ち上げ直した後、もう一度 REBOOT.BAT が動き、`/I` はそのまま戻るので次の行に進みます。MGSDRV と両方を常駐させて NM を使えるのは Nextor のときです。下の「注意」の TPA を見てください）。
- 解除できるのは、MCPLAYER が一番後から常駐したときだけです（MGSDRV などを後から常駐させたら、そちらを先に解除してください）。
- ループしない曲は、最後まで鳴ると止まります。

### 曲の一覧（*.LST）

ゲームのフォルダごとに、そのゲームの曲の一覧（`XAK.LST` のようにドライバと同じ名前）があります。1 行 1 曲の Shift-JIS のテキストで、`#` で始まる行は注釈です。

```
XAK201.MCM | XAK.DRV |  | Xak | フェアレスの町 | Xak | Village of Fearless
（ファイル名 | ドライバ | ループ回数 | ゲーム名 | 曲名 | 英語のゲーム名 | 英語の曲名）
```

- 曲を鳴らすと、一覧からこの曲の行を探し、ドライバ・ループ回数・曲名を使います。曲名は「Playing」と状態の表示（`MCPLAYER`）に出ます。ファイラなどにも渡します（`API.md`）。
- 一覧は、曲のファイル名の先頭の文字でドライバと同じように探します（曲のフォルダ、次に MCPLAYER.COM のフォルダ）。見つからなければ、その 2 つのフォルダの `*.LST` を順に調べます。
- ドライバ・ループ回数は空でも構いません（空ならいつもの探し方・ずっとループ）。ループ回数を書けば、`/L` を付けなくてもその回数で止まります。
- 曲名は、本体の文字セットが日本で、DOS の画面が漢字モード（グラフィックの画面）なら日本語、そうでなければ英語で出します。`/J`・`/E` で決められます。
- 一覧にない曲（名前を変えた曲など）も、下の探し方で鳴ります（曲名は出ません）。一覧はテキストなので、自分で書き足したり直したりできます。

### ドライバの選び方

一覧にこの曲のドライバが書いてあればそれを使います。なければ、曲のファイル名の先頭 5 文字 → 4 文字 → 3 文字の順に `○○.DRV` を探します（`XAK201.MCM` なら XAK20.DRV、XAK2.DRV、XAK.DRV）。探す場所は曲と同じフォルダ、次に MCPLAYER.COM のあるフォルダです。
見つからなければ、その 2 つのフォルダの `*.DRV` を順に調べ、この曲が入っているもの（DRV の中に曲の一覧があります）を使います。名前を変えた曲もこれで鳴ります。`/D:XAK.DRV` で直接指定もできます。

## ファイラから使う

ファイラの拡張子の関連付けで、.MCM に `MCPLAYER` を割り当てます。NM や MultiMente なら MMRET.DAT に、.MCM の行として `MCPLAYER $C` を書きます。.MCM を選んで実行すると、ファイラを使ったまま曲が鳴ります。.MGS も同じように `MCPLAYER $C` を割り当てられます。

## MGSDRV と一緒に使う

**MGSDRV.COM を MCPLAYER.COM と同じフォルダに置き、`MCPLAYER /Z /M` で常駐すると**、MCPLAYER が MGSDRV の本体を読み込み、MGS も鳴らせるようになります（「MGSDRV.COM loaded」と出ます）。MGSDRV を別に常駐させる必要はありません。`/M` を付けなければ今までどおり MCPLAYER だけが常駐します（常駐部が小さいままです）。

- `MCPLAYER 曲.MGS` で MGS を、`MCPLAYER 曲.MCM` で MCM を鳴らします。片方を鳴らすと、もう片方は止まります。MGS でも `/L:n`・`/F`・`/S` と状態の表示が使えます。
- MCPLAYER は MGSDRV が常駐しているときと同じ入口（拡張 BIOS のデバイス番号 F0h）も出すので、常駐した MGSDRV で MGS を鳴らすプログラム（NM など）はそのまま使えます。
- 常駐部は、MGSDRV と MCPLAYER を別々に常駐させるより小さくなります（ページ3を 446 バイト。別々なら 585 バイト）。
- MGSDRV.COM は配布物に入っていません。ご自分の MGSDRV.COM を置いてください。MGSDRV v3 の系統が使えます（v3.20 と v3.17 で確かめています。v3 でなければ読み込みません）。MGSDRV は「MGSDRV プログラムインターフェイス仕様書」のとおり、ほかのプログラムに組み込んで使えるように作られています（MGSDRV の作者の Ain さん、GIGAMIX の皆さんに感謝します）。MCPLAYER は MGSDRV.COM を書き換えずにそのまま読み込み、仕様書にある入口だけを使います。
- MGSDRV (C) Ain./Gigamix — https://www.gigamix.jp/mgsdrv/

MGSDRV そのものを常駐させる使い方もできます（MCPLAYER より先に常駐させると、MCPLAYER は MGSDRV.COM を読み込まず、常駐した MGSDRV で MGS を鳴らします）。

- `MCPLAYER 曲.MCM` は、MGSDRV が常駐していれば MGSDRV の演奏を止めてから鳴らします。
- MGS を鳴らす前に MCPLAYER を止めるのは、MGS を鳴らすプログラムの側の仕事です（止めなければ混ざります）。ファイラなどから止めるための入口は `API.md` にあります。

## 注意

- **TPA**: 常駐部はページ3を 265 バイト（MGSDRV.COM を読み込んだときは 446 バイト）使います（TPA の上限は 100h〜200h 程度下がります）。MSX-DOS2 で MGSDRV と両方を常駐させると、TPA を多く使うプログラム（たとえば D360h 以上を求める NM）が起動できないことがあります。Nextor では両方常駐しても足ります。
- **Nextor の COMMAND3.COM / COMMAND2.COM 2.44**: プログラムが DOS を立ち上げ直す（MGSDRV や MCPLAYER の常駐・解除）たびに、シェルの退避場所が少しずつ埋まり、4〜5 回で「Not enough memory」になるシェル側の問題があります（Konamiman/Nextor #289）。MCPLAYER は立ち上げ直す前にこれを片付けるので、MCPLAYER の常駐・解除では起きません（MGSDRV だけで繰り返すと起きます）。COMMAND3.COM は Nextor の開発版（dev-build 2026-11-23、Konamiman/Nextor #290）で直りました（COMMAND2.COM 2.44 は直りません）。直った COMMAND3.COM とも一緒に使えます。
- 曲は 6KB まで（今あるいちばん大きい曲は 4.7KB）。

## 動作確認

- openMSX（FS-A1ST）の MSX-DOS2 と Nextor 3 で、全 12 種類のドライバでの再生・停止・フェード・ループ回数、MGSDRV との重ね常駐、名前を変えた曲。
- ドライバを移した結果は、元の番地のドライバと PSG・FM への出力が全曲（471 曲）一致することを Z80 エミュレータで確かめています。
- 実機（MSX turboR、MSX-DOS2・Nextor 2）で、R800 / Z80 での再生、ファイラ（NM）の関連付けからの再生、MGSDRV との使い分け。
- MGSDRV.COM の読み込み（openMSX の MSX-DOS2・Nextor 3）: MGS の再生・停止・フェード・状態の表示、MCM との切り替え、常駐した MGSDRV で鳴らすプログラムと同じ手順での再生、MGSDRV を先に常駐させた場合・後から MGSDRV /Z を実行した場合。
- 実機（MSX turboR、MSX-DOS2）で `MCPLAYER /M /Z`: MGS の再生・フェード・MCM との切り替え・解除、NM と MGSEL.COM Version 3.01v（常駐した MGSDRV を使うプログラム）からの再生。

## 仕組み（概要）

- 常駐部はページ3に入口と切り替えの処理（265 バイト。MGSDRV を読み込むときは 446 バイト）だけを置き、ドライバ・音色の表・曲と処理の本体はマッパー RAM のセグメント（16KB）に置きます。割込みのたびにセグメントをページ2に出してドライバを動かし、元に戻します。
- ドライバはゲームの中では決まった番地（CD00h〜D100h など）で動く作りなので、DRV を作るとき（`player/mcdos/mkdrv.py`）に命令を辿って番地を付け替え、セグメントの 8000h〜で動くようにしています。
- ファイラなどから直接鳴らす・止める入口（拡張 BIOS のデバイス番号 F1h）の説明は `API.md` にあります。
