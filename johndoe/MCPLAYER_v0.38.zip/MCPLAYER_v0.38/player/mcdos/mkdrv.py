#!/usr/bin/env python3
"""MCDOS ドライバファイル (*.DRV) を作る

ゲームのディスクイメージからそのゲームのサウンドドライバを取り出し、
MCDRV (常駐部) のマッパーセグメント (ページ2、8000h-) で動くように
パッチ・リロケートして書き出す。マイクロキャビンのコードはこのツールにも
repo にも入っていない (drivers.json は番地と md5 だけ)。

使い方:
  python tools/mkdrv.py                            # 全部のゲーム -> out/*.DRV
  python tools/mkdrv.py XAK                        # ../MicroCabin/disk_image/XAK -> out/XAK.DRV
  python tools/mkdrv.py XAK --disks DIR --songs DIR -o out/
  python tools/mkdrv.py XAK --list                 # 辿った結果・付け替えた番地を表示

DRV ファイルの形 (ヘッダ 64 バイト。src/mcdrv.inc の DH_* と合わせる):
  +00 "MCDRV",1Ah   +06 版 (1)   +07 ヘッダの長さ (64)
  +08 名前 (16 バイト、0 で埋める)
  +18 置く番地       +1A イメージの長さ   +1C その後ろを 0 にする長さ
  +1E 割込み処理     +20 コマンドの入口   +22 コマンド番号 4 つ (初期化, フェードアウト, 演奏中か, 演奏開始)
  +26 表の番地       +28 表の数          +29 (予備)
  +2A 曲の番地       +2C 曲の最大長
  +2E フェードの段数の番地  +30 フェードの制御の番地
  +32 FM 0Eh (リズム) の写しの番地
  +34 turboR の印の番地 (セグメントの中。0 = なし。MCPLAY が常駐部の P_TR を写す)
  +36 曲ごとの表の索引の数
  +38 曲のチャンネルのワーク (12 個)   +3A その大きさ (1 バイト)   +3B (予備)
  +3C ループの折り返しの数 (LoopCnt、12 バイト。セグメントの中)
  +3E-3F 予備
  +40 イメージ、続いて表 (1E0h バイト x 表の数)、
      続いて曲の索引 (1 曲 5 バイト: 曲の長さ, 曲の 16 ビットの和, 表の番号。索引にない曲は表 0)。
      索引にはこの DRV で鳴らす曲を全部入れる (MCPLAY が名前を変えた曲のドライバを探すのにも使う)
"""
import argparse
import hashlib
import json
import os
import re
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import z80dis  # noqa: E402

# 版ごとの番地などの表。MCDOS では tools/drivers.json、MCPLAYER の配布物では player/drivers.json (一つ上)
DRIVERS_JSON = next((p for p in (os.path.join(HERE, 'drivers.json'), os.path.join(HERE, '..', 'drivers.json'))
                     if os.path.isfile(p)), os.path.join(HERE, 'drivers.json'))
DISK_ROOT = os.path.join(HERE, '..', '..', 'MicroCabin', 'disk_image')
SONG_ROOT = os.path.join(HERE, '..', '..', 'MicroCabin', 'data')   # 曲ごとの表を決めるのに使う曲 (*.MCM)
DRV_SIG = re.compile(rb'\xc3..\xf3\xdd\xe5\xe5\xd5\xc5\xfe', re.S)   # jp 割込み処理 / コマンドの入口
TBL_LEN = 0x1E0
INST_SIG = re.compile(re.escape(bytes.fromhex('5161')) + rb'[\x10-\x1f]' + re.escape(bytes.fromhex('0750f15cdc')))

SEG_DRV = 0x8000          # セグメントの中でドライバを置く番地
SEG_TBL = 0x9000          # 表 (9000h + 元の番地の下位 12 ビット)
SEG_SONG = 0xA000         # 曲
SEG_LIB = 0xB800          # 常駐部の処理の本体 (src/seglib.asm)。曲はその手前まで (6KB)
SEG_END = 0xC000
HDR_LEN = 64

# 出力するファイル名 (曲のファイル名の先頭) -> (フォルダ, ドライバの版の名前の頭)
GAMES = {
    'XAK': ('XAK', 'XAK_D100'),
    'XAKI': ('XAKII', 'XAKII_CE00'),
    'GAZZ': ('GAZZEL', 'GAZZEL_CE00'),
    'CABI': ('CABIN', 'CABIN_CD00'),
    'CABI3': ('CABIN', 'CABIN_CF00'),
    'FRYD': ('FRAY_DM', 'CABIN_CF00'),
    'FRYM': ('FRAY_M2', 'CABIN_CF00'),
    'FRYT': ('FRAY_TR', 'FRAY_TR_CF00'),
    'ILLU': ('ILLUSION', 'ILLUSION_8100'),
    'PMAK': ('PMAKER', 'PMAKER_CE00'),
    'RISK': ('RISK2', 'RISK2_CD00'),
    'FFAN': ('FFANTASY', 'FFANTASY_752F'),
}

# 版ごとのリロケートの追加情報 (自動で見つからない飛び先の表など)
#  jtables: {番地: 項目数}
RELOC_EXTRA = {
}

# FM 書き込みの付け替え先 (src/drvstub.asm を STUBBASE=0 でアセンブルしたもの)。入口: B=レジスタ, A=値
STUB_CODE = bytes.fromhex('c5f578d37c0e02cd1600f1d37df50e08cd1600f1c1c93a2a00b7280adbe647dbe690b938fac94110fec900')
STUB_RELOC = [8, 17, 23]          # 置いた番地を足すワードの位置
STUB_FLAG = len(STUB_CODE) - 1    # 0 以外: turboR (E6h で待つ)

# ドライバの FM の書き込み (幻影都市・FRAY turboR 以外の全部): アドレスとデータの間が nop だけで、
# R800 では YM2413 の書き込みの間隔が足りない -> STUB_CODE (待ち付き) に付け替える
#  push bc / push af / ld a,b / ld bc,(ポート) / out (c),a / nop / inc c / pop af / out (c),a / pop bc / ret
FM_WRITE = re.compile(rb'\xc5\xf5\x78\xed\x4b(..)\xed\x79\x00\x0c\xf1\xed\x79\xc1\xc9', re.S)

# ループの終わりのフック (src/drvhook.asm を HOOKBASE=0 でアセンブルしたもの)
HOOK_CODE = bytes.fromhex('e5d5dde5e13a32005f1600197e23e5b7201b2a33007ecb7f2804e67f1802c603fe0c30095f2135001934200135e17ed1e1c9'
                          '000000000000000000000000000000')
HOOK_RELOC = [6, 19, 38]
HOOK_CNT = 0x32                   # CntOff
HOOK_CHACT = 0x33                 # ChactPtr
HOOK_LOOPCNT = 0x35               # LoopCnt (12 バイト)


def disk_files(root, folder):
    out = []
    d = os.path.join(root, folder)
    if os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            f = os.path.join(d, fn)
            if os.path.isfile(f) and fn.lower().endswith(('.dsk', '.di1', '.di2')):
                out.append((fn, open(f, 'rb').read()))
    return out


def find_drivers(known, disks):
    """[(ファイル名, 中身, [(位置, md5 キー)])] (MCPLAYER の build_rom.py Drivers._folder と同じ)"""
    sigs = [DRV_SIG] + [re.compile(re.escape(bytes.fromhex(x)))
                        for x in sorted({d['sig'] for d in known.values() if 'sig' in d})]
    out = []
    for fn, data in disks:
        drvs = []
        for m in (m for sig in sigs for m in sig.finditer(data)):
            k = hashlib.md5(data[m.start():m.start() + 0x600]).hexdigest()
            if k in known:
                d = known[k]
                if hashlib.md5(data[m.start():m.start() + d['copylen']]).hexdigest() == d['md5']:
                    drvs.append((m.start(), k))
        out.append((fn, data, drvs))
    return out


def table_positions(data):
    """ディスクの中の表 -> [(位置, 表)]"""
    out = []
    for m in INST_SIG.finditer(data):
        s = m.start() - 0xE0
        if s >= 0 and m.start() + 0x100 <= len(data):
            out.append((s, data[s:s + TBL_LEN]))
    return out


def find_tables(disks):
    """ディスクの表 (音色など) を見つかった順に、重なりなしで -> [bytes]"""
    out = []
    for fn, data in disks:
        for s, t in table_positions(data):
            if t not in out:
                out.append(t)
    return out


# ---------------------------------------------------------------------------
# 命令を辿る逆アセンブル

ADDR = re.compile(r'\b0?([0-9A-F]{4})h\b')


def ends_flow(t):
    """この命令の後ろへは進まない"""
    if t in ('ret', 'reti', 'retn', 'halt') or t.startswith('jp ('):
        return True
    if (t.startswith('jp ') or t.startswith('jr ')) and ',' not in t:
        return True
    return False


class Tracer:
    def __init__(self, img, base, ranges, extra_tables=None):
        self.img = img
        self.base = base
        self.ranges = ranges               # リロケートする範囲 [(先頭, 終わり, 移す先)]
        self.code = {}                     # 番地 -> (文字列, 長さ)
        # 飛び先の表: 番地 -> (項目数, 1 項目の大きさ, 項目の中の番地の位置)
        self.tables = {a: (n, 2, 0) for a, n in (extra_tables or {}).items()}
        self.end = base + len(img)

    def mapped(self, v):
        return any(lo <= v < hi for lo, hi, new in self.ranges)

    def move(self, v):
        for lo, hi, new in self.ranges:
            if lo <= v < hi:
                return v - lo + new
        return v

    def dis(self, pc):
        return z80dis.dis(self.img, pc, self.base)[:3]

    def trace(self, entries):
        todo = list(entries)
        while True:
            while todo:
                pc = todo.pop()
                while self.base <= pc < self.end and pc not in self.code:
                    t, l, tgt = self.dis(pc)
                    self.code[pc] = (t, l)
                    if tgt is not None and self.base <= tgt < self.end:
                        todo.append(tgt)
                    if ends_flow(t):
                        break
                    pc += l
            new = self.find_tables()
            added = False
            for a, n in new.items():
                if a not in self.tables:
                    self.tables[a] = n
                    added = True
            for a in self.tables:
                for o in self.table_words(a):
                    e = struct.unpack_from('<H', self.img, o)[0]
                    if e not in self.code and self.base <= e < self.end:
                        todo.append(e)
            if not added and not todo:
                break
        self.check_overlap()

    def table_words(self, a):
        """表 a の番地のワードの位置 (イメージの中)"""
        n, stride, off = self.tables[a]
        return [a - self.base + stride * k + off for k in range(n)]

    def ordered(self):
        return sorted(self.code.items())

    def find_tables(self):
        """飛び先の表: ld hl/de,表 の前 12 命令以内に cp n (n 個) / and n (n+1 個)、
        後ろ 12 命令以内 (呼んだ先の 1 命令目も見る) に jp (hl) / jp (ix) / jp (iy)"""
        found = {}
        seq = self.ordered()
        for i, (pc, (t, l)) in enumerate(seq):
            m = re.match(r'ld (hl|de),0?([0-9A-F]{4})h$', t)
            if not m:
                continue
            a = int(m.group(2), 16)
            if not (self.base <= a < self.end) or a in self.code:
                continue
            jump = False
            for pc2, (t2, l2) in seq[i + 1:i + 13]:
                if t2.startswith('jp ('):
                    jump = True
                    break
                c = re.match(r'call 0?([0-9A-F]{4})h$', t2)
                if c and self.code.get(int(c.group(1), 16), ('',))[0].startswith('jp ('):
                    jump = True
                    break
                if ends_flow(t2):
                    break
            if not jump:
                continue
            n = None
            for pc2, (t2, l2) in reversed(seq[max(0, i - 12):i]):
                if ends_flow(t2) or t2.startswith('call'):
                    break
                c = re.match(r'(cp|and) 0?([0-9A-F]{2})h$', t2)
                if c:
                    v = int(c.group(2), 16)
                    n = v if c.group(1) == 'cp' else v + 1
                    break
            if n is None:
                n = 0                       # 数がわからない: ドライバの中を指す値が続く間
                while True:
                    o = a - self.base + 2 * n
                    if o + 2 > len(self.img):
                        break
                    e = struct.unpack_from('<H', self.img, o)[0]
                    if not (self.base <= e < self.end) or a + 2 * n in self.code:
                        break
                    n += 1
            nxt = min((c for c in self.code if c > a), default=self.end)
            found[a] = (min(n, (nxt - a) // 2), 2, 0)
        found.update(self.find_runtables(seq))
        return found

    def find_runtables(self, seq):
        """曲のコマンドの表 (幻影都市の系統): ld hl,表 / cp (hl) / jr c / sub (hl) / inc hl x3 / jr ... /
        inc hl / ld e,(hl) / inc hl / ld d,(hl) ... push de / ret。
        1 項目 3 バイト (コマンドの数, 番地)。コマンドの数の合計が 255 に届くまで"""
        found = {}
        for i, (pc, (t, l)) in enumerate(seq):
            m = re.match(r'ld hl,0?([0-9A-F]{4})h$', t)
            if not m or i + 1 >= len(seq) or seq[i + 1][1][0] != 'cp (hl)':
                continue
            if not any(t2 == 'push de' for p2, (t2, l2) in seq[i + 1:i + 16]):
                continue
            a = int(m.group(1), 16)
            if not (self.base <= a < self.end) or a in self.code:
                continue
            n = total = 0
            while total < 255:
                o = a - self.base + 3 * n
                if o + 3 > len(self.img) or self.img[o] == 0:
                    sys.exit(f'{a:04X}h の曲のコマンドの表の終わりがわかりません')
                total += self.img[o]
                n += 1
            found[a] = (n, 3, 1)
        return found

    def check_overlap(self):
        cover = {}
        for pc, (t, l) in self.code.items():
            for k in range(l):
                if pc + k in cover:
                    sys.exit(f'{pc:04X}h の命令が {cover[pc + k]:04X}h の命令と重なります (辿り方の誤り)')
                cover[pc + k] = pc
        for a, (n, stride, off) in self.tables.items():
            for k in range(stride * n):
                if a + k in cover:
                    sys.exit(f'飛び先の表 {a:04X}h が {cover[a + k]:04X}h の命令と重なります')
                cover[a + k] = a
        self.cover = cover

    def relocs(self):
        """付け替える所 -> [(イメージの中の位置, 元の値, 種類)]"""
        out = []
        for pc, (t, l) in self.ordered():
            if t.startswith(('jr', 'djnz')):
                continue
            ops = [int(m.group(1), 16) for m in ADDR.finditer(t)]
            for v in ops:
                if self.mapped(v):
                    o = pc - self.base + l - 2
                    if struct.unpack_from('<H', self.img, o)[0] != v:
                        sys.exit(f'{pc:04X}h {t}: 番地の位置がわかりません')
                    out.append((o, v, 'code'))
        for a in sorted(self.tables):
            for o in self.table_words(a):
                out.append((o, struct.unpack_from('<H', self.img, o)[0], 'table'))
        return out

    def suspicious(self):
        """命令でも表でもない所にある、ドライバの中を指していそうなワード"""
        out = []
        o = 0
        while o + 2 <= len(self.img):
            a = self.base + o
            if a not in self.cover and a + 1 not in self.cover:
                v = struct.unpack_from('<H', self.img, o)[0]
                if self.mapped(v):
                    out.append((a, v))
            o += 1
        return out


# ---------------------------------------------------------------------------

def align16(a):
    return (a + 15) & ~15


def fm_writes(img, d):
    """FM の書き込みのルーチンの番地 (付け替える所)。drivers.json の wfm (E6h で待つもの) と FM_WRITE の形"""
    out = list(d['wfm'])
    for m in FM_WRITE.finditer(img):
        port = struct.unpack('<H', m.group(1))[0]
        if not (d['base'] <= port < d['base'] + len(img)) or img[port - d['base']] != 0x7C:
            sys.exit(f"{d['name']}: FM の書き込みのポートが 7Ch ではありません")
        out.append(d['base'] + m.start())
    if not out:
        sys.exit(f"{d['name']}: FM の書き込みのルーチンが見つかりません")
    return out


def layout(d, wfm):
    """セグメントの中の置き場所 -> (範囲 [(元の先頭, 終わり, 移す先)], ドライバの終わり, 表の番地)"""
    b = d['base']
    if b >= 0x8000:
        ranges = [(b, d['end'], SEG_DRV)]
    else:
        # ページ1のドライバ (FF): コードとワーク (ページ2) を別々に移す
        code_end = b + d['copylen']
        ranges = [(b, code_end, SEG_DRV), (d['work'], d['end'], align16(SEG_DRV + d['copylen']))]
    drv_end = max(new + hi - lo for lo, hi, new in ranges)
    need = align16(drv_end) + (len(STUB_CODE) if wfm else 0) + len(HOOK_CODE)
    # 表: 9000h + 元の番地の下位 12 ビット。入らなければ 8000h + (MCPLAYER の tbl_ram と同じ考え)
    for top in (SEG_TBL, SEG_DRV):
        t = top | (d['tblorig'][0] & 0xFFF)
        if t + TBL_LEN <= SEG_SONG and t >= need:
            return ranges, drv_end, t
    sys.exit(f"{d['name']}: 表を置く所がありません")


def song_key(body):
    """曲を見分ける値 (長さ, 16 ビットの和)。MCPLAY も同じものを計算する"""
    return len(body), sum(body) & 0xFFFF


def build_driver(img, d, extra):
    """ディスク上のドライバ (copylen バイト) -> (パッチ・リロケート済みのイメージ, 情報, Tracer, 付け替え)"""
    b = d['base']
    wfm = fm_writes(img, d)
    ranges, drv_end, t = layout(d, wfm)
    tr = Tracer(img, b, ranges, extra.get('jtables'))
    tr.trace([d['int'], d['cmd']])
    out = bytearray(img)
    rel = tr.relocs()
    for o, v, kind in rel:
        struct.pack_into('<H', out, o, tr.move(v))

    def put(addr, bs, want=None):
        o = addr - b
        if want is not None and bytes(img[o:o + len(want)]) != want:
            sys.exit(f"{d['name']}: {addr:04X}h の内容が想定と違います")
        out[o:o + len(bs)] = bs

    for a in d['fixed']:                       # ld hl,曲の番地 -> A000h
        if not 0xC000 <= struct.unpack_from('<H', img, a - b)[0] < 0xE000:
            sys.exit(f"{d['name']}: {a:04X}h の曲の番地が想定と違います")
        put(a, struct.pack('<H', SEG_SONG))
    for k, orig in enumerate(d['tblorig']):
        put(d['tblptr'] + 2 * k, struct.pack('<H', t + orig - d['tblorig'][0]), struct.pack('<H', orig))
    # ei -> nop: 全部のドライバのコマンドの出口にある。常駐部はセグメントの中にスタックを置くので、
    # セグメントにいる間は割込みを入れない (drivers.json の eis は FF の分。辿った命令の ei を全部)
    for a in sorted(set(d['eis']) | {pc for pc, (t, l) in tr.code.items() if t == 'ei'}):
        put(a, b'\x00', b'\xfb')
    # イメージはワークの終わりまで 0 で延ばし、後ろにフックなどを置く
    # (ワークは曲を読み込むたびに 0 になる。FF のワークは離れた所から移すのでこの方が簡単)
    image = bytes(out) + bytes(drv_end - SEG_DRV - len(out))
    clear = 0
    stub = flag = 0
    if wfm:
        # FM の書き込み -> セグメントの中の待ち付きの書き込み (R800 でも、turboR 以外でも動く)
        stub = align16(drv_end)
        code = bytearray(STUB_CODE)
        for o in STUB_RELOC:
            struct.pack_into('<H', code, o, struct.unpack_from('<H', code, o)[0] + stub)
        flag = stub + STUB_FLAG
        im = bytearray(image + bytes(stub - SEG_DRV - len(image)) + bytes(code))
        for a in wfm:                          # jp Stub
            if a not in tr.code:
                sys.exit(f"{d['name']}: {a:04X}h の FM の書き込みが命令として辿れていません")
            o = tr.move(a) - SEG_DRV
            if im[o:o + 2] != b'\xc5\xf5':
                sys.exit(f"{d['name']}: {a:04X}h の FM の書き込みが想定と違います")
            im[o:o + 3] = bytes([0xC3, stub & 0xFF, stub >> 8])
        for a in d['wait']:                    # E6h で待つだけのルーチン -> ret (書き込みの側で待つ)
            o = tr.move(a) - SEG_DRV
            if im[o] != 0xC5:
                sys.exit(f"{d['name']}: {a:04X}h の待ちのルーチンが想定と違います")
            im[o] = 0xC9
        image = bytes(im)
    # ループの終わり: ld a,(ix+CNT+1) -> call HookLoop
    hook = align16(SEG_DRV + len(image)) if not stub else SEG_DRV + len(image)
    code = bytearray(HOOK_CODE)
    for o in HOOK_RELOC:
        struct.pack_into('<H', code, o, struct.unpack_from('<H', code, o)[0] + hook)
    code[HOOK_CNT] = d['cnt']
    struct.pack_into('<H', code, HOOK_CHACT, tr.move(d['chact']))
    im = bytearray(image + bytes(hook - SEG_DRV - len(image)) + bytes(code))
    o = tr.move(d['endl']) - SEG_DRV
    if im[o:o + 3] != bytes([0xDD, 0x7E, d['cnt'] + 1]):
        sys.exit(f"{d['name']}: {d['endl']:04X}h のループの終わりが想定と違います")
    im[o:o + 3] = bytes([0xCD, hook & 0xFF, hook >> 8])
    image = bytes(im)
    end = SEG_DRV + len(image) + clear
    if not (t >= end or t + TBL_LEN <= SEG_DRV):
        sys.exit(f"{d['name']}: ドライバ ({SEG_DRV:04X}h-{end:04X}h) と表 ({t:04X}h) が重なります")
    info = dict(name=d['name'], base=SEG_DRV, len=len(image), clear=clear,
                int=tr.move(d['int']), cmd=tr.move(d['cmd']), cmds=d['cmds'], tbl=t, song=SEG_SONG,
                song_max=SEG_LIB - SEG_SONG, fadepass=tr.move(d['fadepass']), fadectl=tr.move(d['fadectl']),
                shdfme=tr.move(d['shdfme']), flag=flag, stub=stub, ranges=ranges, orig_base=b,
                chn=tr.move(d['chn']), stride=d['stride'], hook=hook, loopcnt=hook + HOOK_LOOPCNT)
    return image, info, tr, rel


def header(info, ntbl, nidx):
    h = bytearray(HDR_LEN)
    h[0:6] = b'MCDRV\x1a'
    h[6] = 1
    h[7] = HDR_LEN
    nm = info['name'].encode('ascii')[:16]
    h[8:8 + len(nm)] = nm
    struct.pack_into('<HHHHH', h, 0x18, info['base'], info['len'], info['clear'], info['int'], info['cmd'])
    h[0x22:0x26] = bytes(info['cmds'])
    struct.pack_into('<H', h, 0x26, info['tbl'])
    h[0x28] = ntbl
    struct.pack_into('<HHHHHHH', h, 0x2A, info['song'], info['song_max'], info['fadepass'], info['fadectl'],
                     info['shdfme'], info['flag'], nidx)
    struct.pack_into('<HBB H', h, 0x38, info['chn'], info['stride'], 0, info['loopcnt'])
    return bytes(h)


def load_song(path):
    """MCM ファイル -> 曲データ (BSAVE の形ならヘッダを除く)"""
    raw = open(path, 'rb').read()
    if len(raw) >= 7 and raw[0] == 0xFE:
        start = raw[1] | raw[2] << 8
        end = raw[3] | raw[4] << 8
        return raw[7:7 + (end - start + 1)]
    return raw


def drv_for(name):
    """曲のファイル名 -> DRV の名前 (MCPLAY と同じ: 先頭 5・4・3 文字)"""
    stem = os.path.splitext(os.path.basename(name))[0].upper()
    for n in (5, 4, 3):
        if len(stem) >= n and stem[:n] in GAMES:
            return stem[:n]
    return None


def song_tables(disks, tables, song_dir, game):
    """このゲームの曲 (song_dir の曲のうち drv_for がこのゲームのもの) -> {(長さ, 和): 表の番号}。
    表は MCPLAYER の InstTables と同じ決め方: 曲が見つかったディスクで曲より前にある
    一番近い表 (前になければ後ろの一番近い表)。表が 1 つか、ディスクに見つからなければ 0"""
    if not os.path.isdir(song_dir):
        return {}
    pos = [(data, [(s, tables.index(t)) for s, t in table_positions(data)]) for fn, data in disks]
    out = {}
    for fn in sorted(os.listdir(song_dir)):
        if not fn.upper().endswith('.MCM') or drv_for(fn) != game:
            continue
        body = load_song(os.path.join(song_dir, fn))
        key = song_key(body)
        k = 0
        if len(tables) >= 2:
            for data, p in pos:
                at = data.find(body)
                if at < 0 or not p:
                    continue
                before = [x for x in p if x[0] < at]
                k = (max(before) if before else min(p))[1]
                break
        if out.get(key, k) != k:
            print(f'注意: {fn} と長さ・和が同じで表の違う曲があります')
        out[key] = k
    return out


def make(game, disk_root=DISK_ROOT, list_=False, song_root=SONG_ROOT):
    """-> (DRV ファイルの中身, 情報, 元のドライバ, drivers.json の項目, 表, 曲ごとの表)"""
    folder, want = GAMES[game]
    known = json.load(open(DRIVERS_JSON, encoding='utf-8'))
    disks = disk_files(disk_root, folder)
    if not disks:
        sys.exit(f'{os.path.join(disk_root, folder)} にディスクイメージがありません')
    found = find_drivers(known, disks)
    cand = [(fn, data, pos, k) for fn, data, drvs in found for pos, k in drvs
            if known[k]['name'].startswith(want)]
    if not cand:
        sys.exit(f'{folder}: ドライバ {want} が見つかりません')
    fn, data, pos, key = cand[0]
    d = known[key]
    img = data[pos:pos + d['copylen']]
    out, info, tr, rel = build_driver(img, d, RELOC_EXTRA.get(d['name'], {}))
    tables = find_tables(disks)
    if not tables:
        sys.exit(f'{folder}: 音色などの表が見つかりません')
    if len(tables) > 255:
        sys.exit(f'{folder}: 表が多すぎます')
    idx = song_tables(disks, tables, os.path.join(song_root, folder), game)
    if list_:
        print(f"{game}: {d['name']} ({fn} {pos:06X}h)  " +
              ', '.join(f'{lo:04X}h-{hi:04X}h -> {new:04X}h' for lo, hi, new in info['ranges']))
        print(f'  命令 {len(tr.code)} 個、飛び先の表 ' +
              ', '.join(f'{a:04X}h x{n}' + ('' if st == 2 else f' ({st} バイトずつ)')
                        for a, (n, st, off) in sorted(tr.tables.items())))
        print(f"  付け替え {len(rel)} か所。イメージ {len(out)} バイト + ワーク {info['clear']} バイト、"
              f"表 {info['tbl']:04X}h" + (f"、FM の書き込み {info['stub']:04X}h" if info['stub'] else '') +
              f"、ループのフック {info['hook']:04X}h")
        sus = tr.suspicious()
        print(f'  データの中のドライバ内を指していそうなワード {len(sus)} 個 (付け替えない):')
        if sus:
            print('    ' + ' '.join(f'{a:04X}:{v:04X}' for a, v in sus))
        print(f'  表 {len(tables)} 種類、曲の索引 {len(idx)} 曲')
    index = b''.join(struct.pack('<HHB', ln, sm, k) for (ln, sm), k in sorted(idx.items()))
    return header(info, len(tables), len(idx)) + out + b''.join(tables) + index, info, img, d, tables, idx


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('games', nargs='*', default=sorted(GAMES))
    ap.add_argument('--disks', default=DISK_ROOT)
    ap.add_argument('--songs', default=SONG_ROOT, help='曲 (フォルダ名/*.MCM) の場所。曲ごとの表を決めるのに使う')
    ap.add_argument('-o', '--outdir', default=os.path.join(HERE, '..', 'out'))
    ap.add_argument('--list', action='store_true')
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    for g in a.games:
        g = g.upper()
        if g not in GAMES:
            sys.exit(f'{g}: 知らないゲームです ({", ".join(sorted(GAMES))})')
        drv = make(g, a.disks, a.list, a.songs)[0]
        p = os.path.join(a.outdir, g + '.DRV')
        open(p, 'wb').write(drv)
        print(f'{p}: {len(drv)} バイト')


if __name__ == '__main__':
    main()
