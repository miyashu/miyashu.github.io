"""Minimal Z80 disassembler (documented + common undocumented forms)."""
R = ['b', 'c', 'd', 'e', 'h', 'l', '(hl)', 'a']
RP = ['bc', 'de', 'hl', 'sp']
RP2 = ['bc', 'de', 'hl', 'af']
CC = ['nz', 'z', 'nc', 'c', 'po', 'pe', 'p', 'm']
ALU = ['add a,', 'adc a,', 'sub ', 'sbc a,', 'and ', 'xor ', 'or ', 'cp ']
ROT = ['rlc', 'rrc', 'rl', 'rr', 'sla', 'sra', 'sll', 'srl']
IM = ['0', '0/1', '1', '2', '0', '0/1', '1', '2']
BLI = {(4, 0): 'ldi', (4, 1): 'cpi', (4, 2): 'ini', (4, 3): 'outi',
       (5, 0): 'ldd', (5, 1): 'cpd', (5, 2): 'ind', (5, 3): 'outd',
       (6, 0): 'ldir', (6, 1): 'cpir', (6, 2): 'inir', (6, 3): 'otir',
       (7, 0): 'lddr', (7, 1): 'cpdr', (7, 2): 'indr', (7, 3): 'otdr'}


def h8(v): return '%02Xh' % v if v < 0xA0 else '0%02Xh' % v
def h16(v): return '%04Xh' % v if v < 0xA000 else '0%04Xh' % v


def dis(mem, pc, base, labels=None):
    """mem: bytes, pc: address, base: address of mem[0]. returns (text, length, target)"""
    lab = labels or {}
    def rd(a): return mem[a - base]
    def name(a): return lab.get(a, h16(a))
    start = pc
    op = rd(pc); pc += 1
    idx = None
    if op in (0xDD, 0xFD):
        idx = 'ix' if op == 0xDD else 'iy'
        op = rd(pc); pc += 1
    target = None

    def r(i, d=None):
        if idx is None: return R[i]
        if i == 6: return '(%s%+d)' % (idx, d) if d else '(%s)' % idx
        if i == 4: return idx + 'h'
        if i == 5: return idx + 'l'
        return R[i]

    def hl(): return idx or 'hl'

    if op == 0xCB:
        if idx:
            d = rd(pc); pc += 1
            d = d - 256 if d > 127 else d
            op2 = rd(pc); pc += 1
            x, y, z = op2 >> 6, (op2 >> 3) & 7, op2 & 7
            m = '(%s%+d)' % (idx, d)
        else:
            op2 = rd(pc); pc += 1
            x, y, z = op2 >> 6, (op2 >> 3) & 7, op2 & 7
            m = R[z]
        t = [f'{ROT[y]} {m}', f'bit {y},{m}', f'res {y},{m}', f'set {y},{m}'][x]
        return t, pc - start, None
    if op == 0xED:
        op2 = rd(pc); pc += 1
        x, y, z = op2 >> 6, (op2 >> 3) & 7, op2 & 7
        p, q = y >> 1, y & 1
        if x == 1:
            if z == 0: t = f'in {R[y]},(c)' if y != 6 else 'in (c)'
            elif z == 1: t = f'out (c),{R[y]}' if y != 6 else 'out (c),0'
            elif z == 2: t = f'{"sbc" if q == 0 else "adc"} hl,{RP[p]}'
            elif z == 3:
                nn = rd(pc) | rd(pc + 1) << 8; pc += 2
                t = f'ld ({name(nn)}),{RP[p]}' if q == 0 else f'ld {RP[p]},({name(nn)})'
            elif z == 4: t = 'neg'
            elif z == 5: t = 'reti' if y == 1 else 'retn'
            elif z == 6: t = f'im {IM[y]}'
            else: t = ['ld i,a', 'ld r,a', 'ld a,i', 'ld a,r', 'rrd', 'rld', 'nop*', 'nop*'][y]
        elif x == 2 and (y, z) in BLI: t = BLI[(y, z)]
        elif op2 == 0xC1: t = 'mulub a,b'
        elif op2 == 0xF9: t = 'muluw hl,bc'  # R800
        else: t = 'db 0EDh,%s' % h8(op2)
        return t, pc - start, None

    x, y, z = op >> 6, (op >> 3) & 7, op & 7
    p, q = y >> 1, y & 1

    def disp():
        nonlocal pc
        d = rd(pc); pc += 1
        return d - 256 if d > 127 else d

    def n8():
        nonlocal pc
        v = rd(pc); pc += 1; return v

    def n16():
        nonlocal pc
        v = rd(pc) | rd(pc + 1) << 8; pc += 2; return v

    t = None
    if x == 0:
        if z == 0:
            if y == 0: t = 'nop'
            elif y == 1: t = "ex af,af'"
            else:
                d = disp(); target = pc + d
                t = ['', '', 'djnz', 'jr', 'jr nz,', 'jr z,', 'jr nc,', 'jr c,'][y]
                t = (t + (' ' if y < 4 else '') + name(target))
        elif z == 1:
            if q == 0:
                v = n16(); t = f'ld {RP[p] if p != 2 else hl()},{name(v)}'
            else: t = f'add {hl()},{RP[p] if p != 2 else hl()}'
        elif z == 2:
            if q == 0:
                if p == 0: t = 'ld (bc),a'
                elif p == 1: t = 'ld (de),a'
                elif p == 2: v = n16(); t = f'ld ({name(v)}),{hl()}'
                else: v = n16(); t = f'ld ({name(v)}),a'
            else:
                if p == 0: t = 'ld a,(bc)'
                elif p == 1: t = 'ld a,(de)'
                elif p == 2: v = n16(); t = f'ld {hl()},({name(v)})'
                else: v = n16(); t = f'ld a,({name(v)})'
        elif z == 3: t = f'{"inc" if q == 0 else "dec"} {RP[p] if p != 2 else hl()}'
        elif z in (4, 5):
            d = disp() if (idx and y == 6) else None
            t = f'{"inc" if z == 4 else "dec"} {r(y, d)}'
        elif z == 6:
            d = disp() if (idx and y == 6) else None
            v = n8(); t = f'ld {r(y, d)},{h8(v)}'
        else: t = ['rlca', 'rrca', 'rla', 'rra', 'daa', 'cpl', 'scf', 'ccf'][y]
    elif x == 1:
        if op == 0x76: t = 'halt'
        else:
            d = disp() if (idx and (y == 6 or z == 6)) else None
            if idx and (y == 6 or z == 6):
                a = r(y, d) if y == 6 else R[y]
                b = r(z, d) if z == 6 else R[z]
            else:
                a, b = r(y), r(z)
            t = f'ld {a},{b}'
    elif x == 2:
        d = disp() if (idx and z == 6) else None
        t = f'{ALU[y]}{r(z, d)}'
    else:
        if z == 0: t = f'ret {CC[y]}'
        elif z == 1:
            if q == 0: t = f'pop {RP2[p] if p != 2 else hl()}'
            else: t = ['ret', 'exx', f'jp ({hl()})', f'ld sp,{hl()}'][p]
        elif z == 2: v = n16(); target = v; t = f'jp {CC[y]},{name(v)}'
        elif z == 3:
            if y == 0: v = n16(); target = v; t = f'jp {name(v)}'
            elif y == 2: v = n8(); t = f'out ({h8(v)}),a'
            elif y == 3: v = n8(); t = f'in a,({h8(v)})'
            elif y == 4: t = f'ex (sp),{hl()}'
            elif y == 5: t = 'ex de,hl'
            elif y == 6: t = 'di'
            else: t = 'ei'
        elif z == 4: v = n16(); target = v; t = f'call {CC[y]},{name(v)}'
        elif z == 5:
            if q == 0: t = f'push {RP2[p] if p != 2 else hl()}'
            else: v = n16(); target = v; t = f'call {name(v)}'
        elif z == 6: v = n8(); t = f'{ALU[y]}{h8(v)}'
        else: t = f'rst {h8(y * 8)}'
    return t, pc - start, target
