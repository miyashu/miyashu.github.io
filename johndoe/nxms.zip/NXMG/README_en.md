# NXMG - Nextor 3 for the MEGA-SCSI (v1.0)

ROM images that run Nextor 3 on the MEGA-SCSI by ESE Artists' Factory (normal model and model with SCC), and an installer that writes them to the cartridge's SRAM.

Driver 1.0, installer NXMGINST 1.0. The ROM images contain the kernel of Nextor 3.0 (the final release of 2026-11-01). This is unofficial software. Use it at your own risk.

| File | Contents |
|---|---|
| `NXMG_A8.ROM` | Nextor 3 ROM image (128 KB) for the normal MEGA-SCSI (ASCII-compatible MegaROM controller) |
| `NXMG_SCC.ROM` | Nextor 3 ROM image (128 KB) for the MEGA-SCSI with SCC (Konami MegaROM controller, known as WAVE-SCSI) |
| `NXMGINST.COM` | Installer. Writes a ROM image to the SRAM of the MEGA-SCSI and makes the SRAM disk. It can also restore the original contents |
| `LICENSE_Nextor.md` | The Nextor license (the ROM images contain the Nextor kernel) |

## What it does

- Finds the devices on SCSI IDs 0-6 and reads and writes them as Nextor drives (LUN 0 only)
- 32-bit sector numbers, so an SCSI2SD set to more than 2 GB works
- Removable devices (MO and so on) are checked for a medium
- Reads take a whole 512-byte sector in one go with no waits, as in the original MEGA-SCSI BIOS (speed first)
- Writes wait for the SPC's FIFO to be empty every 8 bytes. The original MEGA-SCSI (with its MSX-DOS2 based kernel) sometimes had trouble writing to an SCSI2SD or SCSI2CF, so writes play safe here
- Booting does not hang when no SCSI device is connected or powered ("SCSI bus not responding" is shown and the device scan stops)
- **SRAM disk** (the counterpart of the original kernel's ESE RAM disk): the SRAM after the first 128 KB (128 KB on the 256 KB model, 384 KB on 512 KB, 896 KB on 1024 KB) is device 1. It keeps its contents with the power off, and Nextor can boot from it. The SCSI devices are devices 2-8 (SCSI IDs 0-6)

## What it does not do (differences from the original MEGA-SCSI kernel)

- Disks formatted by the original kernel are not guaranteed to work. Re-create the partitions with Nextor's `CALL FDISK` (from BASIC) before using them
- The contents of the original kernel's ESE RAM disk are not used as they are. The installer makes a new SRAM disk (asking first if there is data)
- No other features of the original kernel (CALL commands and so on)
- Software that drives the SPC directly (written for the original kernel) does not work

## Requirements

- A MEGA-SCSI with 128 KB of SRAM or more (tested on real hardware: 128 KB and 1024 KB; 256 KB and 512 KB only in an emulator)
- MSX2 or later (NXMGINST runs under MSX-DOS2 or Nextor)
- 64 KB or more of mapper RAM, and 128 KB of VRAM
- The Nextor 3 system files: `NEXTOR.SYS` and `COMMAND3.COM` from the Nextor 3.0 release (https://github.com/Konamiman/Nextor/releases; they are also in `tools.zip`). Put them in the same folder as the installer and they are copied to the SRAM disk

## Installing

1. Put `NXMGINST.COM` and the ROM image for your model (`NXMG_A8.ROM` for the normal model, `NXMG_SCC.ROM` for the model with SCC) on a floppy or other disk. To boot from the SRAM disk, put `NEXTOR.SYS` and `COMMAND3.COM` in the same folder too.
2. With the MEGA-SCSI inserted, run this from MSX-DOS2 or Nextor:

   ```
   NXMGINST NXMG_A8.ROM /B
   ```

   - With `/B`, **the whole SRAM** (128 KB to 1 MB; 1 MB on the 1024 KB model) is saved to `NXMGBACK.ROM` before writing. The original kernel is 64 KB, and the FAT and so on of its ESE RAM disk start at 64 KB into the SRAM, so the first 128 KB alone can't bring it back. Save it to a drive with enough free space, such as the SCSI2SD (a 1 MB backup doesn't fit on a floppy, and it can't go on the SRAM disk or the ESE RAM disk itself). If the file can't be written, the partial file is deleted and an error is shown. Use `/B` on the first installation, in case you want the original kernel back. `/B:filename` sets the file name. If a file with the same name exists, you are asked whether to overwrite it.
   - To take a backup only, run `NXMGINST /B`.
   - On models with 256 KB of SRAM or more, the SRAM after the first 128 KB is formatted as the SRAM disk, and `NEXTOR.SYS` and `COMMAND3.COM` are copied to it if present (as the original installer MGINST did with the ESE RAM disk). If it already holds data (the original kernel's ESE RAM disk, or an SRAM disk made earlier), you are asked whether to format it. Answer `N`, or give `/N`, to leave the SRAM disk alone.
3. Answer `Y` to the (Y/N) question to write. Reading the files takes some 15-20 seconds (from a floppy), and the writing itself is over in an instant.
4. When "DONE" is shown and the screen (or just its border, depending on the screen mode) turns **green**, press the reset button. **Red** ("WRITE ERROR") means the verification failed: write it again. The machine does not restart by itself.
5. If the system files went onto the SRAM disk, Nextor boots from it. Create partitions on the SCSI disks with `CALL FDISK` (from BASIC) before using them. Put `NEXTOR.SYS` and `COMMAND3.COM` on such a disk to boot from it as well.

To go back, run `NXMGINST NXMGBACK.ROM` under Nextor. The whole SRAM returns to the state it was in when saved (the original kernel and the contents of its ESE RAM disk).

### "MEGA-SCSI not found"

If you booted from another DOS cartridge or a floppy and the MEGA-SCSI kernel is not running, the installer can't find the cartridge by itself. Give the slot, as `/S:1` (slot 1) or `/S:2-1` (expanded slot 2-1). The given slot is always checked for the SPC, so it works even if the SRAM is empty.

```
NXMGINST NXMG_A8.ROM /B /S:1
```

### Other notes

- When a Nextor ROM image is written with `/N`, only the first 128 KB of the SRAM is changed. When the SRAM disk is made, only the part from its start to the end of the files is written.
- MGLOAD / NGLOAD can write the images too, but only when the MEGA-SCSI kernel is not running (when you booted DOS from a floppy or another cartridge). They don't back up or verify.
- NXMGINST may refuse to run ("*** Wrong version of MSX-DOS") on a Nextor 2 kernel combined with the MSX-DOS2 `MSXDOS2.SYS` / `COMMAND2.COM`. Use a DOS kernel and system files of the same version.
- If the machine doesn't boot any more (for example, the power went off while writing), remove the MEGA-SCSI, boot, and write the image again in another way (MGLOAD and so on).

## Drive letters in Nextor 3

At boot time Nextor 3 examines the devices of each driver in device number order and assigns the drive letters in that order (see "3.2. Booting Nextor" in the Nextor 3.0 user manual). The devices of this driver are:

| Device | What |
|---|---|
| 1 | The SRAM disk (models with 256 KB or more) |
| 2-8 | The devices on SCSI IDs 0-6 |

- A formatted SRAM disk is always the first drive (A:, if there are no other Nextor cartridges). Nextor 3 boots from the first drive that has a boot sector, so with an SRAM disk Nextor always boots from it. If the SRAM disk has no `NEXTOR.SYS` and `COMMAND3.COM`, DOS doesn't start even if an SCSI disk has them, and you end up in BASIC (checked in an emulator). When making the SRAM disk, put the system files in the installer's folder. To boot from an SCSI disk, don't make an SRAM disk (`/N`; an SRAM disk made earlier stays as it is, though).
- An unformatted SRAM disk gets no drive letter.
- An SCSI device that is switched off (and not removable) gets no drive letter either, so the drive letters of the devices after it move up. A removable device (MO and so on) gets one drive letter even with no medium.
- A device with partitions marked "active" gets one drive letter per active partition (`CALL FDISK` changes the marks).
- The Nextor 3 kernel disables Nextor 2 cartridges in other slots (for example an ESE SDisk with Nextor 2.1.0 Alpha), so they get no drive letters (this is how Nextor 3 works). MSX-DOS / MSX-DOS2 drives (the internal floppy drive and so on) can still be used.

## SCSI2SD and SD cards

The SCSI2SD can become unstable depending on the SD card. In testing, with the same SCSI2SD and driver, these things happened with 2 of the 3 SD cards tried:

- A copy of a 720 KB file finished with no error, but the file on the SCSI2SD came out short, and the next read hung
- The SCSI2SD's name came out garbled and the machine hung just from booting
- Once it hung, the SCSI2SD only came back after being switched off for a while

The SCSI2SD (V4 / V5) reports a write as done before it is written to the SD card when the card is slow (when the host doesn't use SCSI disconnection, as is the case with this driver). If the SD card then stops responding, the data is lost but DOS can't report an error. If the system hangs or files get damaged, try another SD card. Checking the card with H2testw on a PC, or an overwrite format with SD Card Formatter, can also help.

## Tested on

- Real hardware: Panasonic FS-A1ST + SCSI2SD V4 (ID 0)
  - With the Nextor 3.0 kernel (normal and SCC models, 1024 KB): install (including the SRAM disk), booting from the SRAM disk, drive letters, power-on with the SCSI2SD switched on, DRVTEST, formatting SD cards with `CALL FDISK`, reading and writing 720 KB files (MegaFlashROM SCC+ SD → SCSI2SD → SRAM disk → MegaFlashROM, on Z80 / R800; the files copied back matched the originals), writing and reading twelve 720 KB files in a row. Normal model with 128 KB: install and boot
  - Checked earlier with the Nextor 3.0.0 Beta2 kernel (same driver):
    - SCC model, 1024 KB: install, booting from the SCSI2SD, reads and writes on Z80 / R800 (a 720 KB floppy image copied 5 times between a RAM disk and the SCSI2SD, contents matched), the medium seen by `CALL FDISK`
    - Normal model, 1024 KB (slot 1, `/S:1`): install, reads and writes of a 720 KB file (Z80 / R800)
    - Booting with the SCSI device switched off (no hang)
    - SRAM disk (normal and SCC models, 1024 KB): formatting with `CALL FDISK`, booting from it, reads and writes of a 720 KB file (Z80 / R800), contents kept with the power off
    - NXMGINST 0.3 (normal and SCC models, 1024 KB): making the SRAM disk (Y / N to the format question, `/N`) and booting from it. Files written to the SRAM disk and copied back to the SD card matched the originals
    - Whole-SRAM backup (normal and SCC models, 1024 KB): saved with `/B` under Nextor → the original kernel dump written, the original kernel and its ESE RAM disk work (CHKDSK) → the backup written back, Nextor and the SRAM disk are back (CHKDSK)
    - Normal model, 128 KB: install (no SRAM disk)
- Emulator (openMSX, FS-A1ST): normal model with 128 KB / 1024 KB and SCC model with 1024 KB: install and restore, booting from an SCSI hard disk and from the SRAM disk, reads and writes. Making the SRAM disk with the installer and the whole-SRAM backup and restore: normal model with 128 / 256 / 512 KB and SCC model with 1024 KB (the last bank of the normal 1024 KB model can't be tested in the emulator, so that was checked on real hardware only)

Not tested yet: models with 256 KB / 512 KB SRAM on real hardware, restoring a whole-SRAM backup taken while the original kernel was running, more than 2 GB, devices other than the SCSI2SD (HDD, MO, SCSI2CF), machines other than the FS-A1ST.

## Rights

- Nextor is the work of Konamiman (Néstor Soriano), and MSX-DOS is (c) MSX Licensing Corporation. The ROM images contain the Nextor 3.0 kernel. They follow the Nextor license in `LICENSE_Nextor.md`: no commercial use (selling and so on).
- The MEGA-SCSI is a product of ESE Artists' Factory (http://www.hat.hi-ho.ne.jp/tujikawa/ese/).
