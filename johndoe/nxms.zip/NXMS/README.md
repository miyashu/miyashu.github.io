# NXMG - MEGA-SCSI 用 Nextor 3 (試験版)

似非職人工房の MEGA-SCSI(ノーマル版、SCC 付き版)で Nextor 3 を動かすための ROM イメージと、それを SRAM に書き込むインストーラです。

**Nextor 3.0.0 はまだベータ版です。** この ROM には Nextor 3.0.0 Beta2 のカーネルが入っています。ここに書いた動き(できること、できないこと、下の「Nextor 3.0.0 Beta2 での注意」)は 2026-10 時点の Beta2 で確かめたもので、今後の Nextor の更新で直ったり変わったりすることがあります。非公式のソフトです。使用は自己責任でお願いします。

| ファイル | 内容 |
|---|---|
| `NXMG_A8.ROM` | ノーマル版 MEGA-SCSI(アスキー製メガロムコントローラ互換)用の Nextor 3 ROM イメージ(128KB) |
| `NXMG_SCC.ROM` | SCC 付き MEGA-SCSI(コナミ製メガロムコントローラ使用、通称 WAVE-SCSI)用の Nextor 3 ROM イメージ(128KB) |
| `NXMGINST.COM` | インストーラ。ROM イメージを MEGA-SCSI の SRAM に書き込み、SRAM ディスクを作る。元に戻すこともできる |
| `LICENSE_Nextor.md` | Nextor の使用条件(ROM イメージに Nextor のカーネルが入っているため) |

## できること

- SCSI ID 0〜6 の機器を探して、Nextor のドライブとして読み書きする(LUN は 0 のみ)
- セクタ番号は 32 ビット。SCSI2SD の容量を 2GB より大きくしても使える
- 取り外しできる機器(MO など)はメディアの有無を確かめる
- 読み込みは元の MEGA-SCSI BIOS と同じく、1 セクタ 512 バイトを待ちなしで一気に読む(速さ優先)
- 書き込みは 8 バイトごとに SPC の FIFO が空くのを待つ。オリジナルの MEGA-SCSI(MSX-DOS2 カーネルベース)では SCSI2SD や SCSI2CF への書き込みで問題が出ることがあったため、こちらは安全側にしている
- SCSI 機器がない、または電源が入っていなくても、起動時に止まらない(「SCSI bus not responding」と出して検出を打ち切る)
- **SRAM ディスク**(元のカーネルの似非 RAM ディスクにあたるもの): SRAM の 128KB 以降(256KB 版は 128KB、512KB 版は 384KB、1024KB 版は 896KB)をデバイス 1 として読み書きする。電源を切っても中身が残り、ここから起動もできる。SCSI の機器はデバイス 2〜8(SCSI ID 0〜6)

## できないこと(元の MEGA-SCSI カーネルとの違い)

- 元のカーネルでフォーマットしたディスクの読み書きは保証しない。Nextor の `CALL FDISK`(BASIC)でパーティションを作り直してから使う
- 元のカーネルの似非 RAM ディスクの中身はそのまま使えない。SRAM ディスクはインストーラが作り直す(中身があるときは確認してから)
- 元のカーネルのそのほかの機能(CALL 命令など)はない
- SPC を直接操作するソフト(元のカーネル用)は動かない

## 必要なもの

- SRAM 128KB 以上の MEGA-SCSI(確かめたのは 128KB と 1024KB。256KB / 512KB でも問題ないはず)
- MSX2 以降(MSX-DOS2 または Nextor が起動できる環境で NXMGINST を動かす)
- マッパー RAM 64KB 以上と VRAM 128KB
- Nextor 3 のシステムファイル: Nextor 3.0.0 Beta2 のリリース(https://github.com/Konamiman/Nextor/releases)の `tools.zip` にある `NEXTOR.SYS` と `COMMAND3.COM`。インストーラと同じフォルダに置くと、SRAM ディスクに書き込まれる

## インストール

1. フロッピーなどに `NXMGINST.COM` と、機種に合った ROM イメージ(ノーマル版は `NXMG_A8.ROM`、SCC 付き版は `NXMG_SCC.ROM`)を入れます。SRAM ディスクから起動したいときは、同じフォルダに `NEXTOR.SYS` と `COMMAND3.COM` も入れます。
2. MEGA-SCSI を挿した状態で、MSX-DOS2 または Nextor から次を実行します。

   ```
   NXMGINST NXMG_A8.ROM /B
   ```

   - `/B` を付けると、書き込む前に **SRAM 全体**(128KB〜1MB。1MB 版なら 1MB)を `NXMGBACK.ROM` に保存します。元のカーネルは 64KB で、似非 RAM ディスクの FAT などが SRAM の 64KB 目から入っているため、先頭 128KB だけでは元に戻せないからです。保存先は SCSI2SD など、SRAM の大きさの空きがあるドライブにしてください(フロッピーには 1MB 版のバックアップは入りません。SRAM ディスクや似非 RAM ディスク自身にも置けません)。書けなかったときは、途中までのファイルを消してエラーを出します。元のカーネルに戻したいときのために、初めてのインストールでは付けることを勧めます。`/B:ファイル名` で名前を変えられます。同じ名前のファイルがあると、上書きするかを聞きます。
   - バックアップだけを取るときは `NXMGINST /B` です。
   - SRAM が 256KB 以上の版では、SRAM の 128KB 以降を SRAM ディスクとしてフォーマットし、`NEXTOR.SYS` と `COMMAND3.COM` があれば書き込みます(元のインストーラ MGINST が似非 RAM ディスクを作ったのと同じです)。すでに中身があるとき(元のカーネルの似非 RAM ディスクや、前に作った SRAM ディスク)は、フォーマットするかを先に聞きます。`N` と答えるか `/N` を付けると、SRAM ディスクには触りません。
3. 確認(Y/N)に `Y` と答えると書き込みます。ファイルを読むのに 15〜20 秒ほどかかり(フロッピーの場合)、書き込みは一瞬で終わります。
4. 画面に「DONE」と出て画面(画面モードによっては周辺だけ)が **緑** になったら、リセットボタンを押します。**赤**(「WRITE ERROR」)は照合エラーなので、もう一度書き込んでください。自動では再起動しません。
5. SRAM ディスクにシステムファイルを入れたときは、そこから Nextor が起動します。SCSI のディスクは `CALL FDISK`(BASIC)でパーティションを作ってから使います。そこに `NEXTOR.SYS` と `COMMAND3.COM` を入れると、そのディスクからも起動できます。

元に戻すときは、Nextor の上で `NXMGINST NXMGBACK.ROM` を実行します。SRAM 全体が、保存したときの状態(元のカーネルと似非 RAM ディスクの中身)に戻ります。

### 「MEGA-SCSI not found」と出たとき

別の DOS カートリッジやフロッピーから起動していて、MEGA-SCSI のカーネルが動いていないと、自動では見つけられません。`/S:1`(スロット 1)や `/S:2-1`(拡張スロット 2-1)のようにスロットを指定してください。指定したスロットでは SPC があるかを必ず確かめるので、SRAM が空でも書き込めます。

```
NXMGINST NXMG_A8.ROM /B /S:1
```

### そのほか

- Nextor の ROM イメージを `/N` を付けて書くときに書き換えるのは、SRAM の先頭 128KB だけです。SRAM ディスクを作るときも、書くのはディスクの先頭からファイルの終わりまでです。
- MGLOAD / NGLOAD でも書けます。ただし MEGA-SCSI のカーネルが動いていないとき(フロッピーや別のカートリッジの DOS で起動したとき)に限ります。バックアップと照合はしません。
- NXMGINST を、Nextor 2 のカーネルに MSX-DOS2 の `MSXDOS2.SYS` / `COMMAND2.COM` を組み合わせた環境で動かすと、「*** Wrong version of MSX-DOS」と出て動かないことがあります。DOS のカーネルとシステムファイルの版をそろえてください。
- 書き込み中に電源が切れるなどして起動しなくなったときは、MEGA-SCSI を外して起動し、別の方法(MGLOAD など)で書き直してください。

## Nextor 3.0.0 Beta2 での注意

MEGA-SCSI のドライバの問題ではなく、Nextor 3.0.0 Beta2 のカーネルの動きです。Beta 版なので、今後変わるかもしれません。

- **ドライブの割り当て:** Nextor 3 では、起動時にメディアが入っている(パーティションがある)機器から先にドライブ名が割り当てられるようです。そのため、カートリッジの組み合わせやメディアの有無で、A: になる機器が変わります。たとえば MegaFlashROM SCC+ SD(Nextor 3 用ドライバ)では、SD カードの有無で ROM ディスクが A: になったり C: になったりしました。AUTOEXEC.BAT は起動ドライブ(A:)にあるものだけが実行されるので注意してください。MEGA-SCSI でも、SCSI 機器の電源やメディアの有無で A: が変わります。
  - MegaFlashROM SCC+ SD の Nextor 3 用ドライバでは、デバイス番号の順番も Nextor 2 用から変わっています(Nextor の Issue [#262](https://github.com/Konamiman/Nextor/issues/262) で報告済み)。
- **Nextor 2 のカートリッジが使えない:** Nextor 3 のカーネルが起動すると、同時に挿した Nextor 2 のカートリッジ(例: 似非SDisk の Nextor 2.1.0 Alpha)は止められ、ドライブが割り当てられません。起動時に初期化メッセージは出ます。MSX-DOS / MSX-DOS2 のドライブ(本体のフロッピーなど)は使えます。

## 確かめた環境

- 実機: Panasonic FS-A1ST + SCSI2SD V4(2GB、ID 0)
  - SCC 付き版 1024KB: インストール、SCSI2SD からの起動、Z80 / R800 での読み書き(720KB のフロッピーのイメージを RAM ディスクと SCSI2SD の間で 5 回コピーして内容が一致)、`CALL FDISK` でのメディアの認識
  - ノーマル版 1024KB(スロット 1、`/S:1`): インストール、720KB のファイルの読み書き(Z80 / R800)
  - SCSI 機器の電源を切った状態での起動(止まらない)
  - SRAM ディスク(ノーマル版 / SCC 付き版 1024KB): `CALL FDISK` でのフォーマット、SRAM ディスクからの起動、720KB のファイルの読み書き(Z80 / R800)、電源を切っても中身が残ること
- エミュレータ(openMSX、FS-A1ST): ノーマル版 128KB / 1024KB、SCC 付き版 1024KB で、インストールと復元、SCSI ハードディスクと SRAM ディスクからの起動と読み書き。インストーラでの SRAM ディスクの作成はノーマル版 256KB / 512KB / 1024KB、SCC 付き版 1024KB

まだ確かめていないこと: 実機での SRAM 128KB / 256KB / 512KB の版、`CALL FDISK` での実際のフォーマット、2GB を超える容量、SCSI2SD 以外の機器(HDD、MO、SCSI2CF)、FS-A1ST 以外の機種。

## 権利

- Nextor は Konamiman(Néstor Soriano)氏の作品で、MSX-DOS は MSX Licensing Corporation の著作物です。ROM イメージには Nextor 3.0.0 Beta2 のカーネルが入っています。使用条件は `LICENSE_Nextor.md` のとおりで、販売などの商用利用はできません。
- MEGA-SCSI は似非職人工房(http://www.hat.hi-ho.ne.jp/tujikawa/ese/)の製品です。
